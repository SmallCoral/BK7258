/**
 * @file sdcard_test.c
 * @brief SD/TF 卡读写自测驱动实现（本板适配）
 *
 * 数据流：SDIO Host(GPIO14~19) → sd_card 驱动 → FATFS → VFS POSIX(/sd0)。
 * 挂载用 mount("SOURCE_NONE", "/sd0", "fatfs", 0, &partition)；
 * 文件读写用 POSIX open/write/read/close (bk_posix.h)。
 */

#include "sdcard_test.h"

#include <stdio.h>
#include <os/os.h>
#include <os/str.h>
#include <os/mem.h>
#include <components/log.h>
#include <bk_vfs.h>
#include <bk_posix.h>
#include <bk_partition.h>
#include "bsp_gpio.h"

#define TAG "sdcard_test"

#define SD_DEFAULT_FILE     "sd_test.txt"
#define SD_DEFAULT_CONTENT  "Hello BK7258 SD card! write-read self test.\r\n"
#define SD_READ_BUF_SIZE    256

// 大文件/性能测试参数
#define SD_PERF_DEFAULT_FILE   "perf_test.bin"
#define SD_PERF_DEFAULT_KB     512            // 默认 512KB
#define SD_PERF_CHUNK          (16 * 1024)    // 16KB 分块

static bool s_sd_mounted = false;

/**
 * @brief 卡检测：读 SD_CD(GPIO47，上拉，插卡=低)
 *
 * @return true 已插卡；false 未插卡
 */
bool sdcard_test_card_present(void)
{
	// SD_CD(GPIO47) 上拉, 插卡拉低; board_gpio_get 返回输入电平(高=true)
	return board_gpio_get(BOARD_SD_CD_PIN) == false;
}

/**
 * @brief 挂载 SD 卡到 /sd0（幂等）
 *
 * @return 操作结果
 * @retval BK_OK 挂载成功或已挂载
 * @retval BK_FAIL 未检测到 TF 卡
 */
bk_err_t sdcard_test_mount(void)
{
	if (s_sd_mounted) {
		BK_LOGI(TAG, "SD already mounted on %s\r\n", VFS_SD_0_PATITION_0);
		return BK_OK;
	}

	if (!sdcard_test_card_present()) {
		BK_LOGE(TAG, "未检测到 TF 卡 (SD_CD=GPIO47 为高), 请插卡后重试\r\n");
		return BK_FAIL;
	}

	struct bk_fatfs_partition partition = {0};
	partition.part_type = FATFS_DEVICE;
	partition.part_dev.device_name = FATFS_DEV_SDCARD;
	partition.mount_path = VFS_SD_0_PATITION_0;

	int ret = mount("SOURCE_NONE", partition.mount_path, "fatfs", 0, &partition);
	if (ret != BK_OK) {
		BK_LOGE(TAG, "mount %s fail: %d (检查 TF 卡是否插好/已 FAT 格式化)\r\n",
			VFS_SD_0_PATITION_0, ret);
		return ret;
	}

	s_sd_mounted = true;
	BK_LOGI(TAG, "SD mounted on %s OK\r\n", VFS_SD_0_PATITION_0);
	return BK_OK;
}

/**
 * @brief 卸载 SD 卡
 *
 * @return 操作结果
 * @retval BK_OK 卸载成功或未挂载
 */
bk_err_t sdcard_test_unmount(void)
{
	if (!s_sd_mounted) {
		return BK_OK;
	}
	int ret = umount(VFS_SD_0_PATITION_0);
	if (ret != BK_OK) {
		BK_LOGE(TAG, "umount %s fail: %d\r\n", VFS_SD_0_PATITION_0, ret);
		return ret;
	}
	s_sd_mounted = false;
	BK_LOGI(TAG, "SD unmounted from %s\r\n", VFS_SD_0_PATITION_0);
	return BK_OK;
}

/**
 * @brief 查询 SD 卡是否已挂载
 *
 * @return true 已挂载；false 未挂载
 */
bool sdcard_test_is_mounted(void)
{
	return s_sd_mounted;
}

static bk_err_t sd_write_file(const char *path, const char *content, int len)
{
	int fd = open(path, O_RDWR | O_CREAT | O_TRUNC);
	if (fd < 0) {
		BK_LOGE(TAG, "[WRITE] open %s fail: %d\r\n", path, fd);
		return BK_FAIL;
	}

	int wlen = write(fd, content, len);
	close(fd);

	if (wlen != len) {
		BK_LOGE(TAG, "[WRITE] write %s short: %d/%d\r\n", path, wlen, len);
		return BK_FAIL;
	}
	BK_LOGI(TAG, "[WRITE] %s OK, %d bytes\r\n", path, wlen);
	return BK_OK;
}

static bk_err_t sd_read_file(const char *path, const char *expect, int expect_len)
{
	char buf[SD_READ_BUF_SIZE] = {0};

	int fd = open(path, O_RDONLY);
	if (fd < 0) {
		BK_LOGE(TAG, "[READ] open %s fail: %d\r\n", path, fd);
		return BK_FAIL;
	}

	int rlen = read(fd, buf, sizeof(buf) - 1);
	close(fd);

	if (rlen < 0) {
		BK_LOGE(TAG, "[READ] read %s fail: %d\r\n", path, rlen);
		return BK_FAIL;
	}
	buf[rlen] = '\0';
	BK_LOGI(TAG, "[READ] %s OK, %d bytes, content:\r\n%s\r\n", path, rlen, buf);

	if (rlen != expect_len || os_memcmp(buf, expect, expect_len) != 0) {
		BK_LOGE(TAG, "[VERIFY] mismatch! 读回内容与写入不一致\r\n");
		return BK_FAIL;
	}
	BK_LOGI(TAG, "[VERIFY] PASS, 读回内容与写入一致\r\n");
	return BK_OK;
}

/**
 * @brief 完整自测：挂载 → 写文件 → 读回校验（保持挂载）
 *
 * @param filename 文件名，NULL 时使用 sd_test.txt
 * @param content  写入内容，NULL 时使用内置默认字符串
 * @return 操作结果
 * @retval BK_OK 读写校验通过
 */
bk_err_t sdcard_test_write_read(const char *filename, const char *content)
{
	bk_err_t ret = sdcard_test_mount();
	if (ret != BK_OK) {
		return ret;
	}

	if (filename == NULL) {
		filename = SD_DEFAULT_FILE;
	}
	if (content == NULL) {
		content = SD_DEFAULT_CONTENT;
	}
	int len = (int)os_strlen(content);

	char path[64] = {0};
	snprintf(path, sizeof(path), "%s/%s", VFS_SD_0_PATITION_0, filename);

	ret = sd_write_file(path, content, len);
	if (ret != BK_OK) {
		return ret;
	}

	ret = sd_read_file(path, content, len);
	if (ret != BK_OK) {
		return ret;
	}

	BK_LOGI(TAG, "=== SD write-read self test DONE ===\r\n");
	return BK_OK;
}

// 吞吐量 KB/s = 字节数 / 1024 / (ms/1000) = total_kb * 1000 / ms
static uint32_t calc_kbps(uint32_t total_kb, uint32_t ms)
{
	if (ms == 0) {
		ms = 1;   // 防除零(耗时不足 1ms 时按 1ms 估算)
	}
	return (total_kb * 1000U) / ms;
}

/**
 * @brief 大文件读写与性能测试
 *
 * @param filename 文件名，NULL 时用 perf_test.bin
 * @param total_kb 文件大小（KB），0 时用默认 512KB
 * @param verify   是否在读取时校验数据
 * @return 操作结果
 * @retval BK_OK 测试完成
 */
bk_err_t sdcard_test_large_rw(const char *filename, uint32_t total_kb, bool verify)
{
	bk_err_t ret = sdcard_test_mount();
	if (ret != BK_OK) {
		return ret;
	}

	if (filename == NULL) {
		filename = SD_PERF_DEFAULT_FILE;
	}
	if (total_kb == 0) {
		total_kb = SD_PERF_DEFAULT_KB;
	}
	uint32_t total_bytes = total_kb * 1024U;

	uint8_t *buf = (uint8_t *)os_malloc(SD_PERF_CHUNK);
	if (buf == NULL) {
		BK_LOGE(TAG, "[PERF] malloc %d fail\r\n", SD_PERF_CHUNK);
		return BK_FAIL;
	}
	// 位置无关的可校验模式: 每 16KB 块内容一致, 整块/尾块比对均可验证
	for (uint32_t j = 0; j < SD_PERF_CHUNK; j++) {
		buf[j] = (uint8_t)(j * 7U + 1U);
	}

	char path[64] = {0};
	snprintf(path, sizeof(path), "%s/%s", VFS_SD_0_PATITION_0, filename);

	BK_LOGI(TAG, "[PERF] file=%s size=%uKB chunk=%dKB verify=%d\r\n",
		path, (unsigned)total_kb, SD_PERF_CHUNK / 1024, (int)verify);

	// ---- 写: 分块写满 total_bytes, 计时 ----
	int fd = open(path, O_RDWR | O_CREAT | O_TRUNC);
	if (fd < 0) {
		BK_LOGE(TAG, "[PERF] open(write) %s fail: %d\r\n", path, fd);
		os_free(buf);
		return BK_FAIL;
	}

	uint32_t t0 = (uint32_t)rtos_get_time();
	uint32_t written = 0;
	ret = BK_OK;
	while (written < total_bytes) {
		uint32_t n = total_bytes - written;
		if (n > SD_PERF_CHUNK) {
			n = SD_PERF_CHUNK;
		}
		int w = write(fd, buf, n);
		if (w != (int)n) {
			BK_LOGE(TAG, "[PERF] write short at %u: %d/%u\r\n", (unsigned)written, w, (unsigned)n);
			ret = BK_FAIL;
			break;
		}
		written += n;
	}
	fsync(fd);
	close(fd);
	uint32_t write_ms = (uint32_t)rtos_get_time() - t0;

	if (ret != BK_OK) {
		os_free(buf);
		return ret;
	}
	BK_LOGI(TAG, "[PERF] WRITE %uKB done in %ums, %u KB/s\r\n",
		(unsigned)total_kb, (unsigned)write_ms, (unsigned)calc_kbps(total_kb, write_ms));

	// ---- 读: 整文件读回, 计时 + 可选校验 ----
	fd = open(path, O_RDONLY);
	if (fd < 0) {
		BK_LOGE(TAG, "[PERF] open(read) %s fail: %d\r\n", path, fd);
		os_free(buf);
		return BK_FAIL;
	}

	uint32_t readback = 0;
	uint32_t read_ms = 0;   // 仅累计 read() 耗时, 不含 verify 比对
	bool verify_ok = true;
	while (readback < total_bytes) {
		uint32_t n = total_bytes - readback;
		if (n > SD_PERF_CHUNK) {
			n = SD_PERF_CHUNK;
		}
		uint32_t ts = (uint32_t)rtos_get_time();
		int r = read(fd, buf, n);
		read_ms += (uint32_t)rtos_get_time() - ts;
		if (r != (int)n) {
			BK_LOGE(TAG, "[PERF] read short at %u: %d/%u\r\n", (unsigned)readback, r, (unsigned)n);
			ret = BK_FAIL;
			break;
		}
		if (verify) {
			for (uint32_t j = 0; j < n; j++) {
				if (buf[j] != (uint8_t)(j * 7U + 1U)) {
					verify_ok = false;
					break;
				}
			}
			if (!verify_ok) {
				BK_LOGE(TAG, "[PERF] VERIFY mismatch at offset %u\r\n", (unsigned)(readback));
				ret = BK_FAIL;
				break;
			}
		}
		readback += n;
	}
	close(fd);

	if (ret != BK_OK) {
		os_free(buf);
		return ret;
	}
	BK_LOGI(TAG, "[PERF] READ  %uKB done in %ums, %u KB/s\r\n",
		(unsigned)total_kb, (unsigned)read_ms, (unsigned)calc_kbps(total_kb, read_ms));
	if (verify) {
		BK_LOGI(TAG, "[PERF] VERIFY PASS, %uKB 读回与写入完全一致\r\n", (unsigned)total_kb);
	}

	os_free(buf);
	BK_LOGI(TAG, "=== SD large-file & perf test DONE ===\r\n");
	return BK_OK;
}
