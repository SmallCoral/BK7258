/**
 * @file sdcard_test.h
 * @brief TF 卡 SDIO 挂载、读写与性能测试对外接口
 *
 * 接法见 board_design/pinmap.md：SDIO CLK/CMD/D0～D3 = GPIO14～19，SD_CD = GPIO47。
 */

#pragma once

#include <common/bk_err.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 挂载 SD 卡到 /sd0（幂等）
 * @return 操作结果
 * @retval BK_OK 挂载成功或已挂载
 */
bk_err_t sdcard_test_mount(void);

/**
 * @brief 卸载 SD 卡
 * @return 操作结果
 */
bk_err_t sdcard_test_unmount(void);

/**
 * @brief 查询 SD 卡是否已挂载
 * @return true 已挂载
 */
bool sdcard_test_is_mounted(void);

/**
 * @brief 检测 TF 卡是否插入（GPIO47，插卡=低）
 * @return true 卡已插入
 * @note 需先调用 board_gpio_init_sd()
 */
bool sdcard_test_card_present(void);

/**
 * @brief 写文件并读回校验
 * @param filename 目标路径，NULL 使用默认文件名
 * @param content  写入内容，NULL 使用内置测试串
 * @return 操作结果
 * @retval BK_OK 读写校验通过
 */
bk_err_t sdcard_test_write_read(const char *filename, const char *content);

/**
 * @brief 大文件顺序读写与吞吐测试
 * @param filename  目标路径，NULL 使用 "perf_test.bin"
 * @param total_kb  文件大小（KB），0 使用默认 512 KB
 * @param verify    true 时读回逐块校验
 * @return 操作结果
 */
bk_err_t sdcard_test_large_rw(const char *filename, uint32_t total_kb, bool verify);

#ifdef __cplusplus
}
#endif
