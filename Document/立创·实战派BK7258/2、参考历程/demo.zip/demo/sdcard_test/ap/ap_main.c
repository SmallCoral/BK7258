/**
 * @file ap_main.c
 * @brief SD/TF 卡读写自测工程 AP 入口
 *
 * 卡接法见 board_design/pinmap.md：SDIO 4 线 + SD_CD=GPIO47。
 * 开机自动跑卡检测、挂载、写读校验；其余场景用 `sd_test` CLI 手动触发。
 */

#include "bk_private/bk_init.h"
#include <os/os.h>
#include <os/str.h>
#include <components/log.h>
#include "cli.h"
#include "bsp_gpio.h"
#include "sdcard_test.h"

#define TAG "sdcard_test"

static void sd_report_card(void)
{
	bool present = sdcard_test_card_present();
	BK_LOGI(TAG, "[CARD] SD_CD(GPIO47)=%s -> TF 卡%s\r\n",
		present ? "low" : "high", present ? "已插入" : "未插入");
}

static void cli_sd_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
	if (argc >= 2 && os_strcmp(argv[1], "card") == 0) {
		sd_report_card();
	} else if (argc >= 2 && os_strcmp(argv[1], "mount") == 0) {
		sdcard_test_mount();
	} else if (argc >= 2 && os_strcmp(argv[1], "umount") == 0) {
		sdcard_test_unmount();
	} else if (argc >= 3 && os_strcmp(argv[1], "write") == 0) {
		sdcard_test_write_read(NULL, argv[2]);
	} else if (argc >= 2 && os_strcmp(argv[1], "perf") == 0) {
		uint32_t kb = (argc >= 3) ? os_strtoul(argv[2], NULL, 10) : 0;   // 0 -> 默认 512KB
		sdcard_test_large_rw(NULL, kb, true);
	} else {
		// 无参数 / 仅 sd_test: 跑默认 写+读 自测
		sdcard_test_write_read(NULL, NULL);
	}
}

static const struct cli_command s_sd_test_cmds[] = {
	{"sd_test", "sd_test [card|mount|umount|write <s>|perf [KB]]", cli_sd_test_cmd},
};

static void sd_selftest_thread(void *arg)
{
	rtos_delay_milliseconds(500);
	BK_LOGI(TAG, "=== SD card selftest: card + mount + write + read ===\r\n");
	sd_report_card();
	sdcard_test_write_read(NULL, NULL);
	BK_LOGI(TAG, "用 CLI 继续: sd_test card / write <s> / perf [KB] / mount|umount\r\n");
	rtos_delete_thread(NULL);
}

/**
 * @brief AP 入口：初始化系统、板级 GPIO、CLI 并启动 SD 自测线程
 *
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}

	if (bsp_gpio_init_power_master() != BK_OK ||
	    bsp_gpio_init_export_io() != BK_OK ||
	    bsp_gpio_init_sd() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
		return -1;
	}
	board_gpio_set_high(BOARD_EXPORT_IO_PWR_PIN);  // GPIO6 外扩 IO 电源 (兜底)
	rtos_delay_milliseconds(100);

	if (cli_register_commands(
	        s_sd_test_cmds, sizeof(s_sd_test_cmds) / sizeof(s_sd_test_cmds[0])) != BK_OK) {
		BK_LOGE(TAG, "FAIL: CLI register\r\n");
		goto fail_power;
	}

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "sd_selftest", sd_selftest_thread, 4096, NULL) != BK_OK) {
		BK_LOGE(TAG, "FAIL: selftest thread create\r\n");
		cli_unregister_commands(
			s_sd_test_cmds, sizeof(s_sd_test_cmds) / sizeof(s_sd_test_cmds[0]));
		goto fail_power;
	}

	BK_LOGI(TAG, "READY: SD card CLI and selftest\r\n");
	return 0;

fail_power:
	board_gpio_set_low(BOARD_EXPORT_IO_PWR_PIN);
	return -1;
}
