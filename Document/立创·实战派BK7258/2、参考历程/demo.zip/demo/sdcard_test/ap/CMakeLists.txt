set(incs .)
set(srcs ap_main.c sdcard_test.c)

set(priv_req bk_common bk_vfs fatfs bsp_gpio)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
