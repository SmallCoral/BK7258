# sdcard_test：TF 卡挂载、读写校验与性能测试

本 README 依据工程当前的 C、CMake、config、分区文件及板级 GPIO 实现编写。仓库中的历史测试报告可供对照，但本次文档整理不等同于对当前开发板和存储卡重新实测，最终需人工插卡并验收。

## 示例目标

通过 SDIO 4 线接口访问 TF 卡，完成卡检测、FATFS 挂载、短文件写入/读回校验，以及可选的大文件吞吐和逐块数据校验。开机后自动执行一次卡检测与短文件自测。

## 学习内容

- 理解 SDIO Host、SD 卡驱动、FATFS、VFS 和 POSIX 文件 API 的分层。
- 使用低有效卡检测脚判断 TF 卡是否插入。
- 实现幂等挂载、安全卸载、覆盖写入、读回比对和性能计时。
- 从 CP Shell 通过 `ap_cmd` 调用 AP 注册的测试命令。

## 硬件要求和引脚

- 立创 BK7258 开发板及扩展板、可用 TF 卡、USB 数据线。
- TF 卡应采用 FATFS 可识别的 FAT 文件系统；测试会覆盖卡根目录中的 `sd_test.txt` 和 `perf_test.bin`，请先备份同名文件。
- 数据总线为 SDIO 4 线，卡检测使用 `BOARD_SD_CD_PIN`（输入上拉，插卡为低电平）；工程还打开外扩 IO 电源作为板级供电兜底。
- CLK/CMD/D0~D3、卡检测和有效电平以[板卡唯一权威映射](../../board_design/pinmap.md)、[`usr_gpio_cfg_default.h`](../../components/board_cfg/usr_gpio_cfg_default.h)及 [`bsp_gpio.h`](../../components/bsp_gpio/bsp_gpio.h)为准，本文不复制完整引脚表。

## 软件配置

- AP CMake 编译 `ap_main.c` 与 `sdcard_test.c`，依赖 `bk_vfs`、`fatfs` 和 `bsp_gpio`。
- 当前配置已启用 `CONFIG_VFS`、`CONFIG_FATFS`、`CONFIG_FATFS_SDCARD`、`CONFIG_SDIO_HOST`、`CONFIG_SDCARD`、`CONFIG_SDIO` 和 `CONFIG_SDIO_V2P0`。
- 已启用 `CONFIG_SDCARD_BUSWIDTH_4LINE`、`CONFIG_SDIO_4LINES_EN` 和 `CONFIG_SDIO_GDMA_EN`；`CONFIG_SDCARD_DEFAULT_CLOCK_FREQ=11` 对应当前工程采用的 40 MHz 档。
- 挂载点由 SDK 常量 `VFS_SD_0_PATITION_0` 提供，当前实现使用 `/sd0`。
- `usr_gpio_cfg.h` 使用统一板级 SDIO 映射；当前标准 AP/CP/OTA 分区和 16 MiB PSRAM 布局无需修改。

## 编译命令

在本工程目录执行其一：

```bash
make bk7258
```

```bash
./dbuild.sh bk7258
```

默认目录布局为 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。需要排除旧产物时先执行 `make clean`。

## 固件位置

整机烧录文件为：

```text
build/bk7258/sdcard_test/package/all-app.bin
```

烧录时选择 `package/all-app.bin`，不要选择 AP、CP 或分区中间镜像。

## 烧录和运行步骤

1. 备份 TF 卡数据，将卡断电插入卡槽。
2. 用 USB 数据线连接开发板，按[固件烧录参考](../../docs/reference/firmware-download.md)烧录上述固件。
3. 释放下载串口，以 `115200 8N1`、无流控打开终端；详见[串口控制台参考](../../docs/reference/serial-console.md)。
4. 短按复位键；程序延时约 500 ms 后自动检测卡、挂载 `/sd0`、覆盖写入 `sd_test.txt`、读回并比对。
5. 使用 CLI 分别验证卡检测、自定义短字符串和性能测试。
6. 取卡前执行卸载命令，确认卸载成功后再断电或拔卡。

## 预期日志或现象

开机自测的关键日志按源码应包含：

```text
READY: SD card CLI and selftest
=== SD card selftest: card + mount + write + read ===
[CARD] SD_CD(GPIO47)=low -> TF 卡已插入
SD mounted on /sd0 OK
[WRITE] /sd0/sd_test.txt OK
[READ] /sd0/sd_test.txt OK
[VERIFY] PASS, 读回内容与写入一致
=== SD write-read self test DONE ===
```

性能测试完成后应出现 WRITE、READ 吞吐和 `VERIFY PASS`。吞吐受卡片、文件系统状态和供电影响，不应把历史数据当作当前设备保证。人工硬件验收至少应确认：卡检测正确、挂载成功、短文件一致、目标容量性能文件全量校验通过、卸载后再取卡；本文不宣称本次修改已重新完成这些测试。

## CLI/AT 操作方法

串口命令注册在 AP，需从 CP Shell 加 `ap_cmd` 前缀，行尾使用 CRLF：

```text
ap_cmd sd_test card
ap_cmd sd_test
ap_cmd sd_test write Hello_BK7258
ap_cmd sd_test perf
ap_cmd sd_test perf 2048
ap_cmd sd_test mount
ap_cmd sd_test umount
```

- `card`：读取卡检测电平。
- 无参数：重跑默认短文件写入、读回和校验。
- `write <s>`：将单个、不含空格的参数写入 `sd_test.txt` 后读回校验。
- `perf [KB]`：覆盖写入 `perf_test.bin`，默认 512 KiB，16 KiB 分块，并读回全量校验。
- `mount` / `umount`：仅挂载或卸载。
- 本工程不是 AT 固件，不使用 `AT+...` 命令。

## 常见问题

- 显示未插卡：检查卡是否到底、卡座触点和 `BOARD_SD_CD_PIN`；插卡时源码预期 GPIO47 为低。
- `mount /sd0 fail`：确认卡已插好并使用 FATFS 可识别格式；先保存第一条挂载错误码。
- 写入或校验失败：备份数据后检查卡片健康、剩余容量、供电和文件系统，避免运行中拔卡。
- 性能值波动：使用同一张卡、相同容量和空闲状态重复测试；验收以数据校验通过优先，不把单次吞吐当作保证。
- 命令无响应：确认 `ap_cmd` 前缀、CRLF 行尾和串口未被下载工具占用。
- 通用环境、烧录和日志问题见[通用排障](../../docs/reference/troubleshooting.md)。

## 代码入口

教学调用链：

```text
AP main()
  -> bk_init()
  -> power_master -> export IO GPIO -> SD_CD GPIO
  -> 注册 sd_test
  -> sd_selftest_thread()
       -> card_present()
       -> write_read()
          -> mount("fatfs", "/sd0")
          -> open(O_TRUNC) -> write -> close
          -> open(O_RDONLY) -> read -> close
          -> 长度与内容比对

CLI perf
  -> mount()
  -> 16 KiB 分块写入 + fsync + 写计时
  -> 分块读回 + 读计时 + 数据模式校验
```

工程入口位于 [`ap/ap_main.c`](ap/ap_main.c)，文件系统测试实现位于 [`ap/sdcard_test.c`](ap/sdcard_test.c)。

## 可扩展方向

- 增加目录、追加写、随机读写和多文件压力测试。
- 增加异常断电、只读卡、满盘和损坏文件系统等失败场景。
- 将吞吐统计扩展为多轮均值、分位数和不同块大小对比。
- 在产品业务中增加写入原子性、日志轮转和安全卸载策略。

## 相关示例

- [SD 卡教程](../../docs/examples/peripherals/sd-card.md)：更完整的测试矩阵和诊断说明。
- [历史测试报告](TEST_REPORT.md)：仓库已有测试记录，仅作对照，当前硬件需重新验收。
- [`hello_board`](../hello_board/)：先验证基础编译、烧录和串口。
- [`digital_camera`](../digital_camera/)：在综合外设场景中使用 SD 卡存储。
