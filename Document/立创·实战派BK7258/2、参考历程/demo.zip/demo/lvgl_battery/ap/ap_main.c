/**
 * @file ap_main.c
 * @brief BK7258 LVGL 电池电量显示例程入口
 *
 * 初始化板级 GPIO 与 media_service，启动 ST7789 + FT6336 + LVGL V9 电池界面，
 * 电池电压/电量由芯片内部 SARADC 通道 ADC_0 实时采样（采样逻辑内置于
 * lvgl_battery_ui 模块，不依赖 bk_batt_monitor 组件）。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>

#include "bsp_gpio.h"
#include "lvgl_battery_ui.h"

#define TAG "lvgl_battery"

/**
 * @brief AP 应用入口：初始化板级资源并启动电池电量 UI
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }
    /* TP 的 RST/INT 由 TP 框架接管，故不调用 bsp_gpio_init_tp() */
    if (bsp_gpio_init_power_master() != BK_OK ||
        bsp_gpio_init_lcd() != BK_OK ||
        bsp_gpio_init_key() != BK_OK) {
        BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
        return -1;
    }
    if (media_service_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: media service init\r\n");
        return -1;
    }

    if (!lvgl_battery_ui_init()) {
        BK_LOGE(TAG, "FAIL: LVGL UI init\r\n");
        return -1;
    }

    BK_LOGI(TAG, "READY: LVGL battery UI\r\n");
    return 0;
}
