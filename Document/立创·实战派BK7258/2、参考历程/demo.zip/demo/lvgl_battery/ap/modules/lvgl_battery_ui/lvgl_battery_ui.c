/**
 * @file lvgl_battery_ui.c
 * @brief LVGL V9 电池电量显示例程实现。
 *
 * 本模块完成三件事：
 *  1. 初始化 ST7789V2 SPI 屏 + FT6336 触摸 + LVGL V9（逻辑横屏 320x240）；
 *  2. 用一个后台采样线程读取芯片内部 SARADC 通道 @ref BATT_ADC_CHAN 得到电池
 *     电压，并按查表法换算为电量百分比；
 *  3. 用一个 LVGL 定时器把采样结果刷新到自绘的电池控件（外框 + 电量条 +
 *     百分比 + 充电状态；充电时为电池内黄色方块从左到右循环点亮）。
 *
 * @note 电压/电量为真实 ADC 采样；充电状态由板级 5V_DET(GPIO28) 判断 USB 是否
 *       插入，FULL_DET(GPIO26) 判断是否充满（插 USB=CHARGING/FULL，拔 USB=ON BATTERY）。
 * @note 整个例程只有采样线程一处访问 SARADC，以避免与其它 ADC 线程并发导致
 *       saradc 驱动初始化竞争（曾触发 xQueueSemaphoreTake 断言复位）。
 * @warning 电压换算系数与电量查表为示例默认值，需按实际电池校准。
 */

#include "lvgl_battery_ui.h"

#include <components/bk_display.h>
#include <components/log.h>
#include <driver/adc.h>
#include <driver/drv_tp.h>
#include <driver/gpio.h>
#include <driver/pwr_clk.h>
#include <frame_buffer.h>
#include <lv_vendor.h>
#include <lvgl.h>
#include <modules/pm.h>
#include <os/mem.h>
#include <os/os.h>

#include "bsp_gpio.h"
#include "bsp_lcd_st7789.h"

/** @brief 日志 TAG。 */
#define TAG "lvgl_batt"

/** @brief 复用 Designer 生成的字体（仅含 ASCII 字形）。 */
LV_FONT_DECLARE(lv_font_montserrat_regular_20);

/** @brief 采样周期（ms）；电池电压变化缓慢，1.5s 足够。 */
#define BATT_SAMPLE_INTERVAL_MS 1500
/** @brief UI 刷新周期（ms）；充电方块动画每拍前进一步，取 250ms。 */
#define BATT_UI_REFRESH_MS 250

/** @brief 电量填充条最大宽度（像素），对应外框内容区宽度。 */
#define BATT_FILL_MAX_W 162
/** @brief 电量填充条高度（像素）。 */
#define BATT_FILL_H 62
/** @brief 充电动画黄色方块个数。 */
#define BATT_SEG_COUNT 6
/** @brief 单个充电方块宽度（像素）。 */
#define BATT_SEG_W 22
/** @brief 充电方块间距（像素）。6*22 + 5*6 = 162 == BATT_FILL_MAX_W。 */
#define BATT_SEG_GAP 6
/** @brief FULL_DET 有效电平（与 ETA4322 STDBY、bk_batt_monitor 一致：低有效）。 */
#define BATT_FULL_DET_ACTIVE 0

/**
 * @brief 电压 EMA 滤波系数分母：filt += (mv - filt) / N。
 *
 * N 越大越平滑但响应越慢。取 8 时对单次 ADC 噪声有明显抑制。
 */
#define BATT_MV_EMA_SHIFT 3
/**
 * @brief 放电时显示百分比更新去抖次数。
 *
 * 新的百分比候选值需连续出现该次数才更新显示，用于过滤边界处偶发的
 * ±1% 翻动，同时不牺牲步进精度（真实缓慢变化时每个百分比都会显示）。
 */
#define BATT_PCT_DEBOUNCE 2

/**
 * @brief 拔下 USB 后的重同步采样数。
 *
 * 充电时电量被冻结；拔下 USB 后电压需要一小段时间从充电顶高回落到静置电压。
 * 在这几拍里让电量**双向**跟随真实电压收敛到静置值（充久了会涨上去），
 * 收敛完再恢复“只降”锁定。默认 4 × 1.5s ≈ 6s。
 */
#define BATT_UNPLUG_RESYNC_SAMPLES 4

/** @brief LVGL 触摸输入设备句柄，由 lv_vendor 创建后导出。 */
extern lv_indev_t *indev_touchpad;

/* --- 采样线程写、UI 定时器读的共享状态（弱一致即可，读写皆为原子标量） --- */

/** @brief 最近一次采样得到的电池电压（mV）。 */
static volatile uint16_t s_batt_mv;
/** @brief 最近一次换算得到的电量百分比（0~100）。 */
static volatile uint8_t s_batt_pct;
/** @brief USB（5V_DET）是否有电：true=已插入。 */
static volatile bool s_usb_present;
/** @brief FULL_DET 是否有效：true=充电 IC 报告已充满。 */
static volatile bool s_batt_full;
/** @brief 是否已取得过一次有效采样（用于首帧前抑制刷新）。 */
static volatile bool s_batt_valid;
/** @brief 采样线程句柄。 */
static beken_thread_t s_sampler_thread;

/* --- LVGL 控件句柄 --- */

/** @brief 电量填充条对象（宽度随电量变化）。 */
static lv_obj_t *s_batt_fill;
/** @brief 电量百分比标签（电池供电时显示）。 */
static lv_obj_t *s_pct_label;
/** @brief 充电动画黄色方块（电池内部，从左到右循环点亮）。 */
static lv_obj_t *s_batt_segs[BATT_SEG_COUNT];
/** @brief 充电方块动画步进（0..BATT_SEG_COUNT-1）。 */
static uint8_t s_batt_charge_step;
/** @brief 充电状态标签（CHARGING / FULL / ON BATTERY）。 */
static lv_obj_t *s_status_label;

/** @brief ST7789V2 SPI 显示控制器配置。 */
static bk_display_spi_ctlr_config_t s_spi_cfg = {
    .lcd_device = NULL, /**< 运行时由 bsp_lcd_st7789_get() 填充。 */
    .spi_id = 1,
    .dc_pin = GPIO_5,
    .reset_pin = GPIO_12,
    .te_pin = 0,
};

/**
 * @brief LVGL 触摸读取回调（不做坐标旋转，旋转交由 LVGL ROTATE_90 统一处理）。
 *
 * 读取失败时做去抖：连续 5 次读失败才判定为“抬起”，避免抖动误触。
 *
 * @param[in]  indev 触发本次读取的输入设备（未使用）。
 * @param[out] data  输出的触摸点坐标与按压状态。
 */
static void touchpad_read_no_rotate(lv_indev_t *indev, lv_indev_data_t *data)
{
    (void)indev;
    static int32_t last_x;
    static int32_t last_y;
    static lv_indev_state_t last_state = LV_INDEV_STATE_RELEASED;
    static uint8_t read_fail_count;
    tp_point_infor_t point;

    if (drv_tp_read(&point) == 0) {
        read_fail_count = 0;
        last_x = point.m_x;
        last_y = point.m_y;
        last_state = point.m_state ? LV_INDEV_STATE_PRESSED
                                   : LV_INDEV_STATE_RELEASED;
        data->continue_reading = point.m_need_continue;
    } else {
        data->continue_reading = false;
        if (last_state != LV_INDEV_STATE_RELEASED && ++read_fail_count >= 5) {
            read_fail_count = 0;
            last_state = LV_INDEV_STATE_RELEASED;
            last_x = 0;
            last_y = 0;
        }
    }

    data->point.x = last_x;
    data->point.y = last_y;
    data->state = last_state;
}

/* --- 内部电池电压采样（芯片内部 SARADC 通道 ADC_0，读法与换算沿用
 *     bk_batt_monitor 组件）。 --- */

/** @brief 电池电压采样使用的内部 SARADC 通道。 */
#define BATT_ADC_CHAN            ADC_0
/** @brief SARADC 采样时钟。 */
#define BATT_ADC_CLK             203125
/** @brief SARADC steady 稳定控制值。 */
#define BATT_ADC_STEADY_CTRL     7
/** @brief 单次采样缓冲长度；前 5 个样本丢弃以避开建立过程。 */
#define BATT_ADC_BUF_SIZE        (5 + 5)
/** @brief 读取原始样本的等待超时（ms）。 */
#define BATT_ADC_READ_TIMEOUT_MS 1000

/*
 * 原始码值(raw) → 电压(mV) 的线性标定：mv = raw * SLOPE_NUM / SLOPE_DEN + OFFSET。
 *
 * 校准方法：读串口日志里的 raw 与万用表实测电池电压。
 *  - 只想快速修偏移：改 BATT_MV_OFFSET；
 *  - 想修比例：取高/低两个电量点各记一组 (raw, 万用表mV)，令
 *      SLOPE = (mv_hi - mv_lo) / (raw_hi - raw_lo)，OFFSET = mv_lo - raw_lo * SLOPE，
 *    再把 SLOPE 写成合适的 NUM/DEN（整数运算，避免浮点）。
 * 默认值 667/1000 与 +40 源自 bk_batt_monitor 参考硬件，未针对本板校准。
 */
/** @brief 电压换算斜率分子。 */
#define BATT_MV_SLOPE_NUM 667
/** @brief 电压换算斜率分母。 */
#define BATT_MV_SLOPE_DEN 1000
/** @brief 电压换算偏移（mV）。 */
#define BATT_MV_OFFSET    40

/** @brief SARADC 原始样本缓冲（仅采样线程使用）。 */
static uint16_t s_adc_buf[BATT_ADC_BUF_SIZE];

/**
 * @brief 电压-电量查表节点。
 */
typedef struct {
    uint16_t mv;  /**< 电压采样点（mV）。 */
    uint8_t pct;  /**< 该电压点对应的电量百分比（0~100）。 */
} batt_lut_t;

/**
 * @brief 截止（空电）电压（mV）：对应电量 0%。
 *
 * 电池放电截止点，按你的电池数据手册/实测调整（常见 3.0~3.3V）。
 */
#define BATT_MV_EMPTY 3000
/**
 * @brief 满电电压（mV）：对应查表上限电量。
 *
 * 锂电满电静置电压，按你的电池调整（常见 4.15~4.2V）。
 */
#define BATT_MV_FULL 4100

/**
 * @brief 电压(mV)→电量(%) 查表（示例值，需按实际电池放电曲线校准）。
 *
 * 首尾两端用 @ref BATT_MV_EMPTY / @ref BATT_MV_FULL 标定，中间点按放电曲线调整。
 */
static const batt_lut_t s_batt_lut[] = {
    {BATT_MV_EMPTY, 0}, {3400, 10}, {3450, 20}, {3500, 30},
    {3550, 40},         {3590, 50}, {3650, 60}, {3750, 70},
    {3880, 80},         {3980, 90}, {BATT_MV_FULL, 99},
};

/**
 * @brief 按查表 + 线性插值把电池电压换算为电量百分比。
 *
 * @param[in] mv 电池电压（mV）。
 * @return 电量百分比（0~100），越界时钳位到表两端。
 */
static uint8_t batt_mv_to_pct(uint16_t mv)
{
    const int n = sizeof(s_batt_lut) / sizeof(s_batt_lut[0]);

    if (mv <= s_batt_lut[0].mv) {
        return s_batt_lut[0].pct;
    }
    if (mv >= s_batt_lut[n - 1].mv) {
        return s_batt_lut[n - 1].pct;
    }
    for (int i = 0; i < n - 1; i++) {
        uint16_t v1 = s_batt_lut[i].mv;
        uint16_t v2 = s_batt_lut[i + 1].mv;
        if (mv >= v1 && mv <= v2) {
            int p1 = s_batt_lut[i].pct;
            int p2 = s_batt_lut[i + 1].pct;
            return (uint8_t)(p1 + (int)(mv - v1) * (p2 - p1) / (v2 - v1));
        }
    }
    return s_batt_lut[n - 1].pct;
}

/**
 * @brief 单次读取内部 SARADC 通道，换算并返回电池电压。
 *
 * 采样流程：acquire → init → 配置连续模式并旁路校准 → start → 读原始样本 →
 * stop/deinit/release；随后对第 5~N 个样本求均值（剔除 0 与 2048 的无效值），
 * 按线性标定 `mv = raw * BATT_MV_SLOPE_NUM / BATT_MV_SLOPE_DEN + BATT_MV_OFFSET`
 * 换算电压（系数见对应宏，需按本板校准）。
 *
 * @param[out] out_mv 输出电池电压（mV）。
 * @return 操作结果。
 * @retval BK_OK 采样成功，@p out_mv 有效。
 * @retval 其他  SARADC 驱动错误。
 */
static bk_err_t batt_read_mv(uint16_t *out_mv)
{
    bk_err_t ret = bk_adc_acquire();
    if (ret != BK_OK) {
        return ret;
    }

    ret = bk_adc_init(BATT_ADC_CHAN);
    if (ret != BK_OK) {
        bk_adc_release();
        return ret;
    }

    adc_config_t cfg;
    os_memset(&cfg, 0, sizeof(cfg));
    cfg.chan = BATT_ADC_CHAN;
    cfg.adc_mode = ADC_CONTINUOUS_MODE;
    cfg.src_clk = ADC_SCLK_XTAL_26M;
    cfg.clk = BATT_ADC_CLK;
    cfg.saturate_mode = 4;
    cfg.steady_ctrl = BATT_ADC_STEADY_CTRL;
    cfg.adc_filter = 0;
    cfg.sample_rate = 0;

    ret = bk_adc_set_config(&cfg);
    if (ret != BK_OK) {
        goto out_deinit;
    }

    bk_adc_enable_bypass_clalibration();

    ret = bk_adc_start();
    if (ret != BK_OK) {
        goto out_deinit;
    }

    os_memset(s_adc_buf, 0, sizeof(s_adc_buf));
    ret = bk_adc_read_raw(s_adc_buf, BATT_ADC_BUF_SIZE, BATT_ADC_READ_TIMEOUT_MS);
    bk_adc_stop();
    if (ret != BK_OK) {
        goto out_deinit;
    }

    uint32_t sum = 0;
    uint32_t cnt = 0;
    for (int i = 5; i < BATT_ADC_BUF_SIZE; i++) {
        uint16_t v = s_adc_buf[i];
        if (v != 0 && v != 2048) {
            sum += v;
            cnt++;
        }
    }
    uint16_t raw = cnt ? (uint16_t)(sum / cnt) : 0;
    *out_mv = (uint16_t)((uint32_t)raw * BATT_MV_SLOPE_NUM / BATT_MV_SLOPE_DEN +
                         BATT_MV_OFFSET);

out_deinit:
    bk_adc_deinit(BATT_ADC_CHAN);
    bk_adc_release();
    return ret;
}

/**
 * @brief 电池采样线程主体。
 *
 * 周期性读取电池电压/电量与 5V_DET 充电检测脚，结果写入模块共享状态供 UI
 * 定时器读取。永不返回。
 *
 * @param[in] arg 线程参数（未使用）。
 */
static void battery_sampler_thread(void *arg)
{
    (void)arg;

    uint32_t mv_filt = 0;    /* EMA 滤波后的电压（mV），0 表示尚未初始化 */
    uint8_t cand_pct = 0;    /* 待确认的百分比候选值 */
    uint8_t cand_cnt = 0;    /* 候选值已连续出现的次数 */
    bool prev_usb = false;   /* 上一拍 USB 状态，用于检测拔下沿 */
    uint8_t resync_cnt = 0;  /* 拔下后剩余的重同步拍数 */

    while (1) {
        uint16_t mv = 0;
        bk_err_t r = batt_read_mv(&mv);

        s_usb_present = (board_gpio_get(BOARD_5V_DET_PIN) != 0);
        s_batt_full =
            (board_gpio_get(BOARD_FULL_DET_PIN) == BATT_FULL_DET_ACTIVE);

        if (r == BK_OK && mv > 0) {
            /* 拔下沿：进入重同步窗口，并重置 EMA 使其立即重新种子到静置电压 */
            bool unplug_edge = (s_batt_valid && !s_usb_present && prev_usb);
            if (unplug_edge) {
                resync_cnt = BATT_UNPLUG_RESYNC_SAMPLES;
                mv_filt = 0;
            }

            /* 电压 EMA 滤波：首帧/重种子直接取样，之后按 1/N 步长逼近 */
            if (mv_filt == 0) {
                mv_filt = mv;
            } else {
                mv_filt += ((int32_t)mv - (int32_t)mv_filt) >> BATT_MV_EMA_SHIFT;
            }

            uint8_t new_pct = batt_mv_to_pct((uint16_t)mv_filt);

            if (!s_batt_valid) {
                /* 首帧直接采用 */
                s_batt_pct = new_pct;
                cand_cnt = 0;
            } else if (s_usb_present) {
                /* 充电：ADC 读的是被充电 IC 顶高的供电轨电压，不能真实反映
                 * 电量；UI 此时播黄色方块动画、不显示数值，故直接冻结电量，
                 * 拔下 USB 后再重同步到真实电压 */
                if (s_batt_full) {
                    s_batt_pct = 100;
                }
                cand_cnt = 0;
            } else if (resync_cnt > 0) {
                /* 拔下重同步：双向跟随真实电压收敛到静置值（充久了会涨上去） */
                s_batt_pct = new_pct;
                cand_cnt = 0;
                resync_cnt--;
            } else {
                /* 放电：方向锁定为只降 + 去抖，滤掉边界处偶发的 ±1% 翻动 */
                if (new_pct < s_batt_pct) {
                    if (new_pct == cand_pct) {
                        if (++cand_cnt >= BATT_PCT_DEBOUNCE) {
                            s_batt_pct = new_pct;
                            cand_cnt = 0;
                        }
                    } else {
                        cand_pct = new_pct;
                        cand_cnt = 1;
                    }
                } else {
                    cand_cnt = 0;
                }
            }

            prev_usb = s_usb_present;

            s_batt_mv = (uint16_t)mv_filt;
            s_batt_valid = true;
            BK_LOGI(TAG, "batt raw=%umV filt=%umV %u%% usb=%d\r\n", mv,
                    (unsigned)mv_filt, s_batt_pct, (int)s_usb_present);
        } else {
            BK_LOGW(TAG, "adc read fail r=%d mv=%u\r\n", (int)r, mv);
        }

        rtos_delay_milliseconds(BATT_SAMPLE_INTERVAL_MS);
    }
}

/**
 * @brief 按电量返回电量条颜色。
 *
 * @param[in] pct 电量百分比（0~100）。
 * @return >50% 绿、20~50% 琥珀、<20% 红。
 */
static lv_color_t fill_color_for_pct(uint8_t pct)
{
    if (pct > 50) {
        return lv_color_hex(0x30d158); /* 绿 */
    }
    if (pct >= 20) {
        return lv_color_hex(0xffb020); /* 琥珀 */
    }
    return lv_color_hex(0xff453a); /* 红 */
}

/** @brief 更新充电方块：点亮前 lit_count 个；0 表示全部隐藏。 */
static void batt_segs_set_lit(uint8_t lit_count)
{
    for (int i = 0; i < BATT_SEG_COUNT; i++) {
        if (!s_batt_segs[i]) {
            continue;
        }
        if (i < lit_count) {
            lv_obj_clear_flag(s_batt_segs[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(s_batt_segs[i], LV_OBJ_FLAG_HIDDEN);
        }
    }
}

/**
 * @brief UI 刷新定时器回调（运行于 LVGL 线程）。
 *
 * 把采样线程写入的电量/充电状态映射到电池控件：电池供电时更新填充条与百分比；
 * 充电时隐藏填充条/百分比，电池内部黄色方块从左到右循环点亮；FULL 时全亮。
 * 首次有效采样前直接返回。
 *
 * @param[in] timer 触发本次回调的 LVGL 定时器（未使用）。
 */
static void battery_ui_timer_cb(lv_timer_t *timer)
{
    (void)timer;
    char buf[32];

    if (!s_batt_valid) {
        return;
    }

    if (s_usb_present) {
        lv_obj_add_flag(s_batt_fill, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(s_pct_label, LV_OBJ_FLAG_HIDDEN);

        if (s_batt_full) {
            batt_segs_set_lit(BATT_SEG_COUNT);
            lv_label_set_text(s_status_label, "FULL");
            lv_obj_set_style_text_color(s_status_label, lv_color_hex(0x30d158),
                                        LV_PART_MAIN);
        } else {
            uint8_t lit = (uint8_t)(s_batt_charge_step + 1);
            if (lit > BATT_SEG_COUNT) {
                lit = BATT_SEG_COUNT;
            }
            batt_segs_set_lit(lit);
            s_batt_charge_step++;
            if (s_batt_charge_step >= BATT_SEG_COUNT) {
                s_batt_charge_step = 0;
            }
            lv_label_set_text(s_status_label, "CHARGING");
            lv_obj_set_style_text_color(s_status_label, lv_color_hex(0xffb020),
                                        LV_PART_MAIN);
        }
        return;
    }

    batt_segs_set_lit(0);
    lv_obj_clear_flag(s_batt_fill, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(s_pct_label, LV_OBJ_FLAG_HIDDEN);

    uint8_t pct = s_batt_pct;
    int32_t w = (int32_t)BATT_FILL_MAX_W * pct / 100;
    if (w < 6) {
        w = 6;
    }
    lv_obj_set_width(s_batt_fill, w);
    lv_obj_set_style_bg_color(s_batt_fill, fill_color_for_pct(pct),
                              LV_PART_MAIN);

    lv_snprintf(buf, sizeof(buf), "%u%%", pct);
    lv_label_set_text(s_pct_label, buf);
    lv_label_set_text(s_status_label, "ON BATTERY");
    lv_obj_set_style_text_color(s_status_label, lv_color_hex(0x9fe6ff),
                                LV_PART_MAIN);
}

/**
 * @brief 构建并加载电池电量界面。
 *
 * 自绘：深色背景 + 标题、电池外框 body、正极帽 cap、电量填充条 fill、
 * 充电动画黄色方块、居中百分比标签、底部充电状态标签。
 * 控件句柄保存到模块静态变量供刷新使用。
 *
 * @note 必须在持有 lv_vendor 显示锁的上下文中调用。
 */
static void battery_screen_create(void)
{
    lv_obj_t *scr = lv_obj_create(NULL);
    lv_obj_set_scrollbar_mode(scr, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_size(scr, 320, 240);
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x0a1f3d), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(scr, 255, LV_PART_MAIN);

    /* 标题 */
    lv_obj_t *title = lv_label_create(scr);
    lv_label_set_text(title, "BATTERY");
    lv_obj_set_style_text_font(title, &lv_font_montserrat_regular_20,
                               LV_PART_MAIN);
    lv_obj_set_style_text_color(title, lv_color_hex(0x00e5ff), LV_PART_MAIN);
    lv_obj_set_style_text_letter_space(title, 3, LV_PART_MAIN);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 16);

    /* 电池外框（body）：透明底 + 青色边框 */
    lv_obj_t *body = lv_obj_create(scr);
    lv_obj_set_scrollbar_mode(body, LV_SCROLLBAR_MODE_OFF);
    lv_obj_clear_flag(body, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_size(body, 180, 84);
    lv_obj_align(body, LV_ALIGN_CENTER, -6, -6);
    lv_obj_set_style_bg_opa(body, 0, LV_PART_MAIN);
    lv_obj_set_style_border_color(body, lv_color_hex(0x00e5ff), LV_PART_MAIN);
    lv_obj_set_style_border_width(body, 3, LV_PART_MAIN);
    lv_obj_set_style_radius(body, 8, LV_PART_MAIN);
    lv_obj_set_style_pad_all(body, 4, LV_PART_MAIN);

    /* 电池正极帽（cap） */
    lv_obj_t *cap = lv_obj_create(scr);
    lv_obj_clear_flag(cap, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_size(cap, 10, 36);
    lv_obj_align_to(cap, body, LV_ALIGN_OUT_RIGHT_MID, 2, 0);
    lv_obj_set_style_bg_color(cap, lv_color_hex(0x00e5ff), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(cap, 255, LV_PART_MAIN);
    lv_obj_set_style_border_width(cap, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(cap, 2, LV_PART_MAIN);

    /* 电量填充条（fill）：电池供电时宽度随电量变化 */
    s_batt_fill = lv_obj_create(body);
    lv_obj_clear_flag(s_batt_fill, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_size(s_batt_fill, 6, BATT_FILL_H);
    lv_obj_align(s_batt_fill, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_style_bg_color(s_batt_fill, lv_color_hex(0x30d158),
                              LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_batt_fill, 255, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_batt_fill, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_batt_fill, 4, LV_PART_MAIN);

    /* 充电动画方块：黄实心，等宽+等间隔铺满 BATT_FILL_MAX_W */
    s_batt_charge_step = 0;
    for (int i = 0; i < BATT_SEG_COUNT; i++) {
        s_batt_segs[i] = lv_obj_create(body);
        lv_obj_clear_flag(s_batt_segs[i], LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_size(s_batt_segs[i], BATT_SEG_W, BATT_FILL_H);
        lv_obj_align(s_batt_segs[i], LV_ALIGN_LEFT_MID,
                     i * (BATT_SEG_W + BATT_SEG_GAP), 0);
        lv_obj_set_style_bg_color(s_batt_segs[i], lv_color_hex(0xffb020),
                                  LV_PART_MAIN);
        lv_obj_set_style_bg_opa(s_batt_segs[i], 255, LV_PART_MAIN);
        lv_obj_set_style_border_width(s_batt_segs[i], 0, LV_PART_MAIN);
        lv_obj_set_style_radius(s_batt_segs[i], 3, LV_PART_MAIN);
        lv_obj_add_flag(s_batt_segs[i], LV_OBJ_FLAG_HIDDEN);
    }

    /* 百分比（叠在电池中央，电池供电时显示） */
    s_pct_label = lv_label_create(scr);
    lv_label_set_text(s_pct_label, "--%");
    lv_obj_set_style_text_font(s_pct_label, &lv_font_montserrat_regular_20,
                               LV_PART_MAIN);
    lv_obj_set_style_text_color(s_pct_label, lv_color_hex(0xffffff),
                                LV_PART_MAIN);
    lv_obj_align_to(s_pct_label, body, LV_ALIGN_CENTER, 0, 0);

    /* 充电状态 */
    s_status_label = lv_label_create(scr);
    lv_label_set_text(s_status_label, "...");
    lv_obj_set_style_text_font(s_status_label, &lv_font_montserrat_regular_20,
                               LV_PART_MAIN);
    lv_obj_set_style_text_color(s_status_label, lv_color_hex(0x9fe6ff),
                                LV_PART_MAIN);
    lv_obj_align(s_status_label, LV_ALIGN_BOTTOM_MID, 0, -14);

    lv_screen_load(scr);
}

/**
 * @brief 初始化显示/触摸/LVGL，创建电池界面并启动采样。
 *
 * 依次完成：PSRAM 供电投票、点亮 LCD 电源/背光、初始化 5V_DET/FULL_DET 输入、
 * 打开 ST7789V2 SPI 屏并分配帧缓冲、初始化 LVGL V9（ROTATE_90 逻辑横屏）、
 * 绑定触摸回调、构建电池界面并注册刷新定时器、启动采样线程。
 *
 * @return 初始化结果。
 * @retval true  成功。
 * @retval false 帧缓冲分配、显示创建或线程创建失败。
 */
bool lvgl_battery_ui_init(void)
{
    lv_vnd_config_t cfg = {0};

    bk_pm_module_vote_psram_ctrl(PM_POWER_PSRAM_MODULE_NAME_LVGL_CODE_RUN,
                                 PM_POWER_MODULE_STATE_ON);

    board_gpio_set_high(BOARD_LCD_BL_PIN);
    board_gpio_set_high(BOARD_LCD_PWR_PIN);

    /* 5V_DET / FULL_DET 作为普通输入，用于充电状态判断 */
    bsp_gpio_init_batt_det();

    bsp_lcd_st7789_cfg_t lcd_cfg = {
        .landscape = false,
        .mirror_x = false,
        .mirror_y = false,
        .clk = LCD_QSPI_64M,
    };
    const lcd_device_t *lcd = bsp_lcd_st7789_get(&lcd_cfg);
    s_spi_cfg.lcd_device = lcd;

    cfg.width = lcd->width;
    cfg.height = lcd->height;
    cfg.render_mode = RENDER_PARTIAL_MODE;
    cfg.rotation = ROTATE_90;

    for (int i = 0; i < CONFIG_LVGL_FRAME_BUFFER_NUM; i++) {
        cfg.frame_buffer[i] = frame_buffer_display_malloc(
            cfg.width * cfg.height * sizeof(bk_color_t));
        if (!cfg.frame_buffer[i] || !cfg.frame_buffer[i]->frame) {
            BK_LOGE(TAG, "frame buffer %d alloc failed\r\n", i);
            return false;
        }
        os_memset(cfg.frame_buffer[i]->frame, 0,
                  cfg.width * cfg.height * sizeof(bk_color_t));
    }

    if (bk_display_spi_new(&cfg.handle, &s_spi_cfg) != AVDK_ERR_OK) {
        BK_LOGE(TAG, "create SPI display failed\r\n");
        return false;
    }

    lv_vendor_init(&cfg);
    bk_display_open(cfg.handle);

    drv_tp_open(cfg.width, cfg.height, TP_MIRROR_NONE);
    board_key_reinit_pin();
    if (indev_touchpad) {
        lv_indev_set_read_cb(indev_touchpad, touchpad_read_no_rotate);
    }

    lv_vendor_disp_lock();
    battery_screen_create();
    lv_timer_create(battery_ui_timer_cb, BATT_UI_REFRESH_MS, NULL);
    lv_vendor_disp_unlock();

    lv_vendor_start();

    rtos_delay_milliseconds(300);
    board_gpio_set_low(BOARD_LCD_BL_PIN);

    /* 启动唯一的 ADC 采样线程（内部只此一处访问 SARADC） */
    if (rtos_create_thread(&s_sampler_thread, 5, "batt_sampler",
                           (beken_thread_function_t)battery_sampler_thread,
                           2048, NULL) != BK_OK) {
        BK_LOGE(TAG, "create sampler thread failed\r\n");
        return false;
    }

    BK_LOGI(TAG, "UI ready: %dx%d\r\n", cfg.width, cfg.height);
    return true;
}
