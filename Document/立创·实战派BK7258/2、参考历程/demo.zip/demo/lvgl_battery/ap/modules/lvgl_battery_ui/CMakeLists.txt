include(${CMAKE_CURRENT_LIST_DIR}/../../../beken_generated/beken_generated.cmake)

set(incs
    .
    ${BEKEN_GENERATOR_INCLUDE_DIRS}
)

set(srcs
    lvgl_battery_ui.c
    ${BEKEN_GENERATOR_SOURCES}
)

set(priv_req
    media_service
    multimedia
    bk_display
    bk_peripheral
    lvgl
    bsp_lcd_st7789
    bsp_gpio
)

armino_component_register(
    SRCS "${srcs}"
    INCLUDE_DIRS "${incs}"
    PRIV_REQUIRES "${priv_req}"
)

target_compile_options(${COMPONENT_LIB} PRIVATE -Wno-unused-variable)
