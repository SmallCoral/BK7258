/**
 * @file lvgl_battery_ui.h
 * @brief LVGL 电池电量显示例程 UI 接口。
 *
 * 对外仅暴露一个初始化入口，内部完成显示/触摸/LVGL 初始化、电池界面构建
 * 以及内部 SARADC 采样线程的启动。
 */

#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 ST7789V2 + FT6336 + LVGL V9，创建电池电量界面并启动采样
 *
 * @return true 初始化成功；false 初始化失败
 */
bool lvgl_battery_ui_init(void);

#ifdef __cplusplus
}
#endif
