# LVGL 电池电量显示

用 **LVGL V9** 在 ST7789 屏上自绘一个电池控件（外框 + 电量填充条 + 百分比 + 电压 + 充电状态），
电压/电量由**芯片内部 SARADC 通道 `ADC_0`** 实时采样，充电状态由板级检测脚判断。

## 原理

BK7258 的 SARADC 有一个内部通道 `ADC_0`，可读取芯片 **VBAT 供电电压**。板上电池接在 `BAT` 座（`J7`），
经充电芯片 **ETA4322** 给系统供电，因此仅用电池供电时 VBAT ≈ 电池电压。

- **电压/电量**：读法与换算沿用 SDK 组件 `bk_avdk_smp_sdk/ap/components/bk_batt_monitor`
  （读 `ADC_0` 原始值 → `mv = raw * 667 / 1000 + 40` → 电压-百分比查表插值），
  但在本工程 `lvgl_battery_ui.c` 内以**单个采样线程**自行实现，避免与组件自带的监测线程
  并发访问 SARADC（两个线程同时初始化 saradc 驱动会触发 `xQueueSemaphoreTake` 断言复位）。
- **充电状态**：本例程用板级 `5V_DET(GPIO28)` 判断 USB 是否插入；`FULL_DET(GPIO26)` 为充满检测脚。
  - USB 未插入 → `ON BATTERY`
  - USB 插入且电量 < 99% → `CHARGING`
  - USB 插入且电量 ≥ 99% → `FULL`

> 注意：`ADC_0` 与 SARADC 采样经 **AP SARADC Client → mailbox → CP SARADC Server** 完成，
> 故 AP 侧需 `CONFIG_SARADC` + `CONFIG_SARADC_CLIENT`，CP 侧需 `CONFIG_SARADC` + `CONFIG_SARADC_SERVER` + `CONFIG_SARADC_MB`（本工程已配好）。
> 本工程未启用 `CONFIG_BAT_MONITOR`（读法已内联到模块，避免多线程并发访问 SARADC）。

## ⚠️ 校准

电压换算公式 `raw*667/1000+40` 与电量查表 `s_batt_lut` 是**示例默认值**（源自 bk_batt_monitor 参考硬件），
**未必与本板一致**。用万用表实测电池电压与显示值对比后，在 `lvgl_battery_ui.c` 内：

- 修正 `batt_read_mv()` 里的换算系数；
- 按你的电池放电曲线调整 `s_batt_lut` 电压-百分比表。

> 换算逻辑已在本工程模块内实现，改动不影响 SDK 组件与其它工程。

## 构建与烧录

```bash
cd projects/lvgl_battery
make bk7258
```

固件：`build/bk7258/lvgl_battery/package/all-app.bin`

## 预期表现

- 屏幕显示电池外框，电量条随电量绿/琥珀（<50%）/红（<20%）变色，中间显示百分比，下方显示电压与充电状态。
- CP UART0（115200）可见日志：

```text
batt 3720mV 62% usb=0
batt 3720mV 62% usb=0
...
```

## 关键文件

| 文件 | 说明 |
|------|------|
| `ap/ap_main.c` | 板级上电 + media 服务 + 启动 UI |
| `ap/modules/lvgl_battery_ui/lvgl_battery_ui.c` | 显示初始化、电池控件自绘、ADC 采样线程、LVGL 刷新定时器 |
| `ap/config/bk7258_ap/config` | `CONFIG_SARADC` / `CONFIG_SARADC_CLIENT` |
| `beken_generated/` | 复用其中字体 `lv_font_montserrat_regular_20`（仅 ASCII 字形） |

## 参考

- 电池监测组件：`bk_avdk_smp_sdk/ap/components/bk_batt_monitor`
- ADC 通道映射：`bk_avdk_smp_sdk/ap/middleware/soc/bk7258_ap/soc/adc_map.h`（`ADC_0` 为内部通道）
- USB VBUS 采样例程：`projects/adc_voltage_test`
