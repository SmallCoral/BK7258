# key_lcd_demo：SW2 按键切换 LCD 纯色

## 示例目标

在立创 BK7258 扩展板上使用板载 SW2 控制 ST7789V2 SPI 屏，在红、绿、蓝、白四种全屏颜色间循环切换，联合验证按键输入、消抖、帧缓冲和 LCD 刷屏链路。

## 学习内容

- GPIO7 上拉输入、低电平按下与软件消抖。
- SPI1 屏的电源、复位、背光和 RGB565 帧刷新。
- `bk_display` 显示控制器与板级 ST7789 profile 的组合使用。
- 用 CLI 查询状态、切换颜色以及关闭和重新打开显示。

## 硬件要求和引脚

需要 BK7258 主板、立创扩展板、配套 240×320 ST7789V2 SPI 屏、板载 SW2 和支持数据传输的 USB Type-C 线。

| 信号 | 引脚 | 说明 |
| --- | --- | --- |
| LCD CLK/CS/MOSI | GPIO2/GPIO3/GPIO4 | SPI1 |
| LCD D/C | GPIO5 | 普通输出 |
| LCD RESET | GPIO12 | 普通输出 |
| LCD PWR | GPIO13 | 高有效 |
| LCD BL | GPIO25 | 低有效，拉低点亮 |
| SW2 KEY | GPIO7 | 输入上拉，按下为低 |
| `3V3_OUT_CTL` | GPIO22 | 外部 3.3 V 总电源，高有效 |
| 调试 UART0 RX/TX | GPIO10/GPIO11 | CH340K 日志、CLI 与下载 |

FPC 必须断电插拔并确认方向。引脚和有效电平以 [`board_design/pinmap.md`](../../board_design/pinmap.md) 及 `components/bsp_gpio` 为准。

## 软件配置

- `ap/CMakeLists.txt` 编译 `ap_main.c`、`board_key_lcd.c`，依赖媒体、显示、`bsp_gpio` 和 `bsp_lcd_st7789`。
- `CONFIG_LCD_SPI_ST7789V2=y`、`CONFIG_LCD=y`、`CONFIG_LCD_SPI=y`、`CONFIG_CLI=y`。
- LCD 使用 SPI1、竖屏 240×320、RGB565、`LCD_QSPI_64M`。
- `bsp_lcd_st7789` 的初始化序列包含本板必需的 `INVON(0x21)`。
- 按键线程每 50 ms 轮询一次，`board_key_is_pressed()` 内再做约 20 ms 消抖。
- 工程使用 `partitions/bk7258/auto_partitions.csv` 的标准 AP/CP/OTA 分区布局。

## 编译命令

默认 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。在本工程目录执行：

```bash
make bk7258
```

Docker 编译：

```bash
./dbuild.sh bk7258
```

SDK 位于其他目录时，再用 `SDK_DIR` 覆盖默认路径。

## 固件位置

整机烧录文件为：

```text
build/bk7258/key_lcd_demo/package/all-app.bin
```

文件时间应晚于本次构建开始时间；不要烧录 AP、CP 或其他中间产物。

## 烧录和运行步骤

1. 断电安装并锁紧 LCD FPC，确认没有反插。
2. 用 USB Type-C 连接开发板，使用 BKFIL 选择 CH340K 串口和上述 `all-app.bin`。
3. 下载波特率设为 `1500000`，应用复位波特率设为 `115200`，完成烧录。
4. 让烧录工具释放串口，以 `115200 8N1`、无流控打开日志终端。
5. 短按复位键，观察默认红屏；逐次按下 SW2 检查颜色循环。

通用操作见[固件烧录参考](../../docs/reference/firmware-download.md)和[串口控制台参考](../../docs/reference/serial-console.md)。

## 预期日志或现象

启动后屏幕应亮起并显示红色，日志包含：

```text
color -> red
READY: press SW2 to cycle red/green/blue/white
```

每次有效按下 SW2，屏幕按“红 → 绿 → 蓝 → 白 → 红”切换，日志同步打印 `color -> green`、`color -> blue` 等。板上电源或充电指示灯不是本示例的软件输出。

## CLI/AT 操作方法

在 CH340K 终端使用 `115200 8N1` 和 CRLF。AP 命令带 `ap_cmd` 前缀：

| 命令 | 作用 |
| --- | --- |
| `ap_cmd key_lcd status` | 打印颜色、按键电平和 LCD 状态 |
| `ap_cmd key_lcd next` | 切换到下一种颜色 |
| `ap_cmd key_lcd color 0` | 红色；`1/2/3` 分别为绿/蓝/白 |
| `ap_cmd key_lcd close` | 关闭背光并释放显示资源 |
| `ap_cmd key_lcd open` | 重新初始化显示并恢复按键轮询 |

本工程不提供 AT 命令；只使用上述 CLI。

## 常见问题

- **只有背光、没有纯色**：断电后检查 FPC 方向和锁扣；确认烧录的是本工程最新整机固件。
- **颜色呈补色或明显反色**：确认使用的是仓库 `bsp_lcd_st7789` profile，且没有额外做软件 RGB 取反。
- **按 SW2 无反应**：不要误按 CEN/Boot 键；运行 `ap_cmd key_lcd status`，观察 `key=pressed` 是否随按压变化。
- **CLI 切色正常、物理按键无效**：优先排查 GPIO7、按键焊接和输入上拉，而不是 LCD。
- **日志乱码或命令无响应**：检查 `115200 8N1`、CRLF、`ap_cmd` 前缀和端口占用，详见[通用排障](../../docs/reference/troubleshooting.md)。

## 代码入口

- `ap/ap_main.c`：按顺序初始化总电源、LCD GPIO、SW2、媒体服务和业务模块。
- `ap/board_key_lcd.c`：显示打开、帧缓冲填色、按键轮询和 `key_lcd` CLI。
- `ap/board_key_lcd.h`：颜色控制与初始化接口。
- `components/bsp_gpio`：LCD 普通 GPIO、GPIO7 按键和消抖实现。
- `components/bsp_lcd_st7789`：240×320/320×240 profile 与 `INVON` 初始化序列。

## 可扩展方向

- 增加长按、双击或按键中断，并与当前轮询方案比较。
- 增加渐变、色条和屏幕坏点测试图。
- 统计按键次数、刷新耗时和帧缓冲占用。

## 相关示例

- `key_test`：独立验证 SW2 GPIO 中断与消抖。
- `st7789_test`：独立验证 ST7789 显示链路。
- `lcd_tp_test`：在同一屏幕上联合验证 FT6336 触摸。
- `hello_board`：基础构建、烧录和日志基线。

## 人工上板验收

必须由验收人员在真实板卡上完成以下检查，不能只以编译成功代替：

1. 上电后实际看到全屏红色，无明显花屏或补色。
2. 连续按 SW2 至少五次，确认颜色严格循环且每次日志与画面一致。
3. 执行 `status`、`next`、四个 `color` 值以及 `close`/`open`，确认返回 `CMDRSP:OK` 且硬件现象正确。

保存板卡信息、固件时间和完整启动日志后再判定通过。
