/**
 * @file board_key_lcd.c
 * @brief 板载按键控制 ST7789 LCD 纯色切换实现
 *
 * SW2(GPIO_7) 轮询检测按键，经 bk_display SPI 刷新 RGB565 全屏色块；支持 CLI 手动切换。
 */

#include "board_key_lcd.h"

#include <os/os.h>
#include <os/str.h>
#include <components/log.h>
#include <components/avdk_utils/avdk_error.h>
#include "cli.h"
#include "components/bk_display.h"
#include "frame_buffer.h"
#include "bsp_gpio.h"
#include "bsp_lcd_st7789.h"

#define TAG "key_lcd"

#define KEY_POLL_MS        50
#define KEY_TASK_PRIO      4
#define KEY_TASK_STACK     2048

#define COLOR_RED          0xF800
#define COLOR_GREEN        0x07E0
#define COLOR_BLUE         0x001F
#define COLOR_WHITE        0xFFFF

static const uint16_t s_colors[] = {COLOR_RED, COLOR_GREEN, COLOR_BLUE, COLOR_WHITE};
static const char *const s_color_names[] = {"red", "green", "blue", "white"};

static bk_display_ctlr_handle_t s_lcd_handle = NULL;
static uint8_t s_color_idx = 0;
static volatile bool s_key_task_running = false;
static beken_thread_t s_key_thread = NULL;

static bk_display_spi_ctlr_config_t s_spi_cfg = {
    .lcd_device = NULL,      // 运行时由 bsp_lcd_st7789_get 填充
    .spi_id     = 1,
    .dc_pin     = BOARD_LCD_DC_PIN,
    .reset_pin  = BOARD_LCD_RST_PIN,
    .te_pin     = 0,
};

static bk_err_t disp_frame_free_cb(void *args)
{
    frame_buffer_display_free((frame_buffer_t *)args);
    return BK_OK;
}

static void fill_color(frame_buffer_t *fb, uint16_t color)
{
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;

    for (uint32_t i = 0; i < fb->size; i += 2) {
        fb->frame[i]     = hi;
        fb->frame[i + 1] = lo;
    }
}

static avdk_err_t lcd_open(void)
{
    avdk_err_t ret;

    if (s_lcd_handle) {
        return AVDK_ERR_OK;
    }

    ret = bk_display_spi_new(&s_lcd_handle, &s_spi_cfg);
    if (ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "bk_display_spi_new failed: %d\r\n", ret);
        return ret;
    }

    board_gpio_set_high(BOARD_LCD_PWR_PIN);
    ret = bk_display_open(s_lcd_handle);
    if (ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "bk_display_open failed: %d\r\n", ret);
        bk_display_delete(s_lcd_handle);
        s_lcd_handle = NULL;
        board_gpio_set_low(BOARD_LCD_PWR_PIN);
        return ret;
    }

    board_gpio_set_low(BOARD_LCD_BL_PIN);

    return AVDK_ERR_OK;
}

static void lcd_close(void)
{
    beken_thread_t key_thread = s_key_thread;
    s_key_task_running = false;
    if (key_thread) {
        rtos_thread_join(&key_thread);
        s_key_thread = NULL;
    }

    if (s_lcd_handle) {
        board_gpio_set_high(BOARD_LCD_BL_PIN);
        bk_display_close(s_lcd_handle);
        bk_display_delete(s_lcd_handle);
        s_lcd_handle = NULL;
    }
    board_gpio_set_low(BOARD_LCD_PWR_PIN);
}

static avdk_err_t lcd_flush_current(void)
{
    if (!s_lcd_handle) {
        return AVDK_ERR_GENERIC;
    }

    uint32_t frame_len = s_spi_cfg.lcd_device->width * s_spi_cfg.lcd_device->height * 2;
    frame_buffer_t *fb = frame_buffer_display_malloc(frame_len);
    if (!fb) {
        BK_LOGE(TAG, "frame buffer malloc failed\r\n");
        return AVDK_ERR_GENERIC;
    }

    fb->fmt = PIXEL_FMT_RGB565;
    fb->width = s_spi_cfg.lcd_device->width;
    fb->height = s_spi_cfg.lcd_device->height;
    fill_color(fb, s_colors[s_color_idx % (sizeof(s_colors) / sizeof(s_colors[0]))]);

    avdk_err_t ret = bk_display_flush(s_lcd_handle, fb, disp_frame_free_cb);
    if (ret != AVDK_ERR_OK) {
        frame_buffer_display_free(fb);
    }
    return ret;
}

/**
 * @brief 切换到指定索引的纯色并刷新屏幕
 *
 * @param index 颜色索引 0=红、1=绿、2=蓝、3=白（超出范围取模）
 */
void board_key_lcd_set_color_index(uint8_t index)
{
    s_color_idx = index % (sizeof(s_colors) / sizeof(s_colors[0]));
    if (lcd_flush_current() == AVDK_ERR_OK) {
        BK_LOGI(TAG, "color -> %s\r\n", s_color_names[s_color_idx]);
    }
}

/**
 * @brief 获取当前颜色索引
 *
 * @return 当前颜色索引 0～3
 */
uint8_t board_key_lcd_get_color_index(void)
{
    return s_color_idx;
}

/** @brief 切换到下一预设纯色并刷新屏幕 */
void board_key_lcd_next_color(void)
{
    board_key_lcd_set_color_index(s_color_idx + 1);
}

static void key_poll_task(void *arg)
{
    bool key_last = false;

    while (s_key_task_running) {
        bool pressed = board_key_is_pressed();

        if (pressed && !key_last) {
            board_key_lcd_next_color();
        }
        key_last = pressed;
        rtos_delay_milliseconds(KEY_POLL_MS);
    }
    s_key_thread = NULL;
    rtos_delete_thread(NULL);
}

static bk_err_t key_poll_start(void)
{
    if (s_key_task_running) {
        return BK_OK;
    }
    s_key_task_running = true;
    bk_err_t ret = rtos_create_thread(&s_key_thread, KEY_TASK_PRIO, "key_poll",
                                      key_poll_task, KEY_TASK_STACK, NULL);
    if (ret != BK_OK) {
        s_key_task_running = false;
        s_key_thread = NULL;
    }
    return ret;
}

/**
 * @brief 初始化 ST7789 显示并启动按键轮询线程
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功
 * @retval BK_FAIL LCD 打开、首帧刷新或按键线程创建失败
 */
bk_err_t board_key_lcd_init(void)
{
    // 竖屏 240x320，64M；本板屏需 INVON 反相（组件内已固化）
    bsp_lcd_st7789_cfg_t lcd_cfg = {
        .landscape = false,
        .mirror_x  = false,
        .mirror_y  = false,
        .clk       = LCD_QSPI_64M,
    };
    s_spi_cfg.lcd_device = bsp_lcd_st7789_get(&lcd_cfg);

    avdk_err_t ret = lcd_open();
    if (ret != AVDK_ERR_OK) {
        return BK_FAIL;
    }

    s_color_idx = 0;
    if (lcd_flush_current() != AVDK_ERR_OK || key_poll_start() != BK_OK) {
        BK_LOGE(TAG, "initial display or key thread failed\r\n");
        lcd_close();
        return BK_FAIL;
    }
    BK_LOGI(TAG, "READY: press SW2 to cycle red/green/blue/white\r\n");
    return BK_OK;
}

/** @brief 关闭 LCD 并停止按键轮询线程 */
void board_key_lcd_deinit(void)
{
    lcd_close();
}

static void cli_key_lcd_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
    const char *msg = CLI_CMD_RSP_ERROR;

    if (argc < 2) {
        goto exit;
    }

    if (os_strcmp(argv[1], "next") == 0) {
        board_key_lcd_next_color();
        msg = CLI_CMD_RSP_SUCCEED;
    } else if (os_strcmp(argv[1], "color") == 0 && argc >= 3) {
        uint8_t idx = (uint8_t)os_strtoul(argv[2], NULL, 10);
        board_key_lcd_set_color_index(idx);
        msg = CLI_CMD_RSP_SUCCEED;
    } else if (os_strcmp(argv[1], "status") == 0) {
        BK_LOGI(TAG, "color=%s(%u) key=%s lcd=%s\r\n",
                s_color_names[s_color_idx], s_color_idx,
                board_key_is_pressed() ? "pressed" : "released",
                s_lcd_handle ? "open" : "closed");
        msg = CLI_CMD_RSP_SUCCEED;
    } else if (os_strcmp(argv[1], "close") == 0) {
        board_key_lcd_deinit();
        msg = CLI_CMD_RSP_SUCCEED;
    } else if (os_strcmp(argv[1], "open") == 0) {
        if (board_key_lcd_init() == BK_OK) {
            msg = CLI_CMD_RSP_SUCCEED;
        }
    }

exit:
    os_memcpy(pcWriteBuffer, msg, os_strlen(msg));
}

static const struct cli_command s_key_lcd_cmds[] = {
    {"key_lcd", "open/close/next/color <0-3>/status", cli_key_lcd_cmd},
};

/**
 * @brief 注册 `key_lcd` CLI 命令
 *
 * @return cli_register_commands 返回值，0 表示成功
 */
int board_key_lcd_cli_init(void)
{
    return cli_register_commands(s_key_lcd_cmds,
                                 sizeof(s_key_lcd_cmds) / sizeof(s_key_lcd_cmds[0]));
}
