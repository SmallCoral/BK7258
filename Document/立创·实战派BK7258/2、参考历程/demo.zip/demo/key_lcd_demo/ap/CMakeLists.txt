set(incs .)
set(srcs ap_main.c board_key_lcd.c)

set(priv_req media_service multimedia bk_display bsp_gpio bsp_lcd_st7789)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
