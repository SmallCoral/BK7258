/**
 * @file ap_main.c
 * @brief 板载按键控制 LCD 纯色切换演示工程 AP 入口
 *
 * 板载 SW2(GPIO_7) 每按一次，SPI 屏在红/绿/蓝/白之间切换；引脚见 board_design/pinmap.md。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>
#include "bsp_gpio.h"
#include "board_key_lcd.h"

#define TAG "key_lcd_demo"

/**
 * @brief AP 入口：初始化系统、板级 GPIO、LCD 与按键服务
 *
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }
    // 板级 GPIO：先上总 3V3，再配 LCD 与按键（本工程只用 LCD + KEY）
    if (bsp_gpio_init_power_master() != BK_OK ||
        bsp_gpio_init_lcd() != BK_OK ||
        bsp_gpio_init_key() != BK_OK) {
        BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
        return -1;
    }
    if (media_service_init() != BK_OK ||
        board_key_lcd_init() != BK_OK ||
        board_key_lcd_cli_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: key LCD service init\r\n");
        board_key_lcd_deinit();
        return -1;
    }
    BK_LOGI(TAG, "READY: key LCD demo\r\n");
    return 0;
}
