/**
 * @file board_key_lcd.h
 * @brief 板载按键控制 ST7789 LCD 纯色切换对外接口
 *
 * SW2(GPIO_7) 按下或 CLI 触发时在红/绿/蓝/白四色间循环；SPI 屏引脚见 board_design/pinmap.md。
 */

#pragma once

#include <common/bk_err.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 ST7789 显示并启动按键轮询线程
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功
 * @retval BK_FAIL LCD 打开、首帧刷新或按键线程创建失败
 */
bk_err_t board_key_lcd_init(void);

/** @brief 关闭 LCD 并停止按键轮询线程 */
void board_key_lcd_deinit(void);

/** @brief 切换到下一预设纯色并刷新屏幕 */
void board_key_lcd_next_color(void);

/**
 * @brief 切换到指定索引的纯色并刷新屏幕
 *
 * @param index 颜色索引 0=红、1=绿、2=蓝、3=白（超出范围取模）
 */
void board_key_lcd_set_color_index(uint8_t index);

/**
 * @brief 获取当前颜色索引
 *
 * @return 当前颜色索引 0～3
 */
uint8_t board_key_lcd_get_color_index(void);

/**
 * @brief 注册 `key_lcd` CLI 命令
 *
 * @return cli_register_commands 返回值，0 表示成功
 */
int board_key_lcd_cli_init(void);

#ifdef __cplusplus
}
#endif
