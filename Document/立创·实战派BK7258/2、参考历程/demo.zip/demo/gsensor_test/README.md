# gsensor_test：SC7A20 三轴加速度计自检

本 README 依据工程当前的 C、CMake、config、分区文件及 SC7A20 板级组件编写。日志和数值是源码提供的观察点；本次文档整理不等同于上板实测，最终需人工改变板卡姿态并验收。

## 示例目标

给板载 SC7A20 上电，通过共享模拟 I2C 总线读取 `WHO_AM_I`，并提供三轴采样、倾角计算和运动中断测试。上电线程自动执行一次探活及总线诊断。

## 学习内容

- 使用板级总线常量访问共享模拟 I2C，而不是硬编码硬件 I2C 控制器。
- 读取 SC7A20 寄存器并把原始值换算为 mg。
- 用三轴数据计算 pitch/roll。
- 配置传感器运动中断，并在 GPIO 中断后由任务读取数据。

## 硬件要求和引脚

- 立创 BK7258 开发板及扩展板、板载 SC7A20、USB 数据线。
- SC7A20 使用 GPIO42/43 上的共享模拟 I2C，总线还可能连接触摸和摄像头配置口；INT1 使用 `BOARD_GSENSOR_INT_PIN`，传感器电源使用高有效的 `BOARD_SENSOR_PWR_PIN`。
- 当前运行时权威常量为 7 位地址 `0x19`、100 kHz；不要照搬 SDK 默认地址 `0x18`，也不要使用硬件 `I2C_ID_1`。
- 完整引脚事实以[板卡唯一权威映射](../../board_design/pinmap.md)、[`board_i2c.h`](../../components/board_cfg/board_i2c.h)、[`bsp_gpio.h`](../../components/bsp_gpio/bsp_gpio.h)为准，本文不维护完整映射表。

## 软件配置

- AP CMake 依赖 `bk_common`、`bsp_gpio` 和 `bsp_sensor_sc7a20`。
- 当前配置已启用 `CONFIG_I2C`、`CONFIG_SIM_I2C`、`CONFIG_SIM_I2C_HW_BOARD_V3`，模拟 I2C1 的 SDA/SCL 分别配置为 GPIO43/GPIO42。
- `usr_gpio_cfg.h` 转发统一板级映射；模拟 I2C 驱动运行时会接管对应 GPIO。
- 当前标准 AP/CP/OTA 分区及 16 MiB PSRAM 布局无需修改。

## 编译命令

在本工程目录执行其一：

```bash
make bk7258
```

```bash
./dbuild.sh bk7258
```

默认目录布局为 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。需要排除旧产物时先执行 `make clean`。

## 固件位置

整机烧录文件为：

```text
build/bk7258/gsensor_test/package/all-app.bin
```

烧录时选择 `package/all-app.bin`，不要选择 AP、CP 或分区中间镜像。

## 烧录和运行步骤

1. 保持扩展板和传感器硬件连接完整，用 USB 数据线连接开发板。
2. 按[固件烧录参考](../../docs/reference/firmware-download.md)烧录上述固件。
3. 释放下载串口，以 `115200 8N1`、无流控打开终端；详见[串口控制台参考](../../docs/reference/serial-console.md)。
4. 短按复位键，等待自动探活和 I2C 扫描/寄存器诊断完成。
5. 依次执行读取、倾角和运动中断命令；平放、翻面、沿不同轴倾斜并晃动板卡。
6. 结束运动中断测试时发送关闭命令。

## 预期日志或现象

探活成功的核心标志为：

```text
READY: SC7A20 CLI and selftest
PROBE OK, WHO_AM_I=0x11 (SC7A20 在线)
```

连续读取会出现 `[S2/S3]` 的 `raw(...)` 和 `mg(...)`，倾角读取会出现 `[S4] pitch=... roll=...`，运动中断会出现 `MOTION #...`。人工硬件验收应确认：

- 静止平放时总加速度应主要落在重力方向，翻面或旋转后主轴随姿态变化；
- pitch/roll 随倾斜方向变化；
- 打开运动中断后晃动能触发，关闭后不再新增运动日志。

这些是人工观察标准，本文不宣称本次修改已完成上板验证或给出固定姿态数值。

## CLI/AT 操作方法

串口命令注册在 AP，需从 CP Shell 加 `ap_cmd` 前缀，行尾使用 CRLF：

```text
ap_cmd gs_test id
ap_cmd gs_test scan
ap_cmd gs_test read
ap_cmd gs_test read 50
ap_cmd gs_test angle 20
ap_cmd gs_test int
ap_cmd gs_test int off
```

- `id`：读取并校验 `WHO_AM_I=0x11`。
- `scan`：扫描共享模拟 I2C，并打印关键寄存器。
- `read [n]`：输出 n 组三轴原始值和 mg，默认 20 组。
- `angle [n]`：输出 n 组 pitch/roll，默认 20 组。
- `int` / `int off`：打开/关闭运动中断。
- 本工程不是 AT 固件，不使用 `AT+...` 命令。

## 常见问题

- `WHO_AM_I` 读失败或为 `0x00`：确认使用 `BSP_BOARD_I2C_BUS_ID` 和地址 `0x19`，并检查 GPIO24 传感器电源、GPIO42/43 总线。
- 探活成功但数据不变化：确认执行了 `read`/`angle`，并实际改变板卡姿态；检查第一条 I2C 返回错误。
- 运动中断不触发：先执行 `ap_cmd gs_test int`，再明显晃动板卡，并核对 GPIO44 输入和中断接线。
- 命令无响应：确认 `ap_cmd` 前缀、CRLF 行尾和串口未被下载工具占用。
- 通用环境、烧录和日志问题见[通用排障](../../docs/reference/troubleshooting.md)。

## 代码入口

教学调用链：

```text
AP main()
  -> bk_init()
  -> power_master -> sensor GPIO -> export IO GPIO
  -> 拉高 SENSOR_PWR 与 EXPORT_IO_PWR
  -> 注册 gs_test
  -> gs_selftest_thread()
       -> bsp_sc7a20_probe()
          -> ensure_i2c() -> 读 WHO_AM_I
       -> bsp_sc7a20_diag()

CLI read/angle
  -> start_normal(50 Hz, ±2g)
  -> 连续读 XYZ -> 换算 mg
  -> 可选 atan2/sqrt 计算 pitch/roll

CLI int
  -> 配置 SC7A20 INT1
  -> GPIO44 下降沿 ISR -> 信号量
  -> 中断任务读 INT1_SRC 与 XYZ
```

工程入口位于 [`ap/ap_main.c`](ap/ap_main.c)，传感器实现位于 [`components/bsp_sensor_sc7a20`](../../components/bsp_sensor_sc7a20/)。

## 可扩展方向

- 增加零偏标定、低通滤波和姿态稳定性统计。
- 调整量程、采样率、运动阈值和持续时间，并建立可重复的人工验收动作。
- 将采样送入图形界面、网络上报或低功耗唤醒流程。
- 为共享 I2C 上的多个器件增加并发访问压力测试。

## 相关示例

- [SC7A20 教程](../../docs/examples/peripherals/gsensor-sc7a20.md)：更完整的测试场景与诊断说明。
- [`hello_board`](../hello_board/)：先验证基础编译、烧录和串口。
- [`digital_camera`](../digital_camera/)：综合使用共享总线及多种板载外设。
- [`lcd_tp_test`](../lcd_tp_test/)：验证同一共享总线上的触摸器件。
