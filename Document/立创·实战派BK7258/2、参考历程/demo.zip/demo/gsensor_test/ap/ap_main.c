/**
 * @file ap_main.c
 * @brief SC7A20 三轴加速度计自测演示工程入口
 *
 * 传感器接法：I2C1 GPIO42/43，INT1 GPIO44，电源使能 GPIO24。
 * 上电后自动探活 WHO_AM_I，其余测试通过 `gs_test` CLI 触发：
 *   gs_test id | read [n] | angle [n] | int [off]
 */

#include "bk_private/bk_init.h"
#include <os/os.h>
#include <os/str.h>
#include <components/log.h>
#include "cli.h"
#include "bsp_gpio.h"
#include "bsp_sensor_sc7a20.h"

#define TAG "gsensor_test"

/**
 * @brief 连续读取并打印三轴加速度原始值与 mg 值
 *
 * @param n 采样次数
 */
static void gs_read_loop(uint32_t n)
{
	if (bsp_sc7a20_start_normal() != BK_OK) {
		return;
	}
	for (uint32_t i = 0; i < n; i++) {
		bsp_sc7a20_sample_t s;
		if (bsp_sc7a20_read(&s) == BK_OK) {
			BK_LOGI(TAG, "[S2/S3] #%u  raw(%d,%d,%d)  mg(%d,%d,%d)\r\n",
				(unsigned)i, s.raw_x, s.raw_y, s.raw_z, s.mg_x, s.mg_y, s.mg_z);
		}
		rtos_delay_milliseconds(100);
	}
	BK_LOGI(TAG, "[S2/S3] read done (%u samples)\r\n", (unsigned)n);
}

/**
 * @brief 连续读取并打印 pitch/roll 倾角（度）
 *
 * @param n 采样次数
 */
static void gs_angle_loop(uint32_t n)
{
	if (bsp_sc7a20_start_normal() != BK_OK) {
		return;
	}
	for (uint32_t i = 0; i < n; i++) {
		int pitch = 0, roll = 0;
		if (bsp_sc7a20_read_angle(&pitch, &roll) == BK_OK) {
			BK_LOGI(TAG, "[S4] #%u  pitch=%d  roll=%d (deg)\r\n",
				(unsigned)i, pitch, roll);
		}
		rtos_delay_milliseconds(200);
	}
	BK_LOGI(TAG, "[S4] angle done (%u samples)\r\n", (unsigned)n);
}

/**
 * @brief `gs_test` CLI 命令处理
 *
 * @param pcWriteBuffer   响应写入缓冲区（本命令直接打日志，未使用）
 * @param xWriteBufferLen 缓冲区长度
 * @param argc            参数个数
 * @param argv            参数列表
 */
static void cli_gs_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
	if (argc < 2) {
		BK_LOGI(TAG, "usage: gs_test id | read [n] | angle [n] | int [off]\r\n");
		return;
	}

	if (os_strcmp(argv[1], "id") == 0) {
		bsp_sc7a20_probe();
	} else if (os_strcmp(argv[1], "scan") == 0) {
		bsp_sc7a20_diag();
	} else if (os_strcmp(argv[1], "read") == 0) {
		uint32_t n = (argc >= 3) ? os_strtoul(argv[2], NULL, 10) : 0;
		if (n == 0) n = 20;   // 次数缺省/非法(含误填 [n]) 时按默认 20
		gs_read_loop(n);
	} else if (os_strcmp(argv[1], "angle") == 0) {
		uint32_t n = (argc >= 3) ? os_strtoul(argv[2], NULL, 10) : 0;
		if (n == 0) n = 20;
		gs_angle_loop(n);
	} else if (os_strcmp(argv[1], "int") == 0) {
		if (argc >= 3 && os_strcmp(argv[2], "off") == 0) {
			bsp_sc7a20_motion_int_close();
		} else {
			bsp_sc7a20_motion_int_open();
		}
	} else {
		BK_LOGI(TAG, "usage: gs_test id | read [n] | angle [n] | int [off]\r\n");
	}
}

static const struct cli_command s_gs_test_cmds[] = {
	{"gs_test", "gs_test id|read [n]|angle [n]|int [off]", cli_gs_test_cmd},
};

/**
 * @brief 上电自检线程：探活 WHO_AM_I 并打印 I2C 诊断信息
 *
 * @param arg 未使用
 */
static void gs_selftest_thread(void *arg)
{
	rtos_delay_milliseconds(500);
	BK_LOGI(TAG, "=== SC7A20 selftest: run S1 probe + diag ===\r\n");
	bsp_sc7a20_probe();   // 上电自检: 读 WHO_AM_I
	bsp_sc7a20_diag();    // 诊断: I2C 扫描 + 寄存器 dump
	BK_LOGI(TAG, "用 CLI 继续: gs_test scan / read / angle / int\r\n");
	rtos_delete_thread(NULL);
}

/**
 * @brief AP 应用入口：初始化传感器 GPIO、CLI 并启动自检线程
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}

	if (bsp_gpio_init_power_master() != BK_OK ||
	    bsp_gpio_init_sensor() != BK_OK ||
	    bsp_gpio_init_export_io() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
		return -1;
	}
	board_gpio_set_high(BOARD_SENSOR_PWR_PIN);     // GPIO24 高有效, 给 SC7A20 上电
	board_gpio_set_high(BOARD_EXPORT_IO_PWR_PIN);  // GPIO6 外扩 IO 电源 (兜底, 可能给传感器/上拉供电)
	rtos_delay_milliseconds(100);

	if (cli_register_commands(
	        s_gs_test_cmds, sizeof(s_gs_test_cmds) / sizeof(s_gs_test_cmds[0])) != BK_OK) {
		BK_LOGE(TAG, "FAIL: CLI register\r\n");
		goto fail_power;
	}

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "gs_selftest", gs_selftest_thread, 4096, NULL) != BK_OK) {
		BK_LOGE(TAG, "FAIL: selftest thread create\r\n");
		cli_unregister_commands(
			s_gs_test_cmds, sizeof(s_gs_test_cmds) / sizeof(s_gs_test_cmds[0]));
		goto fail_power;
	}

	BK_LOGI(TAG, "READY: SC7A20 CLI and selftest\r\n");
	return 0;

fail_power:
	board_gpio_set_low(BOARD_SENSOR_PWR_PIN);
	board_gpio_set_low(BOARD_EXPORT_IO_PWR_PIN);
	return -1;
}
