set(incs .)
set(srcs ap_main.c)

set(priv_req bk_common bsp_gpio bsp_sensor_sc7a20)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
