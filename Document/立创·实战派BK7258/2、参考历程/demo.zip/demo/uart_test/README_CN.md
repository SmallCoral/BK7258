# uart_test：J4 UART1 串口验证

## 示例目标

验证立创 BK7258 扩展板 J4 上 AP UART1 的发送、接收和硬件环回。

## 学习内容

- 外扩 IO 电源与 UART1 的初始化顺序。
- 115200 8N1 字符串发送和 TX 完成等待。
- J4 TX/RX 短接后的硬件环回自测。
- 通过 CP UART0 调试口向 AP CLI 下发命令。

## 硬件要求和引脚

- CP UART0 使用 GPIO10/11，经板载 CH340K 提供日志、CLI 和固件下载。
- AP UART1 使用 J4 的 GPIO0/1，作为本例被测串口。
- 环回测试需短接 J4 TX/RX；外部对测可连接 3.3 V USB-TTL。
- J4 外扩 IO 电源由 GPIO6 控制，总 3.3 V 电源由 GPIO22 控制。

## 软件配置

- UART1 参数为 115200、8 数据位、无校验、1 停止位、无流控。
- 工程直接使用统一 `bsp_gpio` 初始化板级电源。
- `ram_regions.csv` 声明完整 16 MiB PSRAM，AP PSRAM heap 为 `0x8C0000`。

## 编译命令

```bash
cd projects/uart_test
make bk7258
```

## 固件位置

`build/bk7258/uart_test/package/all-app.bin`

## 烧录和运行步骤

1. 短接 J4 TX/RX。
2. 烧录整包固件并复位开发板。
3. 打开 CP UART0，等待 `READY: uart_test`。
4. 检查自动环回结果，或使用 CLI 再次执行环回和发送测试。

## 预期日志或现象

```text
READY: uart_test
UART1 loopback PASS
```

未短接 J4 TX/RX 时自动环回会显示 `SKIP/FAIL`，但 CLI 和 UART1 发送功能仍可继续验证。

## CLI/AT 操作方法

```text
ap_cmd uart_test status
ap_cmd uart_test pwr on
ap_cmd uart_test pwr off
ap_cmd uart_test loopback
ap_cmd uart_test send hello
```

## 常见问题

- 环回失败：确认 J4 TX/RX 已可靠短接，且没有外部设备同时驱动线路。
- 外部设备收不到数据：确认双方共地并使用 3.3 V、115200 8N1。
- 看不到日志：日志和 CLI 使用 CP UART0/CH340K，不从 J4 UART1 输出。

## 代码入口

- `ap/ap_main.c`：板级上电、CLI 注册、自动环回任务和 READY 日志。
- `ap/uart_test.c`：UART1 初始化、发送、环回和 CLI 实现。
- `ap/uart_test.h`：业务接口和 UART 参数。

## 可扩展方向

- 增加持续收发、吞吐率和误码率测试。
- 支持通过 CLI 修改波特率。
- 增加与外部 MCU 或传感器的协议示例。

## 相关示例

- [UART 详细文档](../../docs/examples/base/UART.md)
- `gpio_toggle_test`：扩展 GPIO 输出与 CLI 控制。
- `wifi_at_test`：基于串口 AT 命令的无线业务验证。
