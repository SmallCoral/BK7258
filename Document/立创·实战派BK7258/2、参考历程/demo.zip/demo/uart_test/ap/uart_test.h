/**
 * @file uart_test.h
 * @brief J4 UART1 收发与环回验证例程对外接口
 *
 * 使用 AP UART1（GPIO0/1）进行发送、状态查询与 TX/RX 短接环回自测。
 */

#pragma once

#include <common/bk_err.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief 被测 UART 编号（AP UART1） */
#define UART_TEST_ID    1
/** @brief UART 波特率 */
#define UART_TEST_BAUD  115200

/**
 * @brief 打开外扩 IO 电源（GPIO6），供 J4 模块供电
 *
 * @return 操作结果
 * @retval BK_OK 成功（幂等）
 */
bk_err_t uart_test_power_on(void);

/**
 * @brief 经 UART1 发送字符串
 *
 * @param text 以 '\\0' 结尾的发送内容，不可为 NULL 或空串
 * @return 操作结果
 * @retval BK_OK 发送完成
 * @retval BK_ERR_PARAM text 无效
 * @retval 其他 UART 初始化或写入失败
 */
bk_err_t uart_test_send(const char *text);

/**
 * @brief UART1 硬件环回自测（需短接 J4 TX/RX）
 *
 * @return 操作结果
 * @retval BK_OK 收发数据一致
 * @retval BK_FAIL 超时或数据不匹配
 */
bk_err_t uart_test_loopback(void);

/** @brief 打印 UART1 与外扩电源当前状态到日志 */
void uart_test_print_status(void);

/**
 * @brief 注册 `uart_test` CLI 命令
 *
 * @return cli_register_commands 返回值，0 表示成功
 */
int uart_test_cli_init(void);

#ifdef __cplusplus
}
#endif
