/**
 * @file ap_main.c
 * @brief J4 UART1 环回自测演示工程入口
 *
 * 初始化板级电源与 UART1 CLI，后台线程尝试环回自测（需短接 J4 TX/RX）。
 */

#include "bk_private/bk_init.h"
#include <os/os.h>
#include <components/log.h>

#include "bsp_gpio.h"
#include "uart_test.h"

#define TAG "uart_test"

/**
 * @brief 上电延迟后执行 UART1 环回自测并打印 CLI 提示
 *
 * @param arg 未使用
 */
static void uart_test_boot_task(void *arg)
{
	(void)arg;

	rtos_delay_milliseconds(800);

	BK_LOGI(TAG, "=== uart_test: UART1 selftest ===\r\n");
	uart_test_print_status();

	if (uart_test_loopback() == BK_OK) {
		BK_LOGI(TAG, "boot loopback: PASS (J4 TX/RX shorted)\r\n");
	} else {
		BK_LOGW(TAG, "boot loopback: SKIP/FAIL -- short J4 TX/RX then: ap_cmd uart_test loopback\r\n");
	}

	BK_LOGI(TAG, "CLI: ap_cmd uart_test status | ap_cmd uart_test send hello\r\n");
	rtos_delete_thread(NULL);
}

/**
 * @brief AP 应用入口：初始化电源、CLI 并启动环回自测线程
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}
	if (bsp_gpio_init_power_master() != BK_OK ||
	    bsp_gpio_init_export_io() != BK_OK ||
	    uart_test_power_on() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board power init\r\n");
		return -1;
	}
	if (uart_test_cli_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: CLI register\r\n");
		return -1;
	}

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "uart_boot", uart_test_boot_task, 2048, NULL) != BK_OK) {
		BK_LOGE(TAG, "FAIL: selftest thread create\r\n");
		return -1;
	}

	BK_LOGI(TAG, "READY: uart_test\r\n");
	return 0;
}
