/**
 * @file uart_test.c
 * @brief J4 UART1 收发与环回验证例程实现
 *
 * 打开外扩 IO 电源后初始化 UART1，支持 CLI 发送、状态查询与 TX/RX 短接环回自测。
 */

#include "uart_test.h"
#include "bsp_gpio.h"

#include <os/os.h>
#include <os/str.h>
#include <os/mem.h>
#include <components/log.h>
#include <driver/uart.h>
#include "bk_private/bk_uart.h"
#include "cli.h"

#define TAG "uart_test"

#define LOOPBACK_PATTERN    "UART_TEST_LOOP"
#define LOOPBACK_TIMEOUT_MS 1000

static bool s_export_pwr_on = false;

bk_err_t uart_test_power_on(void)
{
	if (!s_export_pwr_on) {
		board_gpio_set_high(BOARD_EXPORT_IO_PWR_PIN);
		rtos_delay_milliseconds(50);
		s_export_pwr_on = true;
		BK_LOGI(TAG, "export IO power ON (GPIO_%d)\r\n", BOARD_EXPORT_IO_PWR_PIN);
	}
	return BK_OK;
}

/**
 * @brief 确保 UART1 已初始化并使能 RX 中断
 *
 * @return 操作结果
 * @retval BK_OK UART1 就绪
 */
static bk_err_t uart1_ensure_ready(void)
{
	uart_id_t id = UART_TEST_ID;

	if (!bk_uart_is_in_used(id)) {
		uart_config_t cfg;

		os_memset(&cfg, 0, sizeof(cfg));
		cfg.baud_rate = UART_TEST_BAUD;
		cfg.data_bits = UART_DATA_8_BITS;
		cfg.parity = UART_PARITY_NONE;
		cfg.stop_bits = UART_STOP_BITS_1;
		cfg.flow_ctrl = UART_FLOWCTRL_DISABLE;
		cfg.src_clk = UART_SCLK_XTAL_26M;
		cfg.rx_dma_en = UART_DMA_DISABLE;
		cfg.tx_dma_en = UART_DMA_DISABLE;

		BK_RETURN_ON_ERR(bk_uart_driver_init());
		BK_RETURN_ON_ERR(bk_uart_init(id, &cfg));
		BK_LOGI(TAG, "UART%d init %d bps\r\n", id, UART_TEST_BAUD);
	}

	bk_uart_set_enable_rx(id, true);
	bk_uart_enable_rx_interrupt(id);
	return BK_OK;
}

/** @brief 排空 UART1 硬件 RX FIFO */
static void uart1_drain_hw_rx(void)
{
	uint8_t ch;

	while (uart_read_byte_ex(UART_TEST_ID, &ch) == 0) {
	}
}

/**
 * @brief 带超时从 UART1 硬件 FIFO 读取指定字节数
 *
 * @param buf         接收缓冲区
 * @param want        期望读取字节数
 * @param timeout_ms  超时时间（ms）
 * @return 实际读到的字节数
 */
static int uart1_read_hw_timeout(uint8_t *buf, int want, uint32_t timeout_ms)
{
	uint32_t elapsed = 0;
	int got = 0;

	while (got < want && elapsed < timeout_ms) {
		uint8_t ch;

		if (uart_read_byte_ex(UART_TEST_ID, &ch) == 0) {
			buf[got++] = ch;
		} else {
			rtos_delay_milliseconds(2);
			elapsed += 2;
		}
	}

	return got;
}

bk_err_t uart_test_send(const char *text)
{
	int len;

	if (!text || !text[0]) {
		return BK_ERR_PARAM;
	}

	BK_RETURN_ON_ERR(uart_test_power_on());
	BK_RETURN_ON_ERR(uart1_ensure_ready());

	len = (int)os_strlen(text);
	BK_RETURN_ON_ERR(bk_uart_write_bytes(UART_TEST_ID, text, (uint32_t)len));
	bk_uart_wait_tx_over(UART_TEST_ID);
	BK_LOGI(TAG, "UART1 sent %d bytes\r\n", len);
	return BK_OK;
}

bk_err_t uart_test_loopback(void)
{
	const char *pat = LOOPBACK_PATTERN;
	uint8_t rx[32];
	int pat_len = (int)os_strlen(pat);
	int got;

	BK_RETURN_ON_ERR(uart_test_power_on());
	BK_RETURN_ON_ERR(uart1_ensure_ready());

	bk_uart_disable_sw_fifo(UART_TEST_ID);
	uart1_drain_hw_rx();

	BK_RETURN_ON_ERR(bk_uart_write_bytes(UART_TEST_ID, pat, (uint32_t)pat_len));
	bk_uart_wait_tx_over(UART_TEST_ID);

	os_memset(rx, 0, sizeof(rx));
	got = uart1_read_hw_timeout(rx, pat_len, LOOPBACK_TIMEOUT_MS);

	bk_uart_enable_sw_fifo(UART_TEST_ID);

	if (got != pat_len) {
		BK_LOGE(TAG, "loopback timeout: got %d, expect %d\r\n", got, pat_len);
		BK_LOGE(TAG, "hint: short J4 TX/RX, 115200 8N1\r\n");
		return BK_FAIL;
	}

	if (os_memcmp(rx, pat, (uint32_t)pat_len) != 0) {
		BK_LOGE(TAG, "loopback data mismatch\r\n");
		return BK_FAIL;
	}

	BK_LOGI(TAG, "UART1 loopback PASS\r\n");
	return BK_OK;
}

void uart_test_print_status(void)
{
	BK_LOGI(TAG, "export_pwr=%s uart%d_in_use=%d baud=%d\r\n",
	        s_export_pwr_on ? "on" : "off",
	        UART_TEST_ID,
	        bk_uart_is_in_used(UART_TEST_ID),
	        UART_TEST_BAUD);
	BK_LOGI(TAG, "pins: TX=GPIO_0 RX=GPIO_1 (J4)\r\n");
}

/**
 * @brief `uart_test` CLI 命令处理
 *
 * @param pcWriteBuffer   响应写入缓冲区
 * @param xWriteBufferLen 缓冲区长度
 * @param argc            参数个数
 * @param argv            参数列表
 */
static void cli_uart_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
	const char *msg = CLI_CMD_RSP_ERROR;

	(void)xWriteBufferLen;

	if (argc < 2) {
		goto exit;
	}

	if (os_strcmp(argv[1], "status") == 0) {
		uart_test_print_status();
		msg = CLI_CMD_RSP_SUCCEED;
	} else if (os_strcmp(argv[1], "pwr") == 0 && argc >= 3) {
		if (os_strcmp(argv[2], "on") == 0) {
			uart_test_power_on();
			msg = CLI_CMD_RSP_SUCCEED;
		} else if (os_strcmp(argv[2], "off") == 0) {
			board_gpio_set_low(BOARD_EXPORT_IO_PWR_PIN);
			s_export_pwr_on = false;
			msg = CLI_CMD_RSP_SUCCEED;
		}
	} else if (os_strcmp(argv[1], "loopback") == 0) {
		if (uart_test_loopback() == BK_OK) {
			msg = CLI_CMD_RSP_SUCCEED;
		}
	} else if (os_strcmp(argv[1], "send") == 0 && argc >= 3) {
		if (uart_test_send(argv[2]) == BK_OK) {
			msg = CLI_CMD_RSP_SUCCEED;
		}
	}

exit:
	os_memcpy(pcWriteBuffer, msg, os_strlen(msg));
}

static const struct cli_command s_cmds[] = {
	{"uart_test", "status | pwr on|off | loopback | send <s>", cli_uart_test_cmd},
};

int uart_test_cli_init(void)
{
	return cli_register_commands(s_cmds, sizeof(s_cmds) / sizeof(s_cmds[0]));
}
