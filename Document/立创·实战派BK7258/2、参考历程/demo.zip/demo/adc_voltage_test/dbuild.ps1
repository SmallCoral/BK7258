# Copyright 2026 BEKEN Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

$env:BK_SOLUTION_MODE = 1
$env:SOLUTION_DIR = [System.IO.Path]::GetFullPath("..\..")

function Check-SdkDir {
    param (
        [string]$SdkDir
    )
    
    $dbuildPath = Join-Path -Path $SdkDir -ChildPath "tools\build_tools\docker_build\dbuild.sh"
    
    if (-not (Test-Path $dbuildPath)) {
        Write-Host "sdk directory not found: $SdkDir, please set SDK_DIR environment variable" -ForegroundColor Red
        exit 1
    }
}

function Main {
    if ([string]::IsNullOrEmpty($env:SDK_DIR)) {
        $env:SDK_DIR = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
    }
    
    $currentDir = (Get-Location).Path
    $currentDir = [System.IO.Path]::GetFullPath($currentDir)
    
    $projectDir = $currentDir.Replace($solutionDir + "\", "").Replace("\", "/")
    $env:PROJECT_DIR = $projectDir
    $dockerBuildScript = Join-Path -Path $env:SDK_DIR -ChildPath "dbuild.ps1"
    
    Check-SdkDir -SdkDir $env:SDK_DIR
    
    & $dockerBuildScript "$args"
}

Main "$args"
