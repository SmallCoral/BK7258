/**
 * @file ap_main.c
 * @brief ADC4 5V 检测电压采样演示工程入口
 *
 * 初始化板级电源后启动 ADC4 周期采样，串口打印 VBUS 检测电压。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>

#include "adc_voltage.h"
#include "bsp_gpio.h"

#define TAG "adc_volt"

/**
 * @brief AP 应用入口：初始化电源与 ADC4 采样
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}
	if (bsp_gpio_init_power_master() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board power init\r\n");
		return -1;
	}
	if (adc_voltage_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: ADC4 init\r\n");
		return -1;
	}

	BK_LOGI(TAG, "READY: adc_voltage_test\r\n");
	return 0;
}
