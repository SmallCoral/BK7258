/**
 * @file adc_voltage.h
 * @brief ADC4（GPIO28 / 5V_DET）电压采样例程对外接口
 *
 * 通过分压电阻读取 USB VBUS 5V 检测脚，周期性打印 raw、引脚电压与反推 VBUS。
 */

#pragma once

#include <common/bk_err.h>
#include <driver/hal/hal_adc_types.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief ADC 通道：GPIO28（5V_DET） */
#define ADC4_5V_DET_CHAN           ADC_4

/** @brief 分压上臂电阻（kΩ），VBUS → 节点 */
#define ADC4_DIVIDER_TOP_KOHM      100U
/** @brief 分压下臂电阻（kΩ），节点 → GND；V_pin = VBUS × R_bot / (R_top + R_bot) */
#define ADC4_DIVIDER_BOT_KOHM      200U

/** @brief 轮询采样周期（ms） */
#define ADC4_POLL_INTERVAL_MS      1000

/** @brief 单次 ADC4 采样结果 */
typedef struct {
	uint16_t raw;      /**< SARADC 原始读数 */
	uint16_t pin_mv;   /**< GPIO28 引脚电压（mV） */
	uint32_t vbus_mv;  /**< 按分压比反推的 VBUS（mV） */
} adc4_sample_t;

/**
 * @brief 初始化 ADC4 GPIO 并启动周期采样定时器
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功
 * @retval 其他  GPIO/ADC/定时器失败
 */
bk_err_t adc_voltage_init(void);

#ifdef __cplusplus
}
#endif
