set(incs .)
set(srcs ap_main.c adc_voltage.c)

set(priv_req bsp_gpio driver)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
