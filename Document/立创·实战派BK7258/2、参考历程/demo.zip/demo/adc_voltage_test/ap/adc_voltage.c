/**
 * @file adc_voltage.c
 * @brief ADC4（GPIO28 / 5V_DET）电压采样例程实现
 *
 * 周期性读取 5V 检测分压脚，打印 SARADC 原始值、引脚电压与反推 VBUS。
 */

#include "adc_voltage.h"

#include <components/log.h>
#include <driver/adc.h>
#include <os/mem.h>
#include <os/os.h>

#define TAG "adc_volt"

#define ADC_READ_TIMEOUT_MS        1000

static beken_timer_t s_poll_timer;

/**
 * @brief 按分压比将 GPIO28 引脚电压换算为 VBUS
 *
 * @param pin_mv GPIO28 引脚电压（mV）
 * @return 反推的 VBUS 电压（mV）
 */
static uint32_t adc4_pin_to_vbus_mv(uint16_t pin_mv)
{
	return (uint32_t)pin_mv * (ADC4_DIVIDER_TOP_KOHM + ADC4_DIVIDER_BOT_KOHM)
	       / ADC4_DIVIDER_BOT_KOHM;
}

/**
 * @brief 单次读取 ADC4 并填充采样结果
 *
 * @param out 输出采样结构，不可为 NULL
 * @return 操作结果
 * @retval BK_OK 读取成功，out 有效
 * @retval BK_ERR_PARAM out 为 NULL
 * @retval 其他 ADC 驱动错误
 */
static bk_err_t adc4_read_once(adc4_sample_t *out)
{
	bk_err_t ret;
	adc_config_t cfg;
	uint16_t sample = 0;

	if (!out) {
		return BK_ERR_PARAM;
	}

	ret = bk_adc_acquire();
	if (ret != BK_OK) {
		return ret;
	}

	ret = bk_adc_init(ADC4_5V_DET_CHAN);
	if (ret != BK_OK) {
		goto out_release;
	}

	os_memset(&cfg, 0, sizeof(cfg));
	cfg.chan = ADC4_5V_DET_CHAN;
	cfg.adc_mode = ADC_CONTINUOUS_MODE;
	cfg.src_clk = ADC_SCLK_XTAL_26M;
	cfg.clk = 0x30A0C5;
	cfg.saturate_mode = ADC_SATURATE_MODE_3;
	cfg.steady_ctrl = 7;
	cfg.adc_filter = 0;
	cfg.sample_rate = 0;
	cfg.is_open = 0;
	cfg.vol_div = ADC_VOL_DIV_NONE;

	ret = bk_adc_set_config(&cfg);
	if (ret != BK_OK) {
		goto out_deinit;
	}

	bk_adc_enable_bypass_clalibration();

	ret = bk_adc_start();
	if (ret != BK_OK) {
		goto out_deinit;
	}

	ret = bk_adc_read(&sample, ADC_READ_TIMEOUT_MS);
	bk_adc_stop();
	if (ret != BK_OK) {
		goto out_deinit;
	}

	out->raw = sample;
	out->pin_mv = bk_adc_data_calculate(sample, ADC4_5V_DET_CHAN);
	out->vbus_mv = adc4_pin_to_vbus_mv(out->pin_mv);

out_deinit:
	bk_adc_deinit(ADC4_5V_DET_CHAN);
out_release:
	bk_adc_release();
	return ret;
}

/**
 * @brief 轮询定时器回调，读取并打印 ADC4 电压
 *
 * @param arg 未使用
 */
static void adc4_poll_cb(void *arg)
{
	(void)arg;

	adc4_sample_t sample = {0};
	bk_err_t ret = adc4_read_once(&sample);

	if (ret == BK_OK) {
		BK_LOGI(TAG, "ADC4 raw=%u pin=%umV vbus=%umV\r\n",
		        sample.raw, sample.pin_mv, sample.vbus_mv);
	} else {
		BK_LOGE(TAG, "ADC4 read fail ret=%d\r\n", ret);
	}
}

bk_err_t adc_voltage_init(void)
{
	BK_RETURN_ON_ERR(bk_adc_chan_init_gpio(ADC4_5V_DET_CHAN));

	if (!rtos_is_timer_init(&s_poll_timer)) {
		BK_RETURN_ON_ERR(rtos_init_timer(&s_poll_timer, ADC4_POLL_INTERVAL_MS,
		                                 adc4_poll_cb, NULL));
	}

	BK_RETURN_ON_ERR(rtos_start_timer(&s_poll_timer));
	adc4_poll_cb(NULL);

	BK_LOGI(TAG, "5V_DET ADC4(GPIO28) every %ums, divider %uk/%uk\r\n",
	        ADC4_POLL_INTERVAL_MS,
	        ADC4_DIVIDER_TOP_KOHM, ADC4_DIVIDER_BOT_KOHM);
	return BK_OK;
}
