// 采用扩展板统一引脚映射；运行时会解除 GPIO20 的 I2C0_SCL 复用。
#include "usr_gpio_cfg_default.h"
