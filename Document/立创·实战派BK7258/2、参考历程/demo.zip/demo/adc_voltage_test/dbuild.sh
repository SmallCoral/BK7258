#!/bin/bash
# Copyright 2026 BEKEN Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

export BK_SOLUTION_MODE=1
export SOLUTION_DIR=$(realpath ../..)

function check_sdk_dir() {
    if [ ! -f $1/tools/build_tools/docker_build/dbuild.sh ]; then
        echo "sdk directory not found: $1, please set SDK_DIR environment variable"
        exit 1
    fi
}


function main() {
    SDK_DIR=${SDK_DIR:-$(realpath ../..)}

    CURRENT_DIR=$(realpath .)
    PROJECT_DIR=$(realpath --relative-to="$SOLUTION_DIR" "$CURRENT_DIR")
    if [ "$PROJECT_DIR" == "." ]; then
        PROJECT_DIR=
    fi
    
    export PROJECT_DIR=$PROJECT_DIR
    DOCKER_BUILD_SRCIPT=${SDK_DIR}/dbuild.sh

    check_sdk_dir $SDK_DIR

    $DOCKER_BUILD_SRCIPT $@
}

main $@
