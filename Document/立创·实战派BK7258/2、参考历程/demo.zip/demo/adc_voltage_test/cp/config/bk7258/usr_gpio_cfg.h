// CP 侧采用扩展板统一 UART0 日志/下载引脚配置。
#include "usr_gpio_cfg_default.h"
