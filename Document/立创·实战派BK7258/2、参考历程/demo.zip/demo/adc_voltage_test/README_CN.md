# ADC4 电压采集（5V_DET）

上电后通过 **ADC4 / GPIO28** 读取板载 **5V_DET** 分压信号，**每 1 秒**打印一次：

- `raw`：SARADC 原始值  
- `pin`：GPIO28 引脚电压（mV）  
- `vbus`：按分压比反推的 USB **VBUS** 电压（mV）

无需 CLI，烧录后打开 CP UART0（115200）即可观察。

## 预期日志

```text
 ADC4 raw=7826 pin=3132mV vbus=4698mV
 5V_DET ADC4(GPIO28) every 1000ms, divider 100k/200k
 READY: adc_voltage_test
 ADC4 raw=7834 pin=3170mV vbus=4755mV
 ADC4 raw=7833 pin=3170mV vbus=4755mV
...
```

实测 `pin≈3170mV` 时，`vbus≈4755mV`（约 4.76V）属正常：Type-C 经线缆/保护后 VBUS 常低于 5.0V 标称值。

## 分压原理

扩展板网表（`BK7258扩展板网表.net`）中 **5V_DET** 接法：

```text
VBUS ── R38(100k) ── GPIO28/ADC4 ── R40(200k) ── GND
```

```text
pin_mv  = VBUS × R40 / (R38 + R40) = VBUS × 2/3
vbus_mv = pin_mv × (R38 + R40) / R40 = pin_mv × 3/2
```

代码中 `vbus_mv = pin_mv * 300 / 200`（即 ×1.5）。

## 构建与烧录

```bash
cd projects/adc_voltage_test
make bk7258
```

固件：`build/bk7258/adc_voltage_test/package/all-app.bin`

## 配置说明

- AP：`CONFIG_SARADC=y`、`CONFIG_SARADC_CLIENT=y`  
- 采样经 AP SARADC Client → mailbox → CP SARADC Server 完成  
- `pin_mv` 由 SDK `bk_adc_data_calculate()` 换算；`vbus_mv` 为按固定分压比估算，未做 ADC 标定  

精确计量请用万用表对比 VBUS 后修正分压电阻公差或做软件标定。

## 芯片其他 ADC 通道（本例程未使用）

| 通道 | GPIO | 板级 net 名 | 备注 |
|------|------|-------------|------|
| ADC1 | GPIO25 | LCD_BL | 与背光复用 |
| ADC2 | GPIO24 | SENSOR_PWR_CTL | 与 sensor 电源复用 |
| ADC3 | GPIO23 | PLAY_CTL | 与功放控制复用 |
| **ADC4** | **GPIO28** | **5V_DET** | **本例程** |
| ADC5 | GPIO22 | 3V3_OUT_CTL | 与 3.3V 使能复用 |
| ADC6 | GPIO21 | PORT_I2C_SDA | 与 I2C0 复用 |

扩展其他通道时参考 `board_design/pinmap.md` 与 SDK `adc_map.h`；外部信号勿超过 ADC 允许输入范围。

## 关键文件

| 文件 | 说明 |
|------|------|
| `ap/adc_voltage.c` | ADC4 定时采样与 VBUS 换算 |
| `ap/adc_voltage.h` | 通道与分压常量 |
| `ap/ap_main.c` | 板级上电与启动采样 |

## 参考

- SDK 示例：`bk_avdk_smp_sdk/ap/middleware/driver/saradc/saradc_example.c`
- 管脚表：`board_design/pinmap.md`
