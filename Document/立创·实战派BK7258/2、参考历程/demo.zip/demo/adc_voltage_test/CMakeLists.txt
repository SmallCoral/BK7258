cmake_minimum_required(VERSION 3.5)

include(${CMAKE_CURRENT_LIST_DIR}/../../cmake/lichuang_project.cmake)
lichuang_project_setup()
project(app)
