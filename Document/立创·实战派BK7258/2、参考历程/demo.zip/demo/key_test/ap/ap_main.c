/**
 * @file ap_main.c
 * @brief SW2 按键中断例程 AP 入口
 *
 * 初始化 SDK 与 bsp_key，注册按键按下回调，通过 GPIO7 下降沿中断检测 SW2。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include "bsp_key.h"

#define TAG "key_test"

/**
 * @brief SW2 按键事件回调
 * @param ev  按键事件类型
 * @param arg 用户参数（未使用）
 */
static void on_key_event(bsp_key_event_t ev, void *arg)
{
	static uint32_t s_press_count = 0;

	(void)arg;

	if (ev == BSP_KEY_EVENT_PRESSED) {
		BK_LOGI(TAG, "SW2 pressed #%u: GPIO7 level=0\r\n", (unsigned)(++s_press_count));
	}
}

/**
 * @brief AP 入口：初始化按键中断监测
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }

    bsp_key_cfg_t cfg = { .cb = on_key_event };
    bk_err_t ret = bsp_key_init(&cfg);
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: SW2 key init (%d)\r\n", ret);
        return -1;
    }

    BK_LOGI(TAG, "READY: SW2 GPIO7 pull-up, press=low\r\n");
    BK_LOGI(TAG, "Press SW2 to trigger falling-edge interrupt\r\n");
    return 0;
}
