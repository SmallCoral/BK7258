# key_test：BK7258 扩展板 SW2 按键中断示例

本 README 依据工程当前的 C、CMake、config、分区文件及 `bsp_key`/`bsp_gpio` 组件编写。日志是源码定义的判据；本次文档整理不等同于上板实测，最终结果需人工按键验收。

## 示例目标

使用板载 SW2 验证 GPIO 输入上拉、下降沿中断、ISR 与后台任务协作、20 ms 消抖及按下计数。每次稳定按下只应增加一次计数。

## 学习内容

- 用板级组件初始化低有效机械按键。
- 在 ISR 中只清中断并释放信号量，把消抖和回调放到任务上下文。
- 理解按下、等待释放和避免长按重复计数的状态流程。

## 硬件要求和引脚

- 立创 BK7258 开发板及扩展板、板载 SW2、USB 数据线。
- SW2 使用 `BOARD_KEY_PIN`：输入上拉、按下为低电平，按下沿为下降沿。
- 当前 BSP 常量对应 GPIO7；完整引脚事实以[板卡唯一权威映射](../../board_design/pinmap.md)、[`bsp_gpio.h`](../../components/bsp_gpio/bsp_gpio.h)和 [`bsp_key.h`](../../components/bsp_key/bsp_key.h)为准。本文不复制整张映射表。

## 软件配置

- AP 组件通过 `PRIV_REQUIRES bk_common bsp_key` 引入按键组件。
- `bsp_key_init()` 自行确保 GPIO 驱动已初始化，并调用 `bsp_gpio_init_key()` 完成解映射和输入上拉。
- 配置结构体未填写消抖时间，因此使用组件默认值 `20 ms`；未配置长按阈值，因此本例只处理 `BSP_KEY_EVENT_PRESSED`。
- `usr_gpio_cfg.h` 使用统一板级映射；当前标准 AP/CP/OTA 分区和 16 MiB PSRAM 布局无需修改。

## 编译命令

在本工程目录执行其一：

```bash
make bk7258
```

```bash
./dbuild.sh bk7258
```

默认布局要求 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。需要全量重编时先执行 `make clean`。

## 固件位置

整机烧录文件为：

```text
build/bk7258/key_test/package/all-app.bin
```

烧录时不要选择 AP、CP 或其他中间产物。

## 烧录和运行步骤

1. 连接 USB 数据线并确认 CH340K 串口。
2. 按[固件烧录参考](../../docs/reference/firmware-download.md)烧录上述 `all-app.bin`。
3. 释放下载串口，以 `115200 8N1`、无流控打开终端；详细方法见[串口控制台参考](../../docs/reference/serial-console.md)。
4. 短按复位键，等待按键测试就绪日志。
5. 分别短按、连续短按和按住 SW2，观察计数是否只在每次新的稳定按下时增加。

## 预期日志或现象

初始化成功时源码输出：

```text
READY: SW2 GPIO7 pull-up, press=low
Press SW2 to trigger falling-edge interrupt
```

第一次稳定按下的消息为：

```text
SW2 pressed #1: GPIO7 level=0
```

之后序号应递增。人工硬件验收应确认：一次短按只计数一次、按住不连续刷计数、释放后下一次按下可再次触发；本文不宣称本次修改已完成这些上板验证。

## CLI/AT 操作方法

无需 CLI/AT。SW2 是唯一操作输入，串口只用于观察日志；虽然基础配置包含 CLI，应用没有注册项目专用命令。

## 常见问题

- 按键无日志：先确认已出现 ready 日志，再核对 SW2、`BOARD_KEY_PIN` 和板级映射。
- 一次按下计数多次：检查是否改动了默认消抖时间或中断/释放状态机，不要在 ISR 中直接做延时。
- 初始化返回错误：关注 `SW2 key init failed: <ret>`，优先检查 GPIO 初始化、管脚是否被其他外设重复接管。
- 串口无输出或烧录异常：按[通用排障](../../docs/reference/troubleshooting.md)检查端口占用、波特率和固件路径。

## 代码入口

教学调用链：

```text
AP main()
  -> bk_init()
  -> bsp_key_init(callback)
       -> bsp_gpio_init_key()
       -> 创建信号量和按键任务
       -> 注册 BOARD_KEY_PIN 下降沿 ISR
  -> ISR 清中断、释放信号量
  -> 按键任务等待 20 ms 消抖
  -> 确认低电平、回调 BSP_KEY_EVENT_PRESSED
  -> on_key_event() 打印并增加计数
  -> 等待释放后接受下一次按下
```

工程入口位于 [`ap/ap_main.c`](ap/ap_main.c)，通用状态机位于 [`components/bsp_key/bsp_key.c`](../../components/bsp_key/bsp_key.c)。

## 可扩展方向

- 配置 `long_press_ms`，在回调中区分短按、释放和长按。
- 将按键事件投递到业务消息队列，避免在回调中执行耗时操作。
- 增加多击、组合键或低功耗唤醒测试，并为每种事件制定人工验收步骤。

## 相关示例

- [`hello_board`](../hello_board/)：先验证最小编译、烧录和串口链路。
- [`key_lcd_demo`](../key_lcd_demo/)：将按键事件与 LCD 页面操作结合。
- [`st7789_test`](../st7789_test/)：独立验证按键+显示组合工程所依赖的 LCD 链路。
