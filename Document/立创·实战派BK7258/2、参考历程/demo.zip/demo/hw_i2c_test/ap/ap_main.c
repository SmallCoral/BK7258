/**
 * @file ap_main.c
 * @brief 硬件 I2C 探测 SC7A20 WHO_AM_I 对照实验 demo
 *
 * 目的：对照验证硬件 I2C1 与模拟 I2C 探测 SC7A20 WHO_AM_I 的差异。
 * 结论（2026-10-16 实验）：正确映射引脚后硬件 I2C1 能正常读到 0x11。
 *
 * 实验设计（同一物理总线 GPIO42/43、同一从机 0x19、同一寄存器 0x0F）：
 *   1) hw 组：GPIO42/43 复用为 I2C1 控制器功能，bk_i2c_init(I2C_ID_1) 后
 *      bk_i2c_memory_read 读 WHO_AM_I，并全地址扫描 0x08~0x77；
 *   2) sim 组（对照组）：同一对引脚交回模拟 I2C（id=SOC_I2C_UNIT_NUM）bit-bang
 *      再读 WHO_AM_I。预期读回 0x11，证明器件在线、供电/接线正常，
 *      探测差异只来自硬件控制器路径。
 *
 * 上电自动跑一遍 hw + sim 对照，之后可用 CLI 重测：
 *   hwi2c hw | hw_scan | sim | all
 */

#include "bk_private/bk_init.h"
#include <stdbool.h>
#include <os/os.h>
#include <os/str.h>
#include <components/log.h>
#include "cli.h"
#include "bsp_gpio.h"
#include "board_i2c.h"
#include <driver/i2c.h>
#include <driver/gpio.h>
#include "gpio_driver.h"   // gpio_dev_map/unmap（SDK 内部头，经 PRIV_REQUIRES driver 引入）

#define TAG "hw_i2c_test"

#define SC7A20_ADDR        BSP_BOARD_I2C_ADDR_GSENSOR   // 0x19
#define REG_WHO_AM_I       0x0F
#define WHO_AM_I_VALUE     0x11
#define I2C_SCL_PIN        BSP_BOARD_I2C_SCL_PIN        // GPIO_42
#define I2C_SDA_PIN        BSP_BOARD_I2C_SDA_PIN        // GPIO_43
#define HW_I2C_ID          I2C_ID_1
#define SIM_I2C_ID         BSP_BOARD_I2C_BUS_ID         // SOC_I2C_UNIT_NUM

/**
 * @brief 读 WHO_AM_I 的通用事务：写寄存器地址 0x0F + 重复起始 + 读 1 字节
 *
 * @param id  I2C 总线 id（硬件 I2C_ID_1 或模拟 BSP_BOARD_I2C_BUS_ID）
 * @param out 读回的字节
 * @return BK_OK 传输成功（从机 ACK），其它为控制器/传输错误
 */
static bk_err_t who_am_i_read(i2c_id_t id, uint8_t *out)
{
	i2c_mem_param_t p = {0};// 配置 I2C 内存事务参数
	p.dev_addr = SC7A20_ADDR;// SC7A20 从机地址
	p.mem_addr = REG_WHO_AM_I;// WHO_AM_I 寄存器地址
	p.mem_addr_size = I2C_MEM_ADDR_SIZE_8BIT;// 8-bit 地址模式
	p.data = out;// 读回数据指针
	p.data_size = 1;// 读 1 字节
	p.timeout_ms = 1000;// 1s 超时
	return bk_i2c_memory_read(id, &p);// 执行内存读事务
}

/**
 * @brief 把 GPIO42/43 交还给硬件 I2C1 控制器（模拟 I2C 用过之后必须重映射）
 */
static void hw_i2c_pin_to_controller(void)
{
	gpio_dev_unmap(I2C_SCL_PIN);
	gpio_dev_unmap(I2C_SDA_PIN);
	gpio_dev_map(I2C_SCL_PIN, GPIO_DEV_I2C1_SCL);
	gpio_dev_map(I2C_SDA_PIN, GPIO_DEV_I2C1_SDA);
	bk_gpio_pull_up(I2C_SCL_PIN);
	bk_gpio_pull_up(I2C_SDA_PIN);
}

/**
 * @brief 本 boot 内 I2C1 控制器是否已被我们 init 过
 *
 * 本 SDK 的 bk_i2c_deinit 对从未 init 过的 id 不安全（guard 宏只查驱动级标志，
 * deinit 会对 NULL 信号量 vQueueDelete 触发 configASSERT），因此必须先查本标志。
 */
static bool s_hw_inited = false;

/**
 * @brief 确保硬件 I2C1 处于已知良好状态，且 GPIO42/43 当前归属 I2C1 控制器
 *
 * 已 init 过时做完整 deinit + 重映射引脚 + init：
 * 对照组(sim)运行时 sim 驱动会把 42/43 夺为 bit-bang GPIO，期间 I2C1 控制器
 * 会触发 SCL 超时自保（i2c_driver.c 中永久关闭 scl_timeout 中断并翻转
 * disable/enable），控制器状态已受损，仅重映射引脚无法恢复，必须完整 init。
 */
static bk_err_t ensure_hw_i2c(void)
{
	bk_i2c_driver_init();// 确保 I2C 驱动已 init
	if (s_hw_inited) {// 如果已 init 过
		bk_i2c_deinit(HW_I2C_ID);// 则先 deinit
		s_hw_inited = false;// 标记已 deinit
	}
	hw_i2c_pin_to_controller();// 交还给硬件 I2C1 控制器

	i2c_config_t cfg = {0};// 配置 I2C1
	cfg.baud_rate = BSP_BOARD_I2C_BAUD;   // 100k，与模拟 I2C 保持一致排除速率因素
	cfg.addr_mode = I2C_ADDR_MODE_7BIT;// 7-bit 地址模式
	cfg.slave_addr = SC7A20_ADDR;// SC7A20 从机地址
	bk_err_t ret = bk_i2c_init(HW_I2C_ID, &cfg);// 初始化 I2C1
	if (ret == BK_OK) {
		s_hw_inited = true;// 标记已 init
		rtos_delay_milliseconds(10);// 等待 I2C1 稳定
	}
	return ret;
}

/**
 * @brief hw 组：硬件 I2C1 读 WHO_AM_I
 */
static bk_err_t hw_probe(void)
{
	bk_err_t ret = ensure_hw_i2c();// 确保 I2C1 控制器已 init 且 GPIO42/43 归为 I2C1
	if (ret != BK_OK) {
		BK_LOGE(TAG, "[HW] bk_i2c_init(id=%d) fail: %d\r\n", (int)HW_I2C_ID, ret);
		return ret;
	}

	uint8_t id = 0;
	ret = who_am_i_read(HW_I2C_ID, &id);// 读取 WHO_AM_I
	if (ret != BK_OK) {
		BK_LOGE(TAG, "[HW] read WHO_AM_I fail: ret=%d (hw NACK/xfer error)\r\n", ret);
		return ret;
	}
	BK_LOGI(TAG, "[HW] WHO_AM_I=0x%02x (expect 0x%02x) -> %s\r\n",
		id, WHO_AM_I_VALUE, (id == WHO_AM_I_VALUE) ? "MATCH" : "MISMATCH");
	return (id == WHO_AM_I_VALUE) ? BK_OK : BK_FAIL;
}

/**
 * @brief hw 组：硬件 I2C1 全地址扫描，观察是否有任何从机 ACK
 */
static void hw_scan(void)
{
	if (ensure_hw_i2c() != BK_OK) {// 确保 I2C1 控制器已 init 且 GPIO42/43 归为 I2C1
		BK_LOGE(TAG, "[HW] i2c init fail, skip scan\r\n");
		return;
	}

	BK_LOGI(TAG, "[HW] scan hw-I2C1 addr 0x08~0x77 ...\r\n");
	int found = 0;
	for (uint8_t a = 0x08; a <= 0x77; a++) {// 遍历 0x08~0x77 地址
		uint8_t v = 0xAA;
		i2c_mem_param_t p = {0};
		p.dev_addr = a;
		p.mem_addr = REG_WHO_AM_I;
		p.mem_addr_size = I2C_MEM_ADDR_SIZE_8BIT;
		p.data = &v;
		p.data_size = 1;
		p.timeout_ms = 200;
		if (bk_i2c_memory_read(HW_I2C_ID, &p) == BK_OK) {
			BK_LOGI(TAG, "[HW]  ACK @0x%02x  reg0x0F=0x%02x\r\n", a, v);
			found++;
		}
	}
	BK_LOGI(TAG, "[HW] scan done, %d addr ACKed\r\n", found);
}

/**
 * @brief sim 组（对照组）：模拟 I2C 读 WHO_AM_I
 *
 * sim 驱动在 bk_i2c_init 时自行 gpio_dev_unmap + 重配 42/43 为 bit-bang GPIO，
 * 因此每次调用都重新 init 一次，确保引脚从硬件控制器手里夺回。
 */
static bk_err_t sim_probe(void)
{
	bk_i2c_driver_init();
	if (s_hw_inited) {
		bk_i2c_deinit(HW_I2C_ID);   // 先关闭 I2C1 控制器，避免 sim 夺引脚时它触发 SCL 超时自保
		s_hw_inited = false;// 标记已 deinit
	}
	i2c_config_t cfg = {0};// 配置模拟 I2C
	cfg.baud_rate = BSP_BOARD_I2C_BAUD;// 100k，与硬件 I2C 保持一致排除速率因素
	cfg.addr_mode = I2C_ADDR_MODE_7BIT;// 7-bit 地址模式
	cfg.slave_addr = SC7A20_ADDR;// SC7A20 从机地址
	bk_err_t ret = bk_i2c_init(SIM_I2C_ID, &cfg);   // 重配 42/43 为模拟 I2C
	if (ret != BK_OK) {
		BK_LOGE(TAG, "[SIM] bk_i2c_init(id=%d) fail: %d\r\n", (int)SIM_I2C_ID, ret);
		return ret;
	}
	rtos_delay_milliseconds(10);

	uint8_t id = 0;
	ret = who_am_i_read(SIM_I2C_ID, &id);// 读取 WHO_AM_I
	if (ret != BK_OK) {
		BK_LOGE(TAG, "[SIM] read WHO_AM_I fail: ret=%d\r\n", ret);
		return ret;
	}
	BK_LOGI(TAG, "[SIM] WHO_AM_I=0x%02x -> %s (control: device online)\r\n",
		id, (id == WHO_AM_I_VALUE) ? "MATCH" : "MISMATCH");
	return (id == WHO_AM_I_VALUE) ? BK_OK : BK_FAIL;
}

/**
 * @brief 完整对照实验：hw probe + hw scan + sim probe，并打印结论
 */
static void run_all(void)
{
	BK_LOGI(TAG, "==== contrast test: bus GPIO42/43, slave 0x%02x, reg 0x0F ====\r\n",
		SC7A20_ADDR);
	bk_err_t hw_ret = hw_probe();// 硬件 I2C 读 WHO_AM_I
	hw_scan();// 硬件 I2C 全地址扫描
	bk_err_t sim_ret = sim_probe();// 模拟 I2C 读 WHO_AM_I

	BK_LOGI(TAG, "==== RESULT: hw-I2C1 %s, sim-I2C %s ====\r\n",
		(hw_ret == BK_OK) ? "FOUND dev (0x11)" : "NOT found",
		(sim_ret == BK_OK) ? "FOUND (control OK)" : "also FAIL (check power/wiring)");
}

/**
 * @brief `hwi2c` CLI 命令处理
 */
static void cli_hwi2c_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
	if (argc < 2) {
		BK_LOGI(TAG, "usage: hwi2c hw | hw_scan | sim | all\r\n");
		return;
	}

	if (os_strcmp(argv[1], "hw") == 0) {
		hw_probe();
	} else if (os_strcmp(argv[1], "hw_scan") == 0) {
		hw_scan();
	} else if (os_strcmp(argv[1], "sim") == 0) {
		sim_probe();
	} else if (os_strcmp(argv[1], "all") == 0) {
		run_all();
	} else {
		BK_LOGI(TAG, "usage: hwi2c hw | hw_scan | sim | all\r\n");
	}
}

static const struct cli_command s_hwi2c_cmds[] = {
	{"hwi2c", "hwi2c hw|hw_scan|sim|all", cli_hwi2c_cmd},
};

/**
 * @brief 上电自检线程：自动跑一遍完整对照实验
 */
static void hw_selftest_thread(void *arg)
{
	rtos_delay_milliseconds(500);// 等待传感器上电稳定
	run_all();// 运行完整对照实验
	BK_LOGI(TAG, "re-run via CLI: hwi2c hw / hw_scan / sim / all\r\n");
	rtos_delete_thread(NULL);
}

int main(void)
{
	if (bk_init() != BK_OK) {// 系统初始化
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}

	if (bsp_gpio_init_power_master() != BK_OK ||
	    bsp_gpio_init_sensor() != BK_OK ||
	    bsp_gpio_init_export_io() != BK_OK) {// 初始化其他 GPIO
		BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
		return -1;
	}
	board_gpio_set_high(BOARD_SENSOR_PWR_PIN);     // GPIO24 高有效, 给 SC7A20 上电
	board_gpio_set_high(BOARD_EXPORT_IO_PWR_PIN);  // GPIO6 外扩 IO 电源(上拉供电, 兜底)
	rtos_delay_milliseconds(100);

	if (cli_register_commands(
	        s_hwi2c_cmds, sizeof(s_hwi2c_cmds) / sizeof(s_hwi2c_cmds[0])) != BK_OK) {// 注册 CLI 命令
		BK_LOGE(TAG, "FAIL: CLI register\r\n");
		goto fail_power;
	}

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "hw_selftest", hw_selftest_thread, 4096, NULL) != BK_OK) {// 创建自检线程
		BK_LOGE(TAG, "FAIL: selftest thread create\r\n");
		cli_unregister_commands(// 注销 CLI 命令
			s_hwi2c_cmds, sizeof(s_hwi2c_cmds) / sizeof(s_hwi2c_cmds[0]));
		goto fail_power;
	}

	BK_LOGI(TAG, "READY: hw vs sim I2C contrast test\r\n");
	return 0;

fail_power:
	board_gpio_set_low(BOARD_SENSOR_PWR_PIN);
	board_gpio_set_low(BOARD_EXPORT_IO_PWR_PIN);
	return -1;
}
