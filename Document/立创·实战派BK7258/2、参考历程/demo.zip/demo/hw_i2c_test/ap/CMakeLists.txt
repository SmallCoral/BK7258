set(incs .)
set(srcs ap_main.c)

# driver 仅为使用其内部头 gpio_driver.h 的 gpio_dev_map/unmap（重映射 42/43 到 I2C1 控制器）
set(priv_req bk_common bsp_gpio driver)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
