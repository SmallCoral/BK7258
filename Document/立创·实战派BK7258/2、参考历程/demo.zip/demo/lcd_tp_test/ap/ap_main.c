/**
 * @file ap_main.c
 * @brief LCD 与触摸屏联合自测工程 AP 入口
 *
 * 初始化板级 GPIO 与 media 服务后启动 ST7789 纯色循环与触摸画点自测。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>
#include "bsp_gpio.h"
#include "lcd_tp_selftest.h"

#define TAG "lcd_tp_test"

/**
 * @brief AP 入口：初始化系统并启动 LCD/TP 自测
 *
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
    bk_err_t ret = bk_init();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: bk_init (%d)\r\n", ret);
        return -1;
    }
    ret = bsp_gpio_init_power_master();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: power GPIO init (%d)\r\n", ret);
        return -1;
    }
    ret = bsp_gpio_init_lcd();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: LCD GPIO init (%d)\r\n", ret);
        return -1;
    }
    ret = bsp_gpio_init_key();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: key GPIO init (%d)\r\n", ret);
        return -1;
    }
    ret = media_service_init();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: media service init (%d)\r\n", ret);
        return -1;
    }
    ret = lcd_tp_selftest_init();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "FAIL: LCD/TP selftest init (%d)\r\n", ret);
        return -1;
    }
    BK_LOGI(TAG, "READY: LCD/TP selftest started\r\n");
    return 0;
}
