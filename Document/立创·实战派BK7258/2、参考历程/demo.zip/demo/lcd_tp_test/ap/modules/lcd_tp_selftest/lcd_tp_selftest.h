/**
 * @file lcd_tp_selftest.h
 * @brief ST7789 LCD 与电容触摸联合自测对外接口
 *
 * 开机自动跑 RGB 纯色循环，随后进入触摸画点模式；支持 `lcd_test` / `tp_test` CLI。
 */

#pragma once

#include <common/bk_err.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 LCD 配置、注册 CLI 并启动自测线程
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功（幂等）
 * @retval BK_FAIL ST7789 配置、CLI 或线程创建失败
 */
bk_err_t lcd_tp_selftest_init(void);

/** @brief 停止自测线程、关闭触摸与 LCD 并注销 CLI */
void lcd_tp_selftest_deinit(void);

#ifdef __cplusplus
}
#endif
