/**
 * @file lcd_tp_selftest.c
 * @brief ST7789 LCD 与电容触摸联合自测实现
 *
 * 经 bk_display SPI 刷新 RGB565 纯色与触摸轨迹；提供 lcd_test / tp_test CLI 控制。
 */

#include "lcd_tp_selftest.h"

#include <stdbool.h>
#include <components/log.h>
#include <components/avdk_utils/avdk_error.h>
#include <os/os.h>
#include <os/str.h>
#include "cli.h"
#include "components/bk_display.h"
#include "driver/drv_tp.h"
#include "frame_buffer.h"
#include "lcd_panel_devices.h"
#include "bsp_gpio.h"
#include "bsp_lcd_st7789.h"

#define TAG "lcd_tp_test"

#define RED_COLOR    0xF800
#define GREEN_COLOR  0x07E0
#define BLUE_COLOR   0x001F
#define WHITE_COLOR  0xFFFF
#define BLACK_COLOR  0x0000

#define TP_MARKER_HALF   6
#define TP_POLL_MS       15

static bk_display_ctlr_handle_t s_lcd_handle = NULL;
static frame_buffer_t *s_canvas_fb = NULL;
static beken_thread_t s_tp_thread = NULL;
static beken_thread_t s_selftest_thread = NULL;
static volatile bool s_tp_running = false;
static bool s_initialized = false;

static bk_display_spi_ctlr_config_t s_spi_cfg = {
    .lcd_device = NULL,
    .spi_id     = 1,
    .dc_pin     = BOARD_LCD_DC_PIN,
    .reset_pin  = BOARD_LCD_RST_PIN,
    .te_pin     = 0,
};

static bk_err_t disp_frame_free_cb(void *args)
{
    (void)args;
    return BK_OK;
}

static void fill_pure_color(frame_buffer_t *fb, uint16_t color)
{
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;

    for (uint32_t i = 0; i < fb->size; i += 2) {
        fb->frame[i] = hi;
        fb->frame[i + 1] = lo;
    }
}

static void lcd_release(void)
{
    board_gpio_set_high(BOARD_LCD_BL_PIN);
    if (s_lcd_handle) {
        avdk_err_t ret = bk_display_close(s_lcd_handle);
        if (ret != AVDK_ERR_OK) {
            BK_LOGE(TAG, "bk_display_close failed: %d\r\n", ret);
        }
        ret = bk_display_delete(s_lcd_handle);
        if (ret != AVDK_ERR_OK) {
            BK_LOGE(TAG, "bk_display_delete failed: %d\r\n", ret);
        }
        s_lcd_handle = NULL;
    }
    board_gpio_set_low(BOARD_LCD_PWR_PIN);
}

static avdk_err_t lcd_open(void)
{
    avdk_err_t ret;

    if (s_lcd_handle) {
        return AVDK_ERR_OK;
    }

    board_gpio_set_high(BOARD_LCD_BL_PIN);
    ret = bk_display_spi_new(&s_lcd_handle, &s_spi_cfg);
    if (ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "bk_display_spi_new failed: %d\r\n", ret);
        goto fail;
    }

    board_gpio_set_high(BOARD_LCD_PWR_PIN);
    ret = bk_display_open(s_lcd_handle);
    if (ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "bk_display_open failed: %d\r\n", ret);
        goto fail;
    }

    board_gpio_set_low(BOARD_LCD_BL_PIN);
    return AVDK_ERR_OK;

fail:
    board_gpio_set_high(BOARD_LCD_BL_PIN);
    if (s_lcd_handle) {
        bk_display_delete(s_lcd_handle);
        s_lcd_handle = NULL;
    }
    board_gpio_set_low(BOARD_LCD_PWR_PIN);
    return ret;
}

static avdk_err_t lcd_color_test(uint32_t loops)
{
    const uint16_t colors[3] = {RED_COLOR, GREEN_COLOR, BLUE_COLOR};
    uint32_t w = s_spi_cfg.lcd_device->width;
    uint32_t h = s_spi_cfg.lcd_device->height;
    frame_buffer_t *fb = frame_buffer_display_malloc(w * h * 2);

    if (!fb) {
        BK_LOGE(TAG, "frame buffer malloc failed\r\n");
        return AVDK_ERR_GENERIC;
    }

    fb->fmt = PIXEL_FMT_RGB565;
    fb->width = w;
    fb->height = h;

    avdk_err_t ret = AVDK_ERR_OK;
    for (uint32_t n = 0; n < loops; n++) {
        fill_pure_color(fb, colors[n % 3]);
        ret = bk_display_flush(s_lcd_handle, fb, disp_frame_free_cb);
        if (ret != AVDK_ERR_OK) {
            BK_LOGE(TAG, "bk_display_flush failed: %d\r\n", ret);
            break;
        }
        rtos_delay_milliseconds(500);
    }

    frame_buffer_display_free(fb);
    if (ret == AVDK_ERR_OK) {
        BK_LOGI(TAG, "lcd color test done (%dx%d)\r\n", w, h);
    }
    return ret;
}

static void canvas_draw_marker(uint16_t x, uint16_t y, uint16_t color)
{
    if (!s_canvas_fb) {
        return;
    }

    uint32_t w = s_canvas_fb->width;
    uint32_t h = s_canvas_fb->height;
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;
    int x0 = (int)x - TP_MARKER_HALF;
    int x1 = (int)x + TP_MARKER_HALF;
    int y0 = (int)y - TP_MARKER_HALF;
    int y1 = (int)y + TP_MARKER_HALF;

    if (x0 < 0) {
        x0 = 0;
    }
    if (y0 < 0) {
        y0 = 0;
    }
    if (x1 >= (int)w) {
        x1 = (int)w - 1;
    }
    if (y1 >= (int)h) {
        y1 = (int)h - 1;
    }

    for (int row = y0; row <= y1; row++) {
        uint8_t *line = &s_canvas_fb->frame[(row * (int)w + x0) * 2];
        for (int col = x0; col <= x1; col++) {
            *line++ = hi;
            *line++ = lo;
        }
    }
}

static void tp_selftest_thread(void *arg)
{
    (void)arg;
    uint32_t w = s_spi_cfg.lcd_device->width;
    uint32_t h = s_spi_cfg.lcd_device->height;
    bool tp_open_attempted = false;

    s_canvas_fb = frame_buffer_display_malloc(w * h * 2);
    if (!s_canvas_fb) {
        BK_LOGE(TAG, "canvas fb malloc failed\r\n");
        goto exit;
    }

    s_canvas_fb->fmt = PIXEL_FMT_RGB565;
    s_canvas_fb->width = w;
    s_canvas_fb->height = h;
    fill_pure_color(s_canvas_fb, BLACK_COLOR);
    avdk_err_t display_ret =
        bk_display_flush(s_lcd_handle, s_canvas_fb, disp_frame_free_cb);
    if (display_ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "canvas flush failed: %d\r\n", display_ret);
        goto exit;
    }

    int tp_ret = drv_tp_open((int)w, (int)h, TP_MIRROR_NONE);
    if (tp_ret != kNoErr) {
        BK_LOGE(TAG, "drv_tp_open failed: %d\r\n", tp_ret);
        goto exit;
    }
    tp_open_attempted = true;
    BK_LOGI(TAG, "touch opened, draw on screen with finger...\r\n");

    while (s_tp_running) {
        tp_point_infor_t point = {0};
        if (drv_tp_read(&point) == kNoErr) {
            BK_LOGI(TAG, "tp: x=%u y=%u state=%u\r\n",
                    point.m_x, point.m_y, point.m_state);
            if (point.m_state) {
                canvas_draw_marker(point.m_x, point.m_y, WHITE_COLOR);
                display_ret =
                    bk_display_flush(s_lcd_handle, s_canvas_fb, disp_frame_free_cb);
                if (display_ret != AVDK_ERR_OK) {
                    BK_LOGE(TAG, "marker flush failed: %d\r\n", display_ret);
                    break;
                }
            }
            if (!point.m_need_continue) {
                rtos_delay_milliseconds(TP_POLL_MS);
            }
        } else {
            rtos_delay_milliseconds(TP_POLL_MS);
        }
    }

exit:
    if (tp_open_attempted) {
        drv_tp_close();
    }
    if (s_canvas_fb) {
        frame_buffer_display_free(s_canvas_fb);
        s_canvas_fb = NULL;
    }
    s_tp_running = false;
    s_tp_thread = NULL;
    BK_LOGI(TAG, "touch selftest stopped\r\n");
    rtos_delete_thread(NULL);
}

static bk_err_t tp_test_open(void)
{
    if (s_tp_running) {
        BK_LOGI(TAG, "touch already running\r\n");
        return BK_OK;
    }
    if (lcd_open() != AVDK_ERR_OK) {
        return BK_FAIL;
    }

    s_tp_running = true;
    bk_err_t ret = rtos_create_thread(
        &s_tp_thread, BEKEN_DEFAULT_WORKER_PRIORITY,
        "tp_selftest", tp_selftest_thread, 4096, NULL);
    if (ret != BK_OK) {
        s_tp_running = false;
        s_tp_thread = NULL;
        BK_LOGE(TAG, "create tp thread failed: %d\r\n", ret);
    }
    return ret;
}

static void tp_test_close(void)
{
    beken_thread_t thread = s_tp_thread;
    s_tp_running = false;
    if (thread) {
        bk_err_t ret = rtos_thread_join(&thread);
        if (ret != BK_OK) {
            BK_LOGE(TAG, "join tp thread failed: %d\r\n", ret);
        }
    }
    s_tp_thread = NULL;
}

static void lcd_close(void)
{
    tp_test_close();
    lcd_release();
}

static void selftest_join(void)
{
    beken_thread_t thread = s_selftest_thread;
    if (thread) {
        bk_err_t ret = rtos_thread_join(&thread);
        if (ret != BK_OK) {
            BK_LOGE(TAG, "join lcd selftest thread failed: %d\r\n", ret);
        }
        s_selftest_thread = NULL;
    }
}

static void lcd_selftest_thread(void *arg)
{
    (void)arg;
    rtos_delay_milliseconds(500);
    if (lcd_open() == AVDK_ERR_OK) {
        lcd_color_test(6);
    }
    tp_test_open();
    rtos_delete_thread(NULL);
}

static void cli_lcd_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
    (void)pcWriteBuffer;
    (void)xWriteBufferLen;

    if (argc >= 2 && os_strcmp(argv[1], "close") == 0) {
        selftest_join();
        lcd_close();
        BK_LOGI(TAG, "lcd closed\r\n");
        return;
    }

    if (lcd_open() == AVDK_ERR_OK) {
        uint32_t loops = 6;
        if (argc >= 3) {
            loops = os_strtoul(argv[2], NULL, 10);
        }
        lcd_color_test(loops);
    }
}

static void cli_tp_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
    (void)pcWriteBuffer;
    (void)xWriteBufferLen;

    if (argc >= 2 && os_strcmp(argv[1], "close") == 0) {
        tp_test_close();
        BK_LOGI(TAG, "tp closing\r\n");
        return;
    }
    tp_test_open();
}

static const struct cli_command s_lcd_test_cmds[] = {
    {"lcd_test", "lcd_test open [loops] / lcd_test close", cli_lcd_test_cmd},
    {"tp_test",  "tp_test open / tp_test close",           cli_tp_test_cmd},
};

/**
 * @brief 初始化 LCD 配置、注册 CLI 并启动自测线程
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功（幂等）
 * @retval BK_FAIL ST7789 配置、CLI 或线程创建失败
 */
bk_err_t lcd_tp_selftest_init(void)
{
    if (s_initialized) {
        return BK_OK;
    }

    const bsp_lcd_st7789_cfg_t lcd_cfg = {
        .landscape = false,
        .mirror_x  = false,
        .mirror_y  = false,
        .clk       = LCD_QSPI_64M,
    };
    s_spi_cfg.lcd_device = bsp_lcd_st7789_get(&lcd_cfg);
    if (!s_spi_cfg.lcd_device) {
        BK_LOGE(TAG, "ST7789 profile init failed\r\n");
        return BK_FAIL;
    }

    int ret = cli_register_commands(
        s_lcd_test_cmds, sizeof(s_lcd_test_cmds) / sizeof(s_lcd_test_cmds[0]));
    if (ret != 0) {
        BK_LOGE(TAG, "register lcd/tp commands failed: %d\r\n", ret);
        return BK_FAIL;
    }

    bk_err_t thread_ret = rtos_create_thread(
        &s_selftest_thread, BEKEN_DEFAULT_WORKER_PRIORITY,
        "lcd_selftest", lcd_selftest_thread, 4096, NULL);
    if (thread_ret != BK_OK) {
        s_selftest_thread = NULL;
        cli_unregister_commands(
            s_lcd_test_cmds, sizeof(s_lcd_test_cmds) / sizeof(s_lcd_test_cmds[0]));
        BK_LOGE(TAG, "create lcd selftest thread failed: %d\r\n", thread_ret);
        return thread_ret;
    }

    s_initialized = true;
    return BK_OK;
}

/** @brief 停止自测线程、关闭触摸与 LCD 并注销 CLI */
void lcd_tp_selftest_deinit(void)
{
    selftest_join();
    lcd_close();
    if (s_initialized) {
        cli_unregister_commands(
            s_lcd_test_cmds, sizeof(s_lcd_test_cmds) / sizeof(s_lcd_test_cmds[0]));
        s_initialized = false;
    }
}
