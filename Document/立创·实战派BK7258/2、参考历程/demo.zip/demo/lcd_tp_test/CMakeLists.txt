cmake_minimum_required(VERSION 3.5)

include(${CMAKE_CURRENT_LIST_DIR}/../../cmake/lichuang_project.cmake)
lichuang_project_setup(
    EXTRA_COMPONENTS_DIRS ${CMAKE_CURRENT_SOURCE_DIR}/ap/modules
)
project(app)
