# lcd_tp_test：ST7789 LCD 与 FT6336 触摸自检

## 示例目标

在立创 BK7258 扩展板上联合验证 240×320 ST7789V2 SPI 屏和 FT6336 电容触摸。上电先循环显示红、绿、蓝纯色，再进入黑色画布；手指触摸时打印坐标并在对应位置绘制白色方块。

## 学习内容

- SPI1 LCD 的初始化、RGB565 帧缓冲和纯色刷新。
- FT6336 在共享模拟 I2C 总线上的探测与触点读取。
- 触摸坐标、屏幕方向和绘图位置的联合检查。
- SDK 触摸框架与板级 GPIO 所有权的边界。

## 硬件要求和引脚

需要 BK7258 主板、立创扩展板、带 FT6336/FT6X36 触摸层的 240×320 ST7789V2 屏，以及支持数据传输的 USB Type-C 线。

| 信号 | 引脚 | 说明 |
| --- | --- | --- |
| LCD CLK/CS/MOSI | GPIO2/GPIO3/GPIO4 | SPI1 |
| LCD D/C | GPIO5 | 普通输出 |
| LCD RESET | GPIO12 | 普通输出 |
| LCD PWR | GPIO13 | 高有效 |
| LCD BL | GPIO25 | 低有效，拉低点亮 |
| TP SCL/SDA | GPIO42/GPIO43 | 共享模拟 I2C，总线速率参考 100 kHz |
| TP RESET | GPIO46 | 由 SDK 触摸框架接管 |
| TP INT | GPIO45 | 输入上拉/中断，由 SDK 触摸框架接管 |
| `3V3_OUT_CTL` | GPIO22 | 外部 3.3 V 总电源，高有效 |
| 调试 UART0 RX/TX | GPIO10/GPIO11 | CH340K 日志、CLI 与下载 |

FT6336 的 7 位地址为 `0x38`。FPC 应在断电状态下安装并锁紧。引脚以 [`board_design/pinmap.md`](../../board_design/pinmap.md)、`components/board_cfg/board_i2c.h` 和 `components/bsp_gpio` 为准。

## 软件配置

- `CONFIG_LCD_SPI_ST7789V2=y`、`CONFIG_LCD_SPI=y`、`CONFIG_LCD_SPI_REFRESH_WITH_QSPI_MAPPING_MODE=y`。
- `CONFIG_TP=y`、`CONFIG_TP_FT6336=y`、`CONFIG_TP_RST_GPIO_ID=46`、`CONFIG_TP_INT_GPIO_ID=45`。
- `CONFIG_SIM_I2C=y`，GPIO42/43 配置为共享模拟 I2C 的 SCL/SDA。
- LCD 使用竖屏 240×320、RGB565、`LCD_QSPI_64M`；板级 profile 含 `INVON(0x21)`。
- `ap_main.c` 不调用 `bsp_gpio_init_tp()`，避免与 `drv_tp` 内部的 TP RESET/INT 配置重复。
- 工程使用 `partitions/bk7258/auto_partitions.csv` 的标准分区布局。

## 编译命令

默认 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。在本工程目录执行：

```bash
make bk7258
```

Docker 编译：

```bash
./dbuild.sh bk7258
```

SDK 位于其他目录时，再通过 `SDK_DIR` 显式覆盖。

## 固件位置

整机固件位于：

```text
build/bk7258/lcd_tp_test/package/all-app.bin
```

烧录时只选择该 `package/all-app.bin`，不要使用 AP、CP 或分区中间镜像。

## 烧录和运行步骤

1. 断电连接 LCD/触摸 FPC，确认方向、锁扣和触点清洁。
2. 用 USB Type-C 连接开发板，使用 BKFIL 选择 CH340K 串口和上述固件。
3. 下载波特率设为 `1500000`，应用复位波特率设为 `115200`，完成烧录。
4. 释放串口，以 `115200 8N1`、无流控打开日志终端。
5. 短按复位键，先观察约 3 秒的红/绿/蓝循环，再在黑屏的四角和中心触摸。

通用步骤见[固件烧录参考](../../docs/reference/firmware-download.md)和[串口控制台参考](../../docs/reference/serial-console.md)。

## 预期日志或现象

启动后屏幕依次显示红、绿、蓝，各循环两次；随后变为黑色并进入触摸测试。关键日志包括：

```text
READY: LCD/TP selftest started
lcd color test done (240x320)
touch opened, draw on screen with finger...
tp: x=<坐标> y=<坐标> state=<状态>
```

按下时，触点附近应出现约 13×13 像素的白色方块；移动到不同区域时，日志坐标和白块位置应同步变化。

## CLI/AT 操作方法

在 CH340K 终端使用 `115200 8N1`、CRLF，并给 AP 命令添加 `ap_cmd`：

| 命令 | 作用 |
| --- | --- |
| `ap_cmd lcd_test open` | 打开 LCD，并按默认 6 帧运行纯色测试 |
| `ap_cmd lcd_test open 9` | 打开 LCD，按指定帧数循环红/绿/蓝 |
| `ap_cmd lcd_test close` | 关闭 LCD 和背光 |
| `ap_cmd tp_test open` | 打开触摸自检；重复执行会提示已运行 |
| `ap_cmd tp_test close` | 请求停止触摸线程并释放触摸资源 |

需要停止时先执行 `tp_test close`，等待 `touch selftest stopped`，再执行 `lcd_test close`。本工程不提供 AT 命令。

## 常见问题

- **只有背光、没有纯色**：断电检查 LCD FPC，确认 GPIO2/3/4 的 SPI1 映射以及 GPIO5/12/13/25 的控制链路。
- **纯色正常、触摸无坐标**：检查触摸 FPC、GPIO42/43、地址 `0x38`、GPIO46 RESET 和 GPIO45 INT。
- **持续 I2C 失败**：不要把共享总线当作硬件 I2C1；本工程由模拟 I2C 路径访问 GPIO42/43。
- **坐标与白块方向不一致**：记录四角坐标后核对屏幕方向和触摸镜像；本工程当前使用竖屏及 `TP_MIRROR_NONE`。
- **重复打开后资源异常**：先按顺序关闭触摸和 LCD，再重新打开；必要时复位恢复初始状态。
- **日志乱码或 CLI 无响应**：检查串口参数、CRLF、`ap_cmd` 和端口占用，详见[通用排障](../../docs/reference/troubleshooting.md)。

## 代码入口

- `ap/ap_main.c`：只负责系统、板级 GPIO、媒体服务和自检模块的启动顺序。
- `ap/modules/lcd_tp_selftest`：LCD 打开/关闭、纯色测试、触摸线程、画点、CLI 与失败回滚。
- `ap/config/bk7258_ap/config`：ST7789、FT6336、模拟 I2C、TP GPIO 和显示配置。
- `ap/config/bk7258_ap/usr_gpio_cfg.h`：转发板级默认 GPIO 映射。
- `components/bsp_lcd_st7789`：本板屏的方向、时钟和 `INVON` profile。
- `components/board_cfg/board_i2c.h`：共享模拟 I2C 总线及 FT6336 地址。

## 可扩展方向

- 增加多点触摸、拖动轨迹、清屏和坐标校准。
- 在四角自动计算旋转、镜像和有效触摸范围。
- 增加 LCD 色条、渐变、坏点和长时间刷新稳定性测试。

## 相关示例

- `st7789_test`：单独验证 ST7789 显示。
- `key_lcd_demo`：用 SW2 控制同一 LCD 的纯色切换。
- `gsensor_test`：参考 GPIO42/43 共享模拟 I2C 上的另一设备。
- `hello_board`：基础编译、烧录和串口基线。

## 人工上板验收

必须进行真实硬件验收，编译通过或日志显示“opened”都不能代替触摸效果：

1. 肉眼确认红、绿、蓝三色正确、全屏、无明显花屏或补色。
2. 分别触摸左上、右上、左下、右下和中心，确认每处都有坐标日志和位置对应的白块。
3. 执行触摸关闭/打开和 LCD 纯色命令，确认资源可停止并恢复。

保存板卡信息、FPC 连接方式、固件时间和完整启动日志后，才可判定通过。
