/**
 * @file ap_main.c
 * @brief Wi-Fi AT 验证工程 AP 入口
 *
 * 经 USB-C CP UART0（115200 8N1）直接发送 Wi-Fi AT 命令进行联调验证。
 */

#include "bk_private/bk_init.h"
#include <os/os.h>
#include <components/log.h>
#include "bsp_gpio.h"

#define TAG "wifi_at"

static void wifi_at_boot_task(void *arg)
{
	(void)arg;
	rtos_delay_milliseconds(1500);

	BK_LOGI(TAG, "READY: wifi_at_test\r\n");
	BK_LOGI(TAG, "USB-C (CP UART0), 115200 8N1, send Wi-Fi AT directly\r\n");
	BK_LOGI(TAG, "scan: AT+WIFISCAN\r\n");
	BK_LOGI(TAG, "connect: AT+STASTART=<SSID>,<PASSWORD>\r\n");
	BK_LOGI(TAG, "status: AT+WIFISTATUS=STA,IP / AT+WIFISTATUS=STA,RSSI\r\n");
	BK_LOGI(TAG, "disconnect: AT+STASTOP\r\n");
	rtos_delete_thread(NULL);
}

/**
 * @brief AP 入口：初始化系统与板级电源，并打印 Wi-Fi AT 使用说明
 *
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}
	if (bsp_gpio_init_power_master() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board power init\r\n");
		return -1;
	}

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "wifi_at_boot", wifi_at_boot_task, 2048, NULL) != BK_OK) {
		BK_LOGE(TAG, "FAIL: boot task create\r\n");
		return -1;
	}
	return 0;
}
