# wifi_at_test：BK7258 Wi-Fi 串口 AT 示例

本工程使用扩展板 USB Type-C 串口验证 BK7258 的 2.4 GHz Wi-Fi。文档内容以本工程当前 CMake、AP/CP 配置、分区表和源码为准。

## 1. 示例目标

- 通过 CP UART0 上的 AT Server 扫描、连接和断开 2.4 GHz Wi-Fi。
- 查询 STA/AP 状态、IP、RSSI、SSID、BSSID 和信道。
- 可选启动 SoftAP，验证手机能够发现并接入板端热点。
- 不在源码中写死路由器 SSID 或密码。

## 2. 学习内容

- BK7258 AP/CP 双核工程的启动与串口路径。
- AT 命令的同步响应与 Wi-Fi 异步事件。
- Station、DHCP、SoftAP 和 Wi-Fi 状态查询。
- 工程级 `config`、Flash 分区和本地/Docker 构建入口。

当前路径如下：

```text
PC 串口 -> USB Type-C/CH340 -> CP UART0 -> CP 本地 Wi-Fi AT -> Wi-Fi 协议栈
                                      \-> AP 仅运行工程启动代码和板级供电初始化
```


## 3. 硬件要求和引脚

- 立创 BK7258 模组与扩展板。
- 支持数据传输的 USB Type-C 线。
- 2.4 GHz 路由器或手机热点；仅开启 5 GHz 的热点不可用。
- 烧录工具和 115200 波特率串口终端。

相关板级连接：

- CP UART0 RX：GPIO10，连接板上下载/日志串口。
- CP UART0 TX：GPIO11，连接板上下载/日志串口。
- Wi-Fi 使用片内射频，不占用扩展板普通 GPIO。
- AP 启动时仅调用 `bsp_gpio_init_power_master()` 保证板级总电源初值。

完整映射见仓库内 `board_design/pinmap.md`。

## 4. 软件配置

工程根 CMake 通过 `cmake/lichuang_project.cmake` 建立 AP/CP 双核方案；CP 使用工程自己的 `cp/cp_main.c` 完成最小启动。

关键配置：

- AP：`CONFIG_AT=y`、`CONFIG_WIFI_AT_ENABLE=y`、`CONFIG_DEFAULT_AT_PORT=1`、`CONFIG_UART_PRINT_PORT=1`。
- CP：`CONFIG_AT=y`、`CONFIG_WIFI_AT_ENABLE=y`、`CONFIG_WIFI_ENABLE=y`、`CONFIG_DEFAULT_AT_PORT=0`、`CONFIG_UART_PRINT_PORT=0`、`CONFIG_UART_PRINT_BAUD_RATE=115200`。
- AP 的 `CONFIG_CPU_CNT=2`，CP 的 `CONFIG_CPU_CNT=3`；本例实际操作入口仍是 CP UART0。

Flash 分区为 bootloader 68 KiB、CP app 1360 KiB、AP app 1156 KiB、OTA 1428 KiB、用户配置 60 KiB，末端保留 easyflash、RF 和网络参数区。不要用单独的 AP/CP 二进制覆盖整包分区。

## 5. 编译命令

默认目录结构是 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。进入本工程后可直接构建：

```bash
cd lichuang_bk7258/projects/wifi_at_test
make bk7258
```

Docker wrapper 使用同一默认 SDK 路径：

```bash
./dbuild.sh bk7258
```

SDK 放在其他位置时才显式覆盖：

```bash
make bk7258 SDK_DIR=/path/to/bk_avdk_smp_sdk
SDK_DIR=/path/to/bk_avdk_smp_sdk ./dbuild.sh bk7258
```

清理可执行 `make clean`；切换 SDK、配置或分区后建议先清理再重编。

## 6. 固件位置

完整烧录镜像：

```text
build/bk7258/wifi_at_test/package/all-app.bin
```

OTA 包位于同目录的 `app_pack.rbl`。首次烧录和恢复板卡时使用 `all-app.bin`，不要把 OTA 包当作整片镜像。

最近一次仓库内构建摘要显示 CP Flash 使用约 65.42%，AP Flash 使用约 32.29%；实际数值以本次构建的 `package/build_summary.txt` 为准。

## 7. 烧录和运行步骤

1. 编译并确认 `all-app.bin` 已生成。
2. 让开发板进入下载模式，用 BKFIL 或 SDK 支持的 BK7258 下载工具选择该完整镜像并执行整包烧录。
3. 烧录完成后退出下载模式并复位。
4. 打开扩展板 USB Type-C 对应串口：115200、8 数据位、1 停止位、无校验、无流控。
5. AT 终端行尾设为 CRLF；先发送 `AT`，再逐条执行 Wi-Fi 命令。
6. 串口被下载工具占用时，先关闭下载工具的串口连接。

## 8. 预期日志或现象

AP 启动任务延时约 1.5 秒后会打印：

```text
READY: wifi_at_test
USB-C (CP UART0), 115200 8N1, send Wi-Fi AT directly
scan: AT+WIFISCAN
connect: AT+STASTART=<SSID>,<PASSWORD>
```

基本 AT 连通性预期：

```text
AT
CMDRSP:OK
```

扫描、连接和 DHCP 是异步过程，`EVT:` 日志可能与 `CMDRSP:` 前后交错。连接验收应以 STA 已连接并获得 IP 为准，而不是只看到某一条 `OK`。

## 9. CLI/AT 操作方法

所有下列命令都直接发送，不加 `ap_cmd`，并等待上一条返回后再发下一条。

```text
AT
AT+WIFISCAN
AT+WIFISCAN=YourSSID
AT+STASTART=YourSSID,YourPassword
AT+WIFISTATUS=STA
AT+WIFISTATUS=STA,IP
AT+WIFISTATUS=STA,RSSI
AT+WIFISTATUS=STA,SSID
AT+WIFISTATUS=STA,BSSID
AT+WIFISTATUS=STA,CHANNEL
AT+STASTOP
```

开放网络可省略密码：

```text
AT+STASTART=OpenSSID
```

SoftAP 示例：

```text
AT+SAPSTART=BK7258_AP,12345678,6
AT+WIFISTATUS=AP
AT+WIFISTATUS=AP,IP
AT+SAPSTOP
```

`AT+SAPSTART` 的第二参数长度不超过 2 时会被实现解释为信道；需要密码时应使用合法的至少 8 字符密码。SSID/密码含逗号时会与 AT 参数分隔冲突，不适合作为本例测试输入。

## 10. 常见问题

- `AT` 无响应：检查串口号、115200、CRLF、USB 数据线、下载工具占用和是否烧录了本工程。
- 扫描不到热点：确认热点开启 2.4 GHz、未隐藏 SSID、天线未被金属遮挡，并等待扫描结束。
- 连接失败：确认大小写、密码、路由器准入策略和 DHCP 地址池；先执行 `AT+STASTOP` 再重试。
- 已关联但不能联网：先查 `AT+WIFISTATUS=STA,IP`；无 IP 优先排查 DHCP，有 IP 再排查网关/DNS。
- 输出顺序看似混乱：Wi-Fi 事件异步上报属于正常现象，按最终状态判断。

## 11. 代码入口

- `ap/ap_main.c`：`main()` 调用 `bk_init()`、板级总电源初始化，并创建启动提示任务。
- `ap/CMakeLists.txt`：注册 `ap_main.c`，依赖 `bk_cli` 和 `bsp_gpio`。
- `cp/CMakeLists.txt`：直接注册工程自己的 `cp_main.c`。
- `ap/config/bk7258_ap/config`、`cp/config/bk7258/config`：分别控制 AP/CP 的 AT、UART 和 Wi-Fi 配置。
- `partitions/bk7258/auto_partitions.csv`：定义完整镜像的 Flash 布局。

## 12. 可扩展方向

- 增加连接失败原因、重试次数和耗时统计。
- 在不泄露密码的前提下保存测试网络配置。
- 增加 TCP/UDP、HTTP、DNS 和吞吐测试。
- 对扫描结果按 RSSI 或安全类型筛选。
- 编写串口回归脚本，但应等待每条命令完成并处理异步事件。

## 13. 相关示例

- [`../../docs/examples/connectivity/wifi-at.md`](../../docs/examples/connectivity/wifi-at.md)：Wi-Fi 基础概念、AT 命令与故障排查（面向用户的说明文档）。
- `projects/ble_at_test`：同一 USB 串口下的 BLE AT 与 AP/CP 路径对比。
- `projects/codepulse_desk`：Wi-Fi SoftAP 网页配网、STA 自动重连和 HTTP 数据通道。
- `projects/digital_camera`：AP 侧 CLI 需由 CP 串口使用 `ap_cmd` 转发的对照示例。

## 14. 验收清单

- `AT` 返回 `CMDRSP:OK`。
- `AT+WIFISCAN` 能发现已知 2.4 GHz 热点。
- `AT+STASTART` 后能获得 IP，状态/IP/RSSI 查询均有效。
- `AT+STASTOP` 能断开。
- 可选 SoftAP 能被手机发现、连接并正常停止。
