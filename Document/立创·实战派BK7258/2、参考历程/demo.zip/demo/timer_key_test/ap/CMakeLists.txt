set(incs .)
set(srcs ap_main.c timer_key.c)

set(priv_req bk_common bsp_key driver)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
