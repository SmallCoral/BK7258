/**
 * @file timer_key.c
 * @brief 硬件定时器 + 按键中断例程实现
 *
 * TIMER3 提供 1 ms 时基，SW2（GPIO7）按下时打印自启动以来的毫秒计数。
 */

#include "timer_key.h"

#include <components/log.h>
#include <driver/timer.h>

#include "bsp_key.h"

#define TAG "timer_key"

/* AP 侧 CONFIG_TIMER_SUPPORT_ID_BITS=56，仅 TIMER3/4/5 可用 */
#define DEMO_TIMER_ID  TIMER_ID3

static volatile uint32_t s_tick_ms;

/**
 * @brief TIMER3 1 ms 中断服务，递增毫秒计数
 *
 * @param timer_id 定时器 ID（未使用）
 */
static void tick_timer_isr(timer_id_t timer_id)
{
	(void)timer_id;
	s_tick_ms++;
}

/**
 * @brief SW2 按键事件回调，按下时打印当前毫秒数
 *
 * @param ev  按键事件类型
 * @param arg 用户参数（未使用）
 */
static void on_key_event(bsp_key_event_t ev, void *arg)
{
	uint32_t time_ms;

	(void)arg;

	if (ev != BSP_KEY_EVENT_PRESSED) {
		return;
	}

	time_ms = s_tick_ms;
	BK_LOGI(TAG, "SW2 pressed: time=%ums\r\n", (unsigned)time_ms);
}

bk_err_t timer_key_init(void)
{
	bk_err_t ret;
	bsp_key_cfg_t key_cfg = { .cb = on_key_event };

	ret = bk_timer_start(DEMO_TIMER_ID, 1, tick_timer_isr);
	if (ret != BK_OK) {
		BK_LOGE(TAG, "FAIL: timer start (%d)\r\n", ret);
		return ret;
	}

	ret = bsp_key_init(&key_cfg);
	if (ret != BK_OK) {
		bk_timer_stop(DEMO_TIMER_ID);
		BK_LOGE(TAG, "FAIL: SW2 key init (%d)\r\n", ret);
		return ret;
	}

	BK_LOGI(TAG, "READY: timer_key_test\r\n");
	BK_LOGI(TAG, "Press SW2 to print time ms\r\n");
	BK_LOGI(TAG, "hw timer3 1ms tick + SW2 GPIO7 interrupt\r\n");
	return BK_OK;
}
