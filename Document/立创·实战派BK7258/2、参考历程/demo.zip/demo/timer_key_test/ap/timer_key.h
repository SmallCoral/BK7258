/**
 * @file timer_key.h
 * @brief 硬件定时器 + 按键中断例程对外接口
 *
 * 使用 TIMER3 提供 1 ms 时基，SW2（GPIO7）按下时打印累计毫秒数。
 */

#pragma once

#include <common/bk_err.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 启动 1 ms 硬件定时器并初始化 SW2 按键中断
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功
 * @retval 其他  定时器或按键驱动初始化失败
 */
bk_err_t timer_key_init(void);

#ifdef __cplusplus
}
#endif
