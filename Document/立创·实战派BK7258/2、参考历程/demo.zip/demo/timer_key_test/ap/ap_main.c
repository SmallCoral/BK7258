/**
 * @file ap_main.c
 * @brief 硬件定时器 + 按键中断演示工程入口
 *
 * 启动 1 ms 硬件定时器并注册 SW2 按键中断，按下时在串口打印累计毫秒数。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>

#include "timer_key.h"

#define TAG "timer_key"

/**
 * @brief AP 应用入口：系统初始化并启动定时器与按键例程
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}

	if (timer_key_init() != BK_OK) {
		return -1;
	}

	return 0;
}
