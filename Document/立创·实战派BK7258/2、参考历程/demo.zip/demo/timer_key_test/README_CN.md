# 定时器 + 按键中断例程

演示 **硬件定时器中断计时** 与 **GPIO 按键中断** 的配合：

- 硬件定时器 **TIMER3** 每 **1ms** 触发一次中断，累计运行毫秒数
- **SW2（GPIO7）** 下降沿触发 GPIO 中断，消抖后打印当前计时值

## 预期日志

```text
READY: timer_key_test
Press SW2 to print time ms
hw timer3 1ms tick + SW2 GPIO7 interrupt
SW2 pressed: time=5234ms
SW2 pressed: time=8912ms
...
```

- `time`：自上电以来定时器中断累计的毫秒数

## 构建与烧录

```bash
cd projects/timer_key_test
make bk7258
```

固件：`build/bk7258/timer_key_test/package/all-app.bin`

烧录后以 **115200** 打开 CP UART0，按板载 **SW2** 即可看到输出。

## 工作原理

```text
TIMER3(1ms) ──ISR──> s_tick_ms++
                         ^
SW2 GPIO7 ──下降沿ISR──> 消抖线程 ──> 读取 s_tick_ms 并打印
```

| 模块 | 说明 |
|------|------|
| `bk_timer_start(TIMER_ID3, 1, tick_timer_isr)` | 硬件定时器 1ms 周期中断（AP 仅 TIMER3/4/5 可用） |
| `tick_timer_isr` | ISR 内仅 `s_tick_ms++`，不做阻塞操作 |
| `bsp_key_init` | GPIO7 上拉输入 + 下降沿中断 + 20ms 消抖 |
| `on_key_event` | 按键确认后打印 `time` |

## 硬件

- **SW2**：GPIO7，按下为低（见 `board_design/pinmap.md`）
- 定时器选用 **TIMER_ID3**（AP 侧 `CONFIG_TIMER_SUPPORT_ID_BITS=56`，仅 3/4/5 可用）

## 关键文件

| 文件 | 说明 |
|------|------|
| `ap/timer_key.c` | 定时器 ISR + 按键回调 |
| `ap/ap_main.c` | 板级上电与初始化 |
| `components/bsp_key/` | SW2 GPIO 中断与消抖 |

## 参考

- SDK 定时器 API：`bk_avdk_smp_sdk/ap/include/driver/timer.h`
- 按键例程：`projects/key_test`
