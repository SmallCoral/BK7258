$helper = Join-Path $PSScriptRoot "../../scripts/project_dbuild.ps1"
& $helper $PSScriptRoot @args
exit $LASTEXITCODE
