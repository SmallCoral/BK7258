# BK7258 扩展板播放器服务示例（music_player）

本文件是 `music_player` 的唯一主文档。工程基于 `bk_player_service`，支持内置数组提示音、VFS 文件播放、提示音插播和板载麦克风到喇叭的语音回环。

## 示例目标

- 通过 CLI 播放内置 PCM、MP3、WAV 提示音；
- 从已挂载的 VFS 路径播放媒体文件；
- 在语音回环运行时测试多输入提示音；
- 验证 BK7258 Audio DAC、板载模拟麦克风、MS8002 功放和喇叭链路。

工程上电只初始化媒体服务和 CLI，不会自动播放。

## 学习内容

- 使用 `bk_player_service` 创建、配置、启动、停止和销毁播放器；
- 使用数组 URI 与 VFS URI，并显式指定数组音源的解码类型；
- 通过 `voice_service` 建立板载 MIC → G711A → 板载喇叭回环；
- 使用多输入 speaker port 在回环期间插播提示音；
- 理解 CP 串口 CLI 通过 `ap_cmd` 转发 AP 业务命令。

## 硬件要求和引脚

- 立创 BK7258 扩展板、板载喇叭、支持数据传输的 USB Type-C 线；
- Audio DAC 使用专用模拟脚 AUDLP/AUDLN，经 MS8002 功放接板载喇叭；
- 板载模拟 MIC 使用专用音频输入脚，不是 I2S；
- GPIO8 为高有效播放电源/PA 控制，GPIO22 为外部 3.3 V 总使能；
- 使用 VFS 文件时还需 FAT32 TF 卡：SDIO 为 GPIO14～GPIO19，GPIO47 为低有效卡检测；
- USB-C 对应 CP UART0，GPIO10/11 用于下载和日志。

不要把喇叭接到电池座或 3.3 V。内置 `array` 音源不需要 TF 卡。

## 软件配置

- `ap/CMakeLists.txt` 始终编入播放器 CLI；启用 `CONFIG_VOICE_SERVICE_TEST` 和多源 speaker 后再编入语音 CLI；
- AP 配置已启用 array/VFS stream、MP3/WAV 解码、板载 MIC/SPK、voice read/write service、FATFS SD 卡和 SDIO Host；
- `prompt_tone_test.h` 内含 ID 0～2 的测试音数据；
- `bsp_audio` 将 GPIO8 配为高有效 PA，并应用暂定喇叭增益；
- 工程分区文件的 AP 应用区为 1292 KiB；构建时使用 `partitions/bk7258/auto_partitions.csv`，不要换用其他工程分区。

## 编译命令

默认目录结构为 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。在本工程目录执行：

```bash
make bk7258
```

SDK 不在默认位置时：

```bash
make bk7258 SDK_DIR=/path/to/bk_avdk_smp_sdk
```

Docker wrapper：

```bash
./dbuild.sh bk7258
```

也可在运行 wrapper 前设置 `SDK_DIR`。

## 固件位置

```text
build/bk7258/music_player/package/all-app.bin
```

烧录时选择完整的 `all-app.bin`，不要选择 AP、CP 等中间镜像。

## 烧录和运行步骤

1. USB Type-C 连接开发板，关闭占用串口的终端；
2. 在 BKFIL 开发模式中选择开发板串口和上述 `all-app.bin`；
3. 下载波特率可设为 1500000，应用复位波特率设为 115200，开始烧录；
4. 烧录完成后释放串口，以 `115200、8N1、无流控` 打开日志并复位；
5. 等待 CLI 可用，先执行内置 PCM 命令 `ap_cmd player_service playback start array 0`；
6. 需要测试 VFS 时，再断电插入已准备媒体文件的 FAT32 TF 卡并按下文挂载。

## 预期日志或现象

启动完成后应看到稳定锚点，随后发送有效命令会返回：

```text
READY: player service CLI
CMDRSP:OK
```

播放期间还可能看到 `PLAYER_EVENT_MUSIC_INFO`、`PLAYER_EVENT_FINISH` 或 pipeline 状态日志。内置 ID 0 应播放短促 PCM 提示音，ID 1 为 MP3，ID 2 为 WAV。

`CMDRSP:OK` 只表示 CLI 处理成功，不等于扬声器功能 PASS。最终必须实际听到正确内容，并人工验收音量、底噪、失真和削波。当前 player 喇叭数字/模拟增益 `0x2D/0x08`、多音源端口增益 `0x2D/0x01`、麦克风数字/模拟增益 `0x2D/0x0A` 均为板级暂定值；多音源端口保留历史值以避免本次重构改变响度。

VFS 媒体不存在、TF 卡未挂载或文件损坏时，应将该用例记为环境 SKIP/失败，不能因为收到 `CMDRSP:OK` 就记为功能 PASS。

## CLI/AT 操作方法

播放器命令注册在 AP，USB-C 串口默认连接 CP CLI，因此全部业务命令须带 `ap_cmd`。

内置音源：

```text
# ID 0：PCM；ID 1：MP3；ID 2：WAV
ap_cmd player_service playback start array 0
ap_cmd player_service playback start array 1
ap_cmd player_service playback start array 2
ap_cmd player_service playback stop
```

VFS 文件播放：

```text
ap_cmd vfs mount fatfs /sd0
ap_cmd player_service playback start vfs /sd0/test.mp3
ap_cmd player_service playback stop
ap_cmd vfs umount /sd0
```

命令不会自动提供 `/sd0/test.mp3`。测试前必须确认文件真实存在且格式受支持，否则按环境 SKIP/失败处理。

8 kHz G711A 板载 MIC 回环：

```text
ap_cmd voice_service start onboard 8000 1 g711a g711a onboard 8000 0
ap_cmd voice_service stop onboard 8000 1 g711a g711a onboard 8000 0
```

回环运行时插播提示音，`tone_id` 使用 1 或 2，停止时也必须携带 ID：

```text
ap_cmd player_service prompt_tone start 1 array 0
ap_cmd player_service prompt_tone stop 1
```

源码还接受特定的 16 kHz G711A、AAC、G722 和 I2S 组合；参数必须与 `cli_voice_service.c` 中列出的组合完全一致。本工程没有 AT 命令接口。

## 常见问题

- `cmd NOT found: player_service`：缺少 `ap_cmd`，或烧录的不是本工程固件；
- `CMDRSP:OK` 但无声：确认 GPIO8/PA、喇叭和音源；CLI 成功不能代替听感验收；
- VFS 播放无声或异步失败：先确认 `/sd0` 已挂载且文件存在；缺媒体记环境 SKIP/失败；
- `voice service start timeout`：5 秒内未收到麦克风数据；检查麦克风链路和完整参数；
- `test command not support`：voice 命令参数组合不在源码支持列表内；
- `gl_voice_service_handle is NULL`：必须先启动 voice service，再使用 `prompt_tone`；
- 音量太小、过大或失真：当前增益为暂定值，按硬件实测和人工听感统一标定；
- 串口无响应：确认使用 115200、8N1，并关闭其他占用同一串口的烧录或日志工具。

## 代码入口

- `ap/ap_main.c`：初始化总电源、PA、媒体服务和两组 CLI；
- `ap/player_service_test/cli_player_service.c`：playback、prompt tone 和播放器生命周期；
- `ap/player_service_test/prompt_tone_test.h`：三个内置数组音源；
- `ap/voice_service_test/cli_voice_service.c`：MIC/SPK 回环、编码组合与 CLI；
- `ap/config/bk7258_ap/config`：播放器、voice、多源 speaker、解码器和 SD 卡配置；
- `partitions/bk7258/auto_partitions.csv`：本工程 Flash 分区。

## 可扩展方向

- 增加自动播放、播放列表、暂停/继续、音量和进度命令；
- 为 VFS 播放增加文件存在性检查和明确的异步完成状态；
- 将自定义提示音转换为数组，或统一通过文件系统管理媒体；
- 增加拔卡、损坏媒体、重复 start/stop 和资源释放测试；
- 基于示波器、不同喇叭负载与人工听感完成增益标定。

## 相关示例

- `../voice_input_test/`：MIC1 录音到 TF 卡 WAV；
- `../voice_output_test/`：上电自动播放 TF 卡 MP3；
- `../sdcard_test/`：单独验证 TF 卡检测、SDIO 和 FATFS；
- `../../docs/examples/peripherals/mic-spk.md`：MIC 录音与 SPK 回放说明；
- `../../docs/examples/peripherals/tf-spk.md`：TF 卡 MP3 与 SPK 播放说明。
