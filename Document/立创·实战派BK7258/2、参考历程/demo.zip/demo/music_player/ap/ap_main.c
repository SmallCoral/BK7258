/**
 * @file ap_main.c
 * @brief 音乐播放器 / 语音服务 CLI 演示工程入口
 *
 * 初始化板级电源、音频 PA 与 media_service，注册 player_service 与
 * voice_service（可选）CLI 命令。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>
#include "cli_player_service.h"
#include "bsp_audio.h"
#include "bsp_gpio.h"
#if (CONFIG_VOICE_SERVICE_TEST && CONFIG_ADK_ONBOARD_SPEAKER_STREAM_SUPPORT_MULTIPLE_SOURCE)
#include "cli_voice_service.h"
#endif

#define TAG "music_player"

/**
 * @brief AP 应用入口：初始化电源、媒体服务并注册 CLI
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}
    if (bsp_gpio_init_power_master() != BK_OK) {
        BK_LOGE(TAG, "FAIL: board power init\r\n");
        return -1;
    }
    bsp_audio_pa_power_on();
    if (media_service_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: media service init\r\n");
        bsp_audio_pa_power_off();
        return -1;
    }

    if (cli_player_service_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: player CLI init\r\n");
        bsp_audio_pa_power_off();
        return -1;
    }
#if (CONFIG_VOICE_SERVICE_TEST && CONFIG_ADK_ONBOARD_SPEAKER_STREAM_SUPPORT_MULTIPLE_SOURCE)
    if (cli_voice_service_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: voice CLI init\r\n");
        bsp_audio_pa_power_off();
        return -1;
    }
#endif

    BK_LOGI(TAG, "READY: player service CLI\r\n");
	return 0;
}
