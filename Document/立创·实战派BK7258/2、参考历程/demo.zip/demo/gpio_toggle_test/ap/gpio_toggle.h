/**
 * @file gpio_toggle.h
 * @brief GPIO20 周期翻转例程对外接口
 *
 * 将扩展口 GPIO20（PORT_I2C_SCL）配置为推挽输出，支持 500 ms 自动翻转与 CLI 手动控制。
 */

#pragma once

#include <common/bk_err.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 GPIO20 输出、注册 CLI 并启动自动翻转
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功
 * @retval 其他  GPIO/定时器/CLI 注册失败
 */
bk_err_t gpio_toggle_init(void);

#ifdef __cplusplus
}
#endif
