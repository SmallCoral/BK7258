/**
 * @file gpio_toggle.c
 * @brief GPIO20 周期翻转例程实现
 *
 * 解除 GPIO20 的 I2C0_SCL 复用后配置为推挽输出，500 ms 定时翻转，并提供 CLI 手动控制。
 */

#include "gpio_toggle.h"

#include <cli.h>
#include <components/log.h>
#include <driver/gpio.h>
#include <gpio_driver.h>
#include <os/os.h>
#include <os/str.h>

/** @brief 日志 TAG */
#define TAG "gpio_tg"
/** @brief 被测引脚：GPIO20（PORT_I2C_SCL） */
#define GPIO_TOGGLE_PIN GPIO_20
/** @brief 自动翻转周期（ms） */
#define GPIO_TOGGLE_INTERVAL_MS 500

static beken_timer_t s_toggle_timer;
static volatile bool s_level_high;
static volatile bool s_auto_running;

/**
 * @brief 将 GPIO20 设为指定电平并更新内部状态
 * @param high true=高电平，false=低电平
 */
static void gpio_toggle_apply(bool high)
{
    if (high) {
        bk_gpio_set_output_high(GPIO_TOGGLE_PIN);
    } else {
        bk_gpio_set_output_low(GPIO_TOGGLE_PIN);
    }
    s_level_high = high;
}

static void gpio_toggle_timer_cb(void *arg)
{
    (void)arg;

    /* 定时器回调中只翻转电平，不打印日志、不执行阻塞操作。 */
    gpio_toggle_apply(!s_level_high);
}

/**
 * @brief 启动自动翻转定时器
 *
 * @return 操作结果
 * @retval BK_OK 已运行或启动成功
 */
static bk_err_t gpio_toggle_start(void)
{
    if (s_auto_running) {
        return BK_OK;
    }

    bk_err_t result = rtos_start_timer(&s_toggle_timer);
    if (result == BK_OK) {
        s_auto_running = true;
    }
    return result;
}

/**
 * @brief 停止自动翻转定时器
 *
 * @return 操作结果
 * @retval BK_OK 已停止或停止成功
 */
static bk_err_t gpio_toggle_stop(void)
{
    if (!s_auto_running) {
        return BK_OK;
    }

    bk_err_t result = rtos_stop_timer(&s_toggle_timer);
    if (result == BK_OK) {
        s_auto_running = false;
    }
    return result;
}

/**
 * @brief `gpio_toggle` CLI 命令处理
 *
 * @param buffer     响应写入缓冲区
 * @param buffer_len 缓冲区长度
 * @param argc       参数个数
 * @param argv       参数列表（start/stop/high/low/toggle/status）
 */
static void gpio_toggle_cli(char *buffer, int buffer_len,
                            int argc, char **argv)
{
    if (argc < 2 || os_strcmp(argv[1], "help") == 0) {
        os_snprintf(buffer, buffer_len,
                    "gpio_toggle start|stop|high|low|toggle|status\r\n");
        return;
    }

    bk_err_t result = BK_OK;
    if (os_strcmp(argv[1], "start") == 0) {
        result = gpio_toggle_start();
    } else if (os_strcmp(argv[1], "stop") == 0) {
        result = gpio_toggle_stop();
    } else if (os_strcmp(argv[1], "high") == 0) {
        result = gpio_toggle_stop();
        if (result == BK_OK) {
            gpio_toggle_apply(true);
        }
    } else if (os_strcmp(argv[1], "low") == 0) {
        result = gpio_toggle_stop();
        if (result == BK_OK) {
            gpio_toggle_apply(false);
        }
    } else if (os_strcmp(argv[1], "toggle") == 0) {
        result = gpio_toggle_stop();
        if (result == BK_OK) {
            gpio_toggle_apply(!s_level_high);
        }
    } else if (os_strcmp(argv[1], "status") != 0) {
        result = BK_ERR_PARAM;
    }

    if (result == BK_OK) {
        os_snprintf(buffer, buffer_len,
                    "pin=GPIO20 level=%s auto=%s interval=%ums\r\n",
                    s_level_high ? "HIGH" : "LOW",
                    s_auto_running ? "running" : "stopped",
                    GPIO_TOGGLE_INTERVAL_MS);
    } else {
        os_snprintf(buffer, buffer_len,
                    "ERROR: invalid command or operation failed (%d)\r\n",
                    result);
    }
}

static const struct cli_command s_gpio_toggle_commands[] = {
    {
        "gpio_toggle",
        "start|stop|high|low|toggle|status",
        gpio_toggle_cli,
    },
};

bk_err_t gpio_toggle_init(void)
{
    bk_err_t result = bk_gpio_driver_init();
    if (result != BK_OK) {
        return result;
    }

    /*
     * GPIO20 默认映射为 I2C0_SCL。本例程不使用 I2C0，先解除外设映射，
     * 再将其配置为普通推挽输出，避免 BK_ERR_GPIO_INTERNAL_USED。
     */
    gpio_dev_unmap(GPIO_TOGGLE_PIN);

    gpio_config_t config = {
        .io_mode = GPIO_OUTPUT_ENABLE,
        .pull_mode = GPIO_PULL_DISABLE,
        .func_mode = GPIO_SECOND_FUNC_DISABLE,
    };
    result = bk_gpio_set_config(GPIO_TOGGLE_PIN, &config);
    if (result != BK_OK) {
        return result;
    }

    gpio_toggle_apply(false);

    if (!rtos_is_timer_init(&s_toggle_timer)) {
        result = rtos_init_timer(
            &s_toggle_timer,
            GPIO_TOGGLE_INTERVAL_MS,
            gpio_toggle_timer_cb,
            NULL);
        if (result != BK_OK) {
            return result;
        }
    }

    result = cli_register_commands(
        s_gpio_toggle_commands,
        sizeof(s_gpio_toggle_commands) /
            sizeof(s_gpio_toggle_commands[0]));
    if (result != BK_OK) {
        return result;
    }

    result = gpio_toggle_start();
    if (result != BK_OK) {
        return result;
    }

    BK_LOGI(TAG,
            "GPIO toggle init done, pin=%d, interval=%dms, initial=LOW\r\n",
            GPIO_TOGGLE_PIN,
            GPIO_TOGGLE_INTERVAL_MS);
    return BK_OK;
}
