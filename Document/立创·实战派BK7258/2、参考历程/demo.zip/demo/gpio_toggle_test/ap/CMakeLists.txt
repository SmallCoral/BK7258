set(incs .)
set(srcs ap_main.c gpio_toggle.c)

set(priv_req)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
