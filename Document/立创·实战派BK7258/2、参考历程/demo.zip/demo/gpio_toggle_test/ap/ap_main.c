/**
 * @file ap_main.c
 * @brief GPIO20 电平翻转演示工程入口
 *
 * 初始化系统后启动 GPIO20 自动翻转与 CLI，可用 `ap_cmd gpio_toggle help` 手动控制。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>

#include "gpio_toggle.h"

#define TAG "gpio_tg"

/**
 * @brief AP 应用入口：系统初始化并启动 GPIO 翻转例程
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }

    if (gpio_toggle_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: GPIO toggle init\r\n");
        return -1;
    }

    BK_LOGI(TAG, "READY: GPIO20 level toggle demo\r\n");
    BK_LOGI(TAG, "CLI: ap_cmd gpio_toggle help\r\n");
    return 0;
}
