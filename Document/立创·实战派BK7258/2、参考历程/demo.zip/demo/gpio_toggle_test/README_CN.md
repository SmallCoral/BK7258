# GPIO 电平翻转示例

## 示例目标

使用 AP 核将扩展口 `GPIO20 / PORT_I2C_SCL` 配置为普通输出，验证周期翻转和 CLI 电平控制。

## 学习内容

- GPIO 外设复用解除、输出初始化和电平读写。
- 软件定时器驱动的 500 ms 周期翻转。
- 通过 AP CLI 启停定时器并手动控制电平。

## 硬件要求和引脚

- GPIO20 的电平范围为 0～3.3 V，禁止连接 5 V。
- 测量时将示波器探头接 GPIO20，地夹接开发板 GND。
- GPIO20 默认复用为 I2C0_SCL，本例会解除该复用，因此不能同时使用 I2C0。
- 不要将 GPIO20 直接与 GND、3.3 V 或另一个推挽输出短接。

## 软件配置

- 工程使用统一 AP/CP 骨架和板级 GPIO 配置转发。
- `ram_regions.csv` 声明完整 16 MiB PSRAM，AP PSRAM heap 为 `0x8C0000`。
- 启动后 GPIO20 先输出低电平，再以约 1 Hz、50% 占空比自动翻转。

## 编译命令

```bash
cd projects/gpio_toggle_test
make bk7258
```

## 固件位置

`build/bk7258/gpio_toggle_test/package/all-app.bin`

## 烧录和运行步骤

1. 烧录整包固件并复位开发板。
2. 打开 CP UART0，等待稳定启动锚点。
3. 使用万用表、示波器或逻辑分析仪测量 GPIO20。
4. 通过 CLI 切换自动翻转和固定电平。

## 预期日志或现象

```text
GPIO toggle init done, pin=20, interval=500ms, initial=LOW
READY: GPIO20 level toggle demo
```

GPIO20 的低电平约 0 V、高电平约 3.3 V，高低电平各保持约 500 ms。启动时出现解除 GPIO20 默认外设映射的警告属于正常现象。

## CLI/AT 操作方法

```text
ap_cmd gpio_toggle help
ap_cmd gpio_toggle start
ap_cmd gpio_toggle stop
ap_cmd gpio_toggle high
ap_cmd gpio_toggle low
ap_cmd gpio_toggle toggle
ap_cmd gpio_toggle status
```

执行 `high`、`low` 或 `toggle` 会停止周期翻转；执行 `start` 可恢复自动翻转。

## 常见问题

- 没有波形：确认探头连接 GPIO20 和 GND，并执行 `ap_cmd gpio_toggle start`。
- 电平固定：执行 `status` 检查自动翻转状态，确认没有执行过 `high`、`low` 或 `toggle`。
- I2C0 不工作：本例占用 GPIO20 并解除 I2C0_SCL 复用，两者不能同时使用。

## 代码入口

- `ap/ap_main.c`：系统初始化、业务初始化和 READY 日志。
- `ap/gpio_toggle.c`：GPIO、软件定时器和 CLI 实现。
- `ap/gpio_toggle.h`：业务接口声明。

## 可扩展方向

- 支持通过 CLI 修改翻转周期。
- 增加多个扩展 GPIO 的独立控制。
- 增加周期误差和长时间稳定性统计。

## 相关示例

- `key_test`：GPIO 中断输入与按键消抖。
- `key_lcd_demo`：按键输入与 LCD 输出的组合示例。
- `uart_test`：扩展口 UART1 收发与环回验证。
