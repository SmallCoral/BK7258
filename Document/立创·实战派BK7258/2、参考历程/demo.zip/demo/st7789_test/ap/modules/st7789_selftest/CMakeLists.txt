armino_component_register(
    SRCS "st7789_selftest.c"
    INCLUDE_DIRS "."
    PRIV_REQUIRES multimedia bk_display bk_peripheral bk_cli bsp_gpio bsp_lcd_st7789
)
