/**
 * @file st7789_selftest.h
 * @brief ST7789 SPI LCD 纯色循环自测对外接口
 *
 * 开机自动循环显示红/绿/蓝全屏色块；支持 `lcd_test` CLI 手动控制。
 */

#pragma once

#include <common/bk_err.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 ST7789 配置、注册 CLI 并启动自测线程
 *
 * @return 操作结果
 * @retval BK_OK 初始化成功（幂等）
 * @retval BK_FAIL ST7789 配置、CLI 或线程创建失败
 */
bk_err_t st7789_selftest_init(void);

/** @brief 停止自测线程、关闭 LCD 并注销 CLI */
void st7789_selftest_deinit(void);

#ifdef __cplusplus
}
#endif
