# st7789_test：ST7789V2 SPI 屏点亮与纯色自检

本 README 依据工程当前的 C、CMake、config、分区文件及 LCD 板级组件编写。颜色和日志是源码定义的验收判据；本次文档整理不等同于上板实测，最终需人工观察屏幕。

## 示例目标

初始化扩展板上的 240×320 ST7789V2 屏，上电后自动以 RGB565 依次刷红、绿、蓝纯色共 6 帧，并提供 CLI 重跑和关闭显示。

## 学习内容

- 理解 LCD 电源、复位、D/C、背光与 SPI 总线的分工。
- 使用 `bk_display` 创建控制器、打开面板、分配帧缓冲并刷新。
- 通过板级 profile 设置竖屏、64 MHz 时钟和本屏必需的 `INVON`。
- 从 CP 串口 Shell 使用 `ap_cmd` 路由 AP 注册的命令。

## 硬件要求和引脚

- 立创 BK7258 开发板及扩展板、板载 ST7789V2 240×320 IPS 屏、USB 数据线。
- 显示总线使用 SPI1 的时钟/片选/MOSI；普通 GPIO 控制 D/C、复位、屏电源和低有效背光。
- 工程代码使用 `spi_id=1`、`BOARD_LCD_DC_PIN`、`BOARD_LCD_RST_PIN`、`BOARD_LCD_PWR_PIN`、`BOARD_LCD_BL_PIN`。
- 具体 GPIO 号、复用和有效电平以[板卡唯一权威映射](../../board_design/pinmap.md)、[`bsp_gpio.h`](../../components/bsp_gpio/bsp_gpio.h)和 [`bsp_lcd_st7789`](../../components/bsp_lcd_st7789/)为准，本文不维护可能漂移的完整引脚表。

## 软件配置

- AP CMake 依赖 `media_service`、`multimedia`、`bk_display`、`bsp_gpio` 和 `bsp_lcd_st7789`。
- 当前配置已启用 `CONFIG_LCD_SPI_ST7789V2`、LCD SPI/QSPI 刷新路径、PSRAM 及媒体显示内存。
- `ram_regions.csv` 为显示分配 PSRAM slab；单帧 RGB565 需要 `240 × 320 × 2` 字节，运行本例不要随意缩减显示内存。
- `usr_gpio_cfg.h` 使用统一板级静态映射；当前标准 AP/CP/OTA 分区无需修改。

## 编译命令

在本工程目录执行其一：

```bash
make bk7258
```

```bash
./dbuild.sh bk7258
```

默认目录布局为 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。需要排除旧产物时先执行 `make clean`。

## 固件位置

整机烧录文件为：

```text
build/bk7258/st7789_test/package/all-app.bin
```

应烧录 `package/all-app.bin`，不要改用 AP、CP 或分区中间镜像。

## 烧录和运行步骤

1. 连接 USB 数据线并确认 CH340K 串口。
2. 按[固件烧录参考](../../docs/reference/firmware-download.md)烧录上述固件。
3. 释放下载串口，按[串口控制台参考](../../docs/reference/serial-console.md)以 `115200 8N1`、无流控打开终端。
4. 短按复位键；程序延时约 500 ms 后自动打开 LCD 并开始纯色测试。
5. 观察红、绿、蓝各显示约 500 ms，默认顺序重复两轮。
6. 自动测试结束后，可使用 CLI 重跑或关闭屏幕。

## 预期日志或现象

自动流程完成时，串口应包含类似：

```text
READY: ST7789 selftest started
lcd color test done (240x320)
```

屏幕应按红→绿→蓝顺序切换两轮，并停留在最后一帧。人工硬件验收应确认：屏幕能上电、背光正常、三种颜色不是补色、画面无明显错位；本文不宣称本次修改已完成上板验证。若红显示成青、绿显示成品红或蓝显示成黄，通常说明未使用包含 `INVON` 的本板 profile。

## CLI/AT 操作方法

串口使用 `115200 8N1`，命令行尾使用 CRLF。命令注册在 AP，需从 CP Shell 加 `ap_cmd` 前缀：

```text
ap_cmd lcd_test open
ap_cmd lcd_test open 9
ap_cmd lcd_test close
```

- `open [loops]`：打开屏幕并刷新指定帧数，默认 6；颜色按红、绿、蓝循环。
- `close`：关闭背光、关闭并删除显示控制器。
- 本工程不是 AT 固件，不使用 `AT+...` 命令。

## 常见问题

- 背光亮但无图：检查首条 `bk_display_spi_new`、`bk_display_open` 或 `bk_display_flush` 错误，并核对屏电源、复位和 SPI1 映射。
- 颜色为补色：确认工程仍依赖 `bsp_lcd_st7789`，其初始化序列包含本屏必需的 `INVON(0x21)`。
- 提示帧缓冲分配失败：确认 PSRAM 初始化正常，且 `ram_regions.csv` 的显示内存没有被改小。
- 命令无响应：确认发送的是 `ap_cmd lcd_test ...`、行尾为 CRLF，且下载工具已释放串口。
- 通用烧录或串口问题见[通用排障](../../docs/reference/troubleshooting.md)。

## 代码入口

教学调用链：

```text
AP main()
  -> bk_init()
  -> power_master -> lcd GPIO -> key GPIO
  -> bsp_lcd_st7789_get(竖屏, 64 MHz)
       -> 生成 240x320 profile + INVON
  -> media_service_init()
  -> 注册 lcd_test
  -> lcd_selftest_thread()
       -> lcd_open()
          -> bk_display_spi_new()
          -> LCD 电源高 -> bk_display_open() -> 背光拉低点亮
       -> 分配 RGB565 帧 -> 填色 -> bk_display_flush()
       -> 释放帧缓冲
```

工程入口位于 [`ap/ap_main.c`](ap/ap_main.c)，单工程自检与生命周期位于
[`ap/modules/st7789_selftest`](ap/modules/st7789_selftest/)，面板初始化序列位于
[`components/bsp_lcd_st7789`](../../components/bsp_lcd_st7789/)。

## 可扩展方向

- 调整横竖屏与 X/Y 镜像，验证 MADCTL 组合。
- 在人工信号质量验收后比较 64 MHz 与其他合法时钟档位。
- 将纯色帧替换为渐变、色条、图片或 LVGL 界面。
- 增加刷新耗时、帧率和内存占用统计。

## 相关示例

- [SPI 总线与显示](../../docs/examples/base/SPI.md)：SPI 外设基础与 ST7789 刷屏说明。
- [LCD ST7789 外设例程](../../docs/examples/peripherals/lcd-st7789.md)：更完整的命令、原理和验收说明。
- [`lcd_tp_test`](../lcd_tp_test/)：LCD 与触摸组合。
- [`key_lcd_demo`](../key_lcd_demo/)：按键驱动 LCD 交互。
- [`dvp_lcd_demo`](../dvp_lcd_demo/)：摄像头画面显示。
- [`LVGL_example`](../LVGL_example/)：图形界面应用。
