// Copyright 2020-2021 Beken
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @file headset_user_config.h
 * @brief A2DP Sink / 蓝牙耳机用户配置宏
 *
 * 定义本地设备名、A2DP 缓存帧数、音量默认值与 GAP 扫描/重连参数等。
 */

#pragma once

/** @brief 启用 A2DP 音频播放路径 */
#define CONFIG_A2DP_AUDIO

/** @brief A2DP Sink 消息队列深度 */
#define BT_AUDIO_SINK_DEMO_MSG_COUNT          (60)

/** @brief 蓝牙本地名称前缀（后缀为 MAC 低 3 字节） */
#define LOCAL_NAME "BK7258_SPK"

/** @brief A2DP Sink 任务优先级 */
#define A2DP_SINK_DEMO_TASK_PRIORITY      (4)

/** @brief A2DP 解码帧缓存数量 */
#define CONFIG_A2DP_CACHE_FRAME_NUM    4

/** @brief 默认 A2DP 绝对音量（0x7F 为最大） */
#define DEFAULT_A2DP_VOLUME  0x5A

/** @brief Page Scan 间隔（单位 0.625 ms） */
#define PAGE_SCAN_INTV   0x0800  //1.28s
/** @brief Page Scan 窗口（单位 0.625 ms） */
#define PAGE_SCAN_WIN    0x00B4  //11.25ms

/** @brief Page 超时（单位 0.625 ms） */
#define CONFIG_PAGE_TIMEOUT  16000   //unit of 0.625ms
/** @brief 断线重连间隔（单位 ms） */
#define CONFIG_RECONN_INTERVAL  2000   //unit of 1ms

/** @brief Wi-Fi 共存方案选择 */
#define CONFIG_WIFI_COEX_SCHEME  0

/** @brief 是否使用旧版音频接口 */
#define CONFIG_USE_AUDIO_LEGACY_INTERFACE  0
/** @brief 板载音频输出声道数 */
#define CONFIG_BOARD_AUDIO_CHANNLE_NUM     1
