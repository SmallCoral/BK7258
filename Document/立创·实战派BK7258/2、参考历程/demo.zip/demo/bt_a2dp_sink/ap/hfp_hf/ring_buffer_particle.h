/**
 * @file ring_buffer_particle.h
 * @brief 字节级环形缓冲区接口（HFP SCO 音频缓存）
 */

#pragma once

#include <stdint.h>
#include <stdbool.h>

//#define INT_CEIL_4 (x) ((x) / 4 * 4 + ((x) % 4 ? 4 : 0))
//#define INT_FLOOR_4 (x) ((x) / 4 * 4)
#define INT_CEIL(x, size) ((x) / (size) * (size) + ((x) % (size) ? (size) : 0))
#define INT_FLOOR(x, size) ((x) / (size) * (size))

#define INT_CEIL_4(x) ((((size_t)(x)) & (~(size_t)3)) + ((((size_t)(x)) & 0b11) ? 0b100: 0))
#define INT_CEIL_4(x) ((((size_t)(x)) & (~(size_t)3)) + ((((size_t)(x)) & 0b11) ? 0b100: 0))
#define INT_FLOOR_4(x) (((size_t)(x)) & (~(size_t)3))

/** @brief 字节级环形缓冲区上下文。 */
typedef struct
{
    uint8_t *buffer;
    uint32_t len;
    uint32_t rp;
    uint32_t wp;
}ring_buffer_particle_ctx;

/**
 * @brief 分配并初始化环形缓冲区
 *
 * @param ctx 上下文指针
 * @param len 缓冲区长度（字节）
 * @return 0 成功，-1 失败
 */
int32_t ring_buffer_particle_init(ring_buffer_particle_ctx *ctx, uint32_t len);

/**
 * @brief 释放缓冲区并重置上下文
 *
 * @param ctx 上下文指针
 * @return 0 成功
 */
int32_t ring_buffer_particle_deinit(ring_buffer_particle_ctx *ctx);

/**
 * @brief 检查缓冲区是否已初始化
 *
 * @param ctx 上下文指针
 * @return true 已初始化
 */
bool ring_buffer_particle_is_init(ring_buffer_particle_ctx *ctx);

/**
 * @brief 重置读写指针（保留 buffer 内存）
 *
 * @param ctx 上下文指针
 * @return 0 成功
 */
int32_t ring_buffer_particle_reset(ring_buffer_particle_ctx *ctx);

/**
 * @brief 写入数据到环形缓冲区
 *
 * @param ctx  上下文指针
 * @param data 待写入数据
 * @param len  数据长度
 * @return 0 成功，-1 缓冲区满
 */
int32_t ring_buffer_particle_write(ring_buffer_particle_ctx *ctx, uint8_t *data, uint32_t len);

/**
 * @brief 从环形缓冲区读取数据
 *
 * @param ctx         上下文指针
 * @param buff        输出缓冲区
 * @param len         期望读取长度
 * @param already_len 实际读取长度
 * @return 0 成功
 */
int32_t ring_buffer_particle_read(ring_buffer_particle_ctx *ctx, uint8_t *buff, uint32_t len, uint32_t *already_len);

/**
 * @brief 获取当前已缓存数据长度
 *
 * @param ctx 上下文指针
 * @return 字节数
 */
uint32_t ring_buffer_particle_len(ring_buffer_particle_ctx *ctx);

/** @brief 打印读写指针与长度（调试）。 */
void ring_buffer_particle_debug(ring_buffer_particle_ctx *ctx);

/** @brief 自测读写与边界条件。 */
int32_t ring_buffer_particle_test(void);
