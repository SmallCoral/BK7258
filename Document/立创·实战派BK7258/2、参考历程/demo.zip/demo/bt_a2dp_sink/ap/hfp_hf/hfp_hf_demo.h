/**
 * @file hfp_hf_demo.h
 * @brief HFP Hands-Free 演示模块对外接口
 */

#ifndef HFP_HF_DEMO_H
#define HFP_HF_DEMO_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 HFP HF 演示
 *
 * @param msbc_supported 1 支持 mSBC 宽带语音，0 仅 CVSD
 * @return 0 成功，负数失败
 */
int hfp_hf_demo_init(uint8_t msbc_supported);

/**
 * @brief 启用/禁用语音识别（VR）
 *
 * @param enable 1 启用，0 禁用
 */
void hfp_demo_vr(uint8_t enable);

/**
 * @brief 拨号或挂断
 *
 * @param enable 1 拨号，0 挂断
 * @param num    号码字符串
 */
void hfp_demo_dial(uint8_t enable, uint8_t *num);

/**
 * @brief 接听或拒接来电
 *
 * @param accept 1 接听，0 拒接
 */
void hfp_demo_answer(uint8_t accept);

/**
 * @brief 发送自定义 AT 命令
 *
 * @param cmd AT 命令字符串
 */
void hfp_demo_cust_cmd(uint8_t *cmd);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*HFP_HF_DEMO_H*/
