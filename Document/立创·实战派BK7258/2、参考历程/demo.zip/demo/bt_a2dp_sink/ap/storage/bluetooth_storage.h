/**
 * @file bluetooth_storage.h
 * @brief 蓝牙配对信息（Link Key、音量、BLE Key）持久化接口
 */

#pragma once

#include <stdint.h>

#include "components/bluetooth/bk_dm_bluetooth_types.h"
#include "components/bluetooth/bk_dm_gap_ble_types.h"


#define BT_STORAGE_KEY "bluetooth_user_info"

#define BT_LINKKEY_MAX_SAVE_COUNT 3

/** @brief 单条经典蓝牙配对记录（地址 + Link Key + A2DP 音量）。 */
typedef struct __attribute__((packed))
{
    //    char addr[6 * 2 + 5 + 1];
    //    char link_key[16 * 2 + 1];
    uint8_t addr[6];
    uint8_t link_key[16];
    uint8_t a2dp_volume;
} bt_user_storage_elem_linkkey_t;


/** @brief 蓝牙用户存储结构（RAM 镜像，可同步到 EasyFlash）。 */
typedef struct __attribute__((packed))
{
    bt_user_storage_elem_linkkey_t linkkey[BT_LINKKEY_MAX_SAVE_COUNT];
#if CONFIG_BLE
    bk_ble_bond_dev_t ble_key[BT_LINKKEY_MAX_SAVE_COUNT];
    bk_ble_local_keys_t local_keys;
#endif
} bt_user_storage_t;


/**
 * @brief 初始化存储模块并从 Flash 加载
 *
 * @return 0 成功，-1 失败
 */
int32_t bluetooth_storage_init(void);

/**
 * @brief 释放存储模块内存
 *
 * @return 0 成功
 */
int32_t bluetooth_storage_deinit(void);

/**
 * @brief 按地址查找 Link Key 槽位
 *
 * @param addr 6 字节蓝牙地址
 * @param key  输出 Link Key（可为 NULL）
 * @return 槽位索引，-1 未找到
 */
int32_t bluetooth_storage_find_linkkey_info_index(uint8_t *addr, uint8_t *key);

/**
 * @brief 保存 Link Key（LRU 排序，最新在末尾）
 *
 * @param addr 设备地址
 * @param key  16 字节 Link Key
 * @return 槽位索引，-1 失败
 */
int32_t bluetooth_storage_save_linkkey_info(uint8_t *addr, uint8_t *key);

/**
 * @brief 删除指定设备的 Link Key
 *
 * @param addr 设备地址
 * @return 0 成功
 */
int32_t bluetooth_storage_del_linkkey_info(uint8_t *addr);

/**
 * @brief 将指定设备记录移到最新位置
 *
 * @param addr 设备地址
 * @return 0 成功，-1 未找到
 */
int32_t bluetooth_storage_update_to_newest(uint8_t *addr);

/**
 * @brief 获取最近配对的 Link Key
 *
 * @param addr 输出设备地址
 * @param key  输出 Link Key（可为 NULL）
 * @return 槽位索引，-1 无有效记录
 */
int32_t bluetooth_storage_get_newest_linkkey_info(uint8_t *addr, uint8_t *key);

/**
 * @brief 清空所有 Link Key 记录
 *
 * @return 0 成功
 */
int32_t bluetooth_storage_clean_linkkey_info(void);

/**
 * @brief 将 RAM 镜像写入 Flash
 *
 * @return 0 成功
 */
int32_t bluetooth_storage_sync_to_flash(void);

/** @brief 打印所有 Link Key 记录（调试）。 */
int32_t bluetooth_storage_linkkey_debug(void);

/**
 * @brief 按地址查找 A2DP 音量
 *
 * @param addr   设备地址
 * @param volume 输出音量值
 * @return 槽位索引，-1 未找到
 */
int32_t bluetooth_storage_find_volume_by_addr(uint8_t *addr, uint8_t *volume);

/**
 * @brief 保存 A2DP 音量到指定设备记录
 *
 * @param addr   设备地址
 * @param volume 音量值（0~0x7F）
 * @return 0 成功，-1 未找到设备
 */
int32_t bluetooth_storage_save_volume(uint8_t *addr, uint8_t volume);

#if CONFIG_BLE
int32_t bluetooth_storage_save_ble_key_info(bk_ble_bond_dev_t *list, uint32_t count);
int32_t bluetooth_storage_clean_ble_key_info(void);
int32_t bluetooth_storage_read_ble_key_info(bk_ble_bond_dev_t *list, uint32_t *count);

int32_t bluetooth_storage_save_local_key(bk_ble_local_keys_t *key);
int32_t bluetooth_storage_clean_local_key(void);
int32_t bluetooth_storage_read_local_key(bk_ble_local_keys_t *key);
#endif
