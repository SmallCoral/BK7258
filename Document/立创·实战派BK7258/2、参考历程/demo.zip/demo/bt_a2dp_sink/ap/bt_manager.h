/**
 * @file bt_manager.h
 * @brief 经典蓝牙连接状态机与 GAP 事件管理接口
 */

#include "components/bluetooth/bk_dm_bluetooth_types.h"
#include "components/bluetooth/bk_dm_bt_types.h"
#include "components/bluetooth/bk_dm_bt.h"
#include "components/bluetooth/bk_dm_gap_bt.h"

/** @brief 蓝牙管理器工作模式 */
enum
{
    BT_MNG_MODE_PAIRING = 1,       /**< 可连接且可被发现 */
    BT_MNG_MODE_RECONNECTING,      /**< 不可连接且不可被发现（重连中） */
    BT_MNG_MODE_CONNECTEED,        /**< 已连接，不可被发现 */
    BT_MNG_MODE_CONNECTABLE,       /**< 可连接但不可被发现 */
};

/** @brief 蓝牙链路/Profile 连接状态 */
enum
{
    BT_STATE_IDLE = 0,
    BT_STATE_WAIT_FOR_RECONNECT,
    BT_STATE_RECONNECTING,
    BT_STATE_LINK_CONNECTED,
    BT_STATE_PROFILE_CONNECTED,
    BT_STATE_KEY_MISSING,
};

typedef void (*btm_gap_event_cb)(bk_gap_bt_cb_event_t event, bk_bt_gap_cb_param_t *param);
typedef void (*btm_start_profile_connect_cb)(uint8_t *remote_addr);
typedef void (*btm_start_profile_disconnect_cb)(uint8_t *remote_addr);
typedef void (*btm_stop_profile_connect_cb)();

/** @brief Profile 层注册到 bt_manager 的回调集合 */
typedef struct 
{
    btm_gap_event_cb gap_cb;
    btm_start_profile_connect_cb start_connect_cb;
    btm_stop_profile_connect_cb stop_connect_cb;
    btm_start_profile_disconnect_cb start_disconnect_cb;
} btm_callback_s;

/**
 * @brief 注册 Profile 回调到 bt_manager
 *
 * @param cb 回调结构体指针
 * @return 槽位索引；MAX_PROFILE_NUM 表示注册失败
 */
int bt_manager_register_callback(btm_callback_s *cb);

/**
 * @brief 启动对指定设备的重连流程
 *
 * @param addr      6 字节蓝牙地址
 * @param immediate 1 立即重连，0 延迟 CONFIG_RECONN_INTERVAL ms
 */
void bt_manager_start_reconnect(uint8_t *addr, uint8_t immediate);

/**
 * @brief 设置 GAP 可见性/可连接性模式
 *
 * @param mode BT_MNG_MODE_* 枚举值
 */
void bt_manager_set_mode(uint8_t mode);

/**
 * @brief 初始化蓝牙存储、GAP 回调与本地设备名
 *
 * @return 0 成功，-1 存储初始化失败
 */
int bt_manager_init();

/**
 * @brief 获取当前连接状态
 *
 * @return BT_STATE_* 枚举值
 */
uint8_t bt_manager_get_connect_state();

/**
 * @brief 设置连接状态
 *
 * @param state BT_STATE_* 枚举值
 */
void bt_manager_set_connect_state(uint8_t state);

/**
 * @brief 获取当前重连目标地址
 *
 * @return 6 字节地址指针（内部缓冲）
 */
uint8_t* bt_manager_get_reconnect_device();

/**
 * @brief 获取当前已连接设备地址
 *
 * @return 6 字节地址指针（内部缓冲）
 */
uint8_t* bt_manager_get_connected_device();
