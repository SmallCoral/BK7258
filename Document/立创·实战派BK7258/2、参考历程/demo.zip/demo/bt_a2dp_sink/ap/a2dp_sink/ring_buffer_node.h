/**
 * @file ring_buffer_node.h
 * @brief 节点式环形缓冲区接口（A2DP 音频帧缓存）
 */

#ifndef __RING_BUFFER_NODE_H__
#define __RING_BUFFER_NODE_H__

#ifdef  __cplusplus
extern "C" {
#endif//__cplusplus

#include <stdint.h>
#include <os/os.h>

/** @brief 节点式环形缓冲区上下文。 */
typedef struct _RingBufferNodeContext
{
    uint8_t *address;   /**< 缓冲区基地址 */
    uint32_t node_len;  /**< 单节点字节长度 */
    uint32_t node_num;  /**< 节点总数 */
    uint32_t rp;        /**< 读指针（节点索引） */
    uint32_t wp;        /**< 写指针（节点索引） */
} RingBufferNodeContext;

/**
 * @brief 初始化节点式环形缓冲区
 *
 * @param rbn     上下文指针
 * @param address 缓冲区起始地址
 * @param node_len 单节点长度（字节）
 * @param nodes   节点数量
 */
void ring_buffer_node_init(RingBufferNodeContext *rbn, uint8_t *address, uint32_t node_len, uint32_t nodes);

/** @brief 反初始化（当前为空实现）。 */
void ring_buffer_node_deinit(RingBufferNodeContext *rbn);

/**
 * @brief 清空读写指针
 *
 * @param rbn 上下文指针
 */
void ring_buffer_node_clear(RingBufferNodeContext *rbn);

/**
 * @brief 获取已填充节点数
 *
 * @param rbn 上下文指针
 * @return 已填充节点数
 */
uint32_t ring_buffer_node_get_fill_nodes(RingBufferNodeContext *rbn);

/**
 * @brief 获取空闲节点数（保留 1 个节点区分满/空）
 *
 * @param rbn 上下文指针
 * @return 可写节点数
 */
uint32_t ring_buffer_node_get_free_nodes(RingBufferNodeContext *rbn);

/**
 * @brief 取出一个读节点并推进读指针
 *
 * @param rbn 上下文指针
 * @return 节点数据指针
 */
uint8_t *ring_buffer_node_get_read_node(RingBufferNodeContext *rbn);

/**
 * @brief 获取一个写节点并推进写指针
 *
 * @param rbn 上下文指针
 * @return 节点数据指针
 */
uint8_t *ring_buffer_node_get_write_node(RingBufferNodeContext *rbn);

/**
 * @brief 窥视读节点但不推进读指针
 *
 * @param rbn 上下文指针
 * @return 节点数据指针
 */
uint8_t *ring_buffer_node_peek_read_node(RingBufferNodeContext *rbn);

/**
 * @brief 推进读指针（丢弃当前窥视节点）
 *
 * @param rbn 上下文指针
 */
void ring_buffer_node_take_read_node(RingBufferNodeContext *rbn);

/**
 * @brief 写入数据到当前写节点（前 2 字节存长度）
 *
 * @param rbn  上下文指针
 * @param data 待写入数据
 * @param len  数据长度
 * @return 0 成功
 */
int32_t ring_buffer_node_write(RingBufferNodeContext *rbn, uint8_t *data, uint16_t len);

#ifdef  __cplusplus
}
#endif//__cplusplus

#endif//__RING_BUFFER_NODE_H__
