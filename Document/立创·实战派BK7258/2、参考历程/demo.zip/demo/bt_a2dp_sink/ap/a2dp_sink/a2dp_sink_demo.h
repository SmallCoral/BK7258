/**
 * @file a2dp_sink_demo.h
 * @brief A2DP Sink 演示模块对外接口
 */

#ifndef A2DP_SINK_DEMO_H
#define A2DP_SINK_DEMO_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/**
 * @brief 初始化 A2DP Sink 演示（注册回调并创建音频任务）
 *
 * @param aac_supported 1 支持 AAC，0 仅 SBC
 * @return 0 成功，负数失败
 */
int a2dp_sink_demo_init(uint8_t aac_supported);

/**
 * @brief 通过 AVRCP 获取远端媒体属性
 *
 * @param attr 属性 ID（如标题、艺术家）
 * @return 0 成功，负数失败
 */
int32_t bk_bt_app_avrcp_ct_get_attr(uint32_t attr);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*A2DP_SINK_DEMO_H*/
