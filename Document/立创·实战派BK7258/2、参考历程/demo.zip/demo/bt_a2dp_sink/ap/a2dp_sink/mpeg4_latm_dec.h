/**
 * @file mpeg4_latm_dec.h
 * @brief MPEG-4 LATM 封装 AAC 帧解析接口与调试宏
 */

#pragma once

#include "components/log.h"
#include "os/mem.h"

/** @brief LATM 解码日志级别枚举 */
enum
{
    MPEG4_LATM_DEBUG_LEVEL_ERROR,
    MPEG4_LATM_DEBUG_LEVEL_WARNING,
    MPEG4_LATM_DEBUG_LEVEL_INFO,
    MPEG4_LATM_DEBUG_LEVEL_DEBUG,
    MPEG4_LATM_DEBUG_LEVEL_VERBOSE,
};


/** @brief 当前 LATM 解码日志级别 */
#define MPEG4_LATM_DEBUG_LEVEL MPEG4_LATM_DEBUG_LEVEL_INFO

#define mpeg_loge(format, ...) do{if(MPEG4_LATM_DEBUG_LEVEL >= MPEG4_LATM_DEBUG_LEVEL_ERROR)   BK_LOGE("mpeg4", "%s:" format "\n", __func__, ##__VA_ARGS__);}while(0)
#define mpeg_logw(format, ...) do{if(MPEG4_LATM_DEBUG_LEVEL >= MPEG4_LATM_DEBUG_LEVEL_WARNING) BK_LOGW("mpeg4", "%s:" format "\n", __func__, ##__VA_ARGS__);}while(0)
#define mpeg_logi(format, ...) do{if(MPEG4_LATM_DEBUG_LEVEL >= MPEG4_LATM_DEBUG_LEVEL_INFO)    BK_LOGI("mpeg4", "%s:" format "\n", __func__, ##__VA_ARGS__);}while(0)
#define mpeg_logd(format, ...) do{if(MPEG4_LATM_DEBUG_LEVEL >= MPEG4_LATM_DEBUG_LEVEL_DEBUG)   BK_LOGD("mpeg4", "%s:" format "\n", __func__, ##__VA_ARGS__);}while(0)
#define mpeg_logv(format, ...) do{if(MPEG4_LATM_DEBUG_LEVEL >= MPEG4_LATM_DEBUG_LEVEL_VERBOSE) BK_LOGV("mpeg4", "%s:" format "\n", __func__, ##__VA_ARGS__);}while(0)

/**
 * @brief 从 LATM 载荷中解析出裸 AAC 帧
 *
 * @param input      输入 LATM 数据
 * @param input_len  输入长度（字节）
 * @param output     输出：指向 input 内 AAC 帧起始地址
 * @param output_len 输出：AAC 帧长度（字节）
 * @return 0 成功，负数失败
 */
int mpeg4_latm_decode(uint8_t *input, uint32_t input_len, uint8_t **output, uint32_t *output_len);
