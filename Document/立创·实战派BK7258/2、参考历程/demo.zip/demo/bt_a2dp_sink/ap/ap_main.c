/**
 * @file ap_main.c
 * @brief Classic BT A2DP Sink 演示工程入口
 *
 * 手机系统蓝牙可发现、配对并播放音频；支持 A2DP Sink 与 HFP HF（可选）及 `headset` CLI。
 */

#include "bk_private/bk_init.h"
#include <os/os.h>
#include <components/log.h>
#include "bsp_gpio.h"
#include "bsp_audio.h"
#include "bt_manager.h"
#include "media_service.h"

#define TAG "bt_a2dp"

#define AUTO_ENABLE_BLUETOOTH_DEMO 1

/**
 * @brief 上电延迟后打印蓝牙配对与 CLI 使用提示
 *
 * @param arg 未使用
 */
static void bt_a2dp_boot_task(void *arg)
{
	(void)arg;
	rtos_delay_milliseconds(2000);

	BK_LOGI(TAG, "READY: bt_a2dp_sink\r\n");
	BK_LOGI(TAG, "Phone Settings -> Bluetooth: search and pair device name BK7258_SPK_xxxxxx\r\n");
	BK_LOGI(TAG, "CLI: ap_cmd headset pair_mode | ap_cmd headset vol_up\r\n");
	rtos_delete_thread(NULL);
}

/**
 * @brief AP 应用入口：初始化电源、音频、蓝牙与 CLI
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}
	if (bsp_gpio_init_power_master() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board power init\r\n");
		return -1;
	}
	if (bsp_gpio_init_audio() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board audio gpio init\r\n");
		return -1;
	}
	bsp_audio_pa_power_on();

	media_service_init();

#if AUTO_ENABLE_BLUETOOTH_DEMO
	bt_manager_init();

#if CONFIG_A2DP_SINK_DEMO
	extern int a2dp_sink_demo_init(uint8_t aac_supported);
	a2dp_sink_demo_init(0);
#endif

#if CONFIG_HFP_HF_DEMO
	extern int hfp_hf_demo_init(uint8_t msbc_supported);
	hfp_hf_demo_init(0);
#endif

#if CONFIG_BT
	extern int cli_headset_demo_init(void);
	cli_headset_demo_init();
#endif
#endif

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "bt_a2dp_boot", bt_a2dp_boot_task, 2048, NULL) != BK_OK) {
		BK_LOGE(TAG, "FAIL: boot task create\r\n");
		return -1;
	}
	return 0;
}
