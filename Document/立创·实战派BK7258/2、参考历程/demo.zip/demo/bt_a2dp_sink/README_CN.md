# Classic BT A2DP Sink 例程

基于 SDK `projects/bluetooth/headset` 移植，在立创 BK7258 扩展板上实现经典蓝牙 A2DP 音箱。

## 示例目标

让手机通过系统蓝牙搜索、配对 `BK7258_SPK_XXYYZZ`，并把 SBC 音频流送到板载 DAC 和喇叭。

## 学习内容

- BR/EDR GAP 可发现、配对和重连流程。
- A2DP Sink 的 SBC 解码与 DAC 播放链路。
- AP/CP 双核蓝牙配置和 `ap_cmd` CLI 转发。

## 硬件要求和引脚

- BK7258QN88616 模组及立创扩展板。
- USB-C 连接 CP UART0，串口参数为 115200 8N1。
- 板载 MS8002 功放：GPIO8 控制播放电源，GPIO23 保持低电平。

## 软件配置

- AP/CP 均启用 `CONFIG_BT=y`。
- AP 启用 `CONFIG_A2DP_SINK_DEMO=y`，默认不启用 HFP。
- `ram_regions.csv` 使用完整 16 MiB PSRAM 布局。

## 编译命令

```bash
cd projects/bt_a2dp_sink
make bk7258
```

## 固件位置

`build/bk7258/bt_a2dp_sink/package/all-app.bin`

## 烧录和运行步骤

1. 整包烧录 `all-app.bin` 并打开 CP UART0。
2. 等待启动日志出现 `READY`。
3. 手机打开“设置 → 蓝牙”，搜索并配对 `BK7258_SPK_XXYYZZ`。
4. 在手机音乐 App 中选择该设备作为音频输出并播放。

## 预期日志或现象

```text
READY: bt_a2dp_sink
Phone Settings -> Bluetooth: search and pair device name BK7258_SPK_xxxxxx
```

配对后手机显示蓝牙音频设备，播放音频时板载喇叭输出声音。

## CLI/AT 操作方法

CP UART0 发往 AP 的命令需要 `ap_cmd` 前缀：

```text
ap_cmd headset pair_mode
ap_cmd headset vol_up
ap_cmd headset vol_down
ap_cmd headset play
ap_cmd headset pause
```

## 常见问题

- 手机搜不到设备：确认 AP/CP 均启用 BT，并完整重编、整包烧录。
- 能配对但无声：检查 GPIO8 的 PLAY_3V3、GPIO23 低电平和喇叭连接。
- 编译缺组件：确认 `SDK_DIR` 指向完整的 `bk_avdk_smp_sdk`。
- Wi-Fi 与 BT 共存异常：先关闭 Wi-Fi 缩小范围，再对照 SDK headset 的 coex 配置。

## 代码入口

- `ap/ap_main.c`：板级上电与 BT/A2DP 初始化。
- `ap/bt_manager.c`：GAP 配对和重连管理。
- `ap/a2dp_sink/a2dp_sink_demo.c`：A2DP 音频接收与播放。
- `ap/config/bk7258_ap/config`、`cp/config/bk7258/config`：双核蓝牙配置。

## 可扩展方向

- 增加 AVRCP 元数据、播放控制和音量同步。
- 启用 HFP HF，补充通话音频和麦克风链路。
- 增加配对信息持久化及异常断线重连测试。

## 相关示例

- `ble_at_test`：BLE only 的 AT 通路，不作为手机系统蓝牙音箱。
- [`../../docs/examples/connectivity/Bluetooth.md`](../../docs/examples/connectivity/Bluetooth.md)：经典蓝牙与 A2DP 的进一步说明。
- `music_player`：本地文件和音频服务播放。
- SDK 原始例程：`bk_avdk_smp_sdk/projects/bluetooth/headset`。
