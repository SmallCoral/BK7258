# LCD 背光 PWM 调光示例

本例程使用 BK7258 的 PWM5 外设驱动扩展板 LCD 背光，实现亮度调节和呼吸灯效果。

## 硬件连接

扩展板已经完成连接，不需要额外接线：

- `GPIO25`：LCD 背光控制，对应 `PWM5`
- `GPIO13`：LCD 电源使能
- 背光控制为低有效：GPIO25 拉低时背光点亮，拉高时熄灭

本例程上电后先初始化 ST7789V2 并刷一屏白色，再由 PWM5 驱动背光，便于肉眼观察亮度变化。

## 默认行为

设备启动后：

1. 打开 LCD 电源，刷一屏白色；
2. 将 GPIO25 映射为 PWM5；
3. 输出 20kHz PWM，避免肉眼可见闪烁；
4. 从 50% 亮度开始自动执行 0～100% 呼吸效果。

## 编译

在工程目录运行：

```bash
make bk7258
```

固件位置：

```text
build/bk7258/lcd_backlight_pwm/package/all-app.bin
```

## 串口命令

USB-C 串口连接 CP CLI，AP 命令需要使用 `ap_cmd`：

```text
# 查看帮助
ap_cmd backlight help

# 设置亮度
ap_cmd backlight set 0
ap_cmd backlight set 25
ap_cmd backlight set 50
ap_cmd backlight set 75
ap_cmd backlight set 100

# 每次增减 10%
ap_cmd backlight up
ap_cmd backlight down

# 最亮和熄灭
ap_cmd backlight on
ap_cmd backlight off

# 启停呼吸效果
ap_cmd backlight breath start
ap_cmd backlight breath stop

# 查询当前状态
ap_cmd backlight status
```

## 预期日志

```text
LCD filled RGB565=0xFFFF (240x320)
PWM5 ready: GPIO25, 20000Hz, active-low, default breath
READY: GPIO25 PWM5 LCD backlight demo
```

状态命令返回示例：

```text
brightness=50% breathing=no pwm=20000Hz channel=5
```

## 验收方法

1. 启动后背光应平滑地由暗变亮、再由亮变暗。
2. 设置 `0%` 后背光完全熄灭。
3. 设置 `100%` 后背光达到最高亮度。
4. 设置 `25%`、`50%`、`75%` 时亮度应逐级增加。
5. 用示波器测量 GPIO25，应看到约 20kHz PWM 波形。

注意：LCD 背光采用低有效 PMOS，高电平占空比与视觉亮度方向相反；代码已经完成极性换算，用户命令仍按 `0%=熄灭、100%=最亮` 使用。
