set(incs .)
set(srcs ap_main.c backlight_pwm.c lcd_panel_fill.c)

set(priv_req bsp_gpio bsp_lcd_st7789 media_service multimedia bk_display bk_peripheral)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
