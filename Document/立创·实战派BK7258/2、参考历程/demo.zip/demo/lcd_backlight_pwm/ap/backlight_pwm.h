/**
 * @file backlight_pwm.h
 * @brief LCD 背光 PWM 调光例程对外接口
 *
 * 使用 PWM5 驱动 GPIO25（LCD_BL，低有效）实现 0～100% 亮度调节。
 */

#pragma once

#include <common/bk_err.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化背光 PWM 并注册 CLI
 *
 * @return 操作结果
 * @retval BK_OK 成功
 * @retval 其他  PWM/CLI 初始化失败
 */
bk_err_t backlight_pwm_init(void);

/**
 * @brief 设置背光亮度百分比
 *
 * @param percent 亮度 0～100
 * @return 操作结果
 * @retval BK_OK 成功
 * @retval BK_ERR_PARAM percent > 100
 */
bk_err_t backlight_pwm_set_brightness(uint8_t percent);

/**
 * @brief 获取当前亮度百分比
 *
 * @return 当前亮度 0～100
 */
uint8_t backlight_pwm_get_brightness(void);

#ifdef __cplusplus
}
#endif
