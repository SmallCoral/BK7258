/**
 * @file lcd_panel_fill.c
 * @brief ST7789 单次纯色刷屏，供背光 PWM 演示观察亮度
 */

#include "lcd_panel_fill.h"

#include <components/avdk_utils/avdk_error.h>
#include <components/bk_display.h>
#include <components/log.h>
#include "bsp_gpio.h"
#include "bsp_lcd_st7789.h"
#include "frame_buffer.h"

#define TAG "bl_fill"

static bk_err_t disp_frame_free_cb(void *args)
{
    (void)args;
    return BK_OK;
}

static void fill_pure_color(frame_buffer_t *fb, uint16_t color)
{
    uint8_t hi = (uint8_t)(color >> 8);
    uint8_t lo = (uint8_t)(color & 0xFF);

    for (uint32_t i = 0; i < fb->size; i += 2) {
        fb->frame[i] = hi;
        fb->frame[i + 1] = lo;
    }
}

bk_err_t lcd_panel_fill_solid(uint16_t color)
{
    bk_display_ctlr_handle_t lcd = NULL;
    bk_display_spi_ctlr_config_t spi_cfg = {
        .lcd_device = NULL,
        .spi_id     = 1,
        .dc_pin     = BOARD_LCD_DC_PIN,
        .reset_pin  = BOARD_LCD_RST_PIN,
        .te_pin     = 0,
    };
    const bsp_lcd_st7789_cfg_t lcd_cfg = {
        .landscape = false,
        .mirror_x  = false,
        .mirror_y  = false,
        .clk       = LCD_QSPI_64M,
    };
    frame_buffer_t *fb = NULL;
    avdk_err_t ret;

    spi_cfg.lcd_device = bsp_lcd_st7789_get(&lcd_cfg);
    if (!spi_cfg.lcd_device) {
        BK_LOGE(TAG, "FAIL: ST7789 profile\r\n");
        return BK_FAIL;
    }

    /* 刷屏期间先用 GPIO 管背光；随后由 backlight_pwm_init() 接管 PWM5 */
    board_gpio_set_high(BOARD_LCD_BL_PIN);
    ret = bk_display_spi_new(&lcd, &spi_cfg);
    if (ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "FAIL: bk_display_spi_new (%d)\r\n", ret);
        goto fail;
    }

    board_gpio_set_high(BOARD_LCD_PWR_PIN);
    ret = bk_display_open(lcd);
    if (ret != AVDK_ERR_OK) {
        BK_LOGE(TAG, "FAIL: bk_display_open (%d)\r\n", ret);
        goto fail;
    }

    {
        uint32_t w = spi_cfg.lcd_device->width;
        uint32_t h = spi_cfg.lcd_device->height;

        fb = frame_buffer_display_malloc(w * h * 2);
        if (!fb) {
            BK_LOGE(TAG, "FAIL: frame buffer malloc\r\n");
            ret = AVDK_ERR_NOMEM;
            goto fail_opened;
        }
        fb->fmt = PIXEL_FMT_RGB565;
        fb->width = w;
        fb->height = h;
        fill_pure_color(fb, color);
        ret = bk_display_flush(lcd, fb, disp_frame_free_cb);
        frame_buffer_display_free(fb);
        fb = NULL;
        if (ret != AVDK_ERR_OK) {
            BK_LOGE(TAG, "FAIL: bk_display_flush (%d)\r\n", ret);
            goto fail_opened;
        }
        BK_LOGI(TAG, "LCD filled RGB565=0x%04X (%ux%u)\r\n", color, w, h);
    }

    /* GRAM 已写入；关闭控制器但保持供电，背光交给 PWM */
    (void)bk_display_close(lcd);
    (void)bk_display_delete(lcd);
    return BK_OK;

fail_opened:
    (void)bk_display_close(lcd);
fail:
    if (lcd) {
        (void)bk_display_delete(lcd);
    }
    return (ret == AVDK_ERR_OK) ? BK_FAIL : (bk_err_t)ret;
}
