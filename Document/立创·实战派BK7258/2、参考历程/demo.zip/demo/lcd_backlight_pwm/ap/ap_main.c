/**
 * @file ap_main.c
 * @brief LCD 背光 PWM 调光演示工程入口
 *
 * 先刷一屏白色再初始化 PWM5 背光，默认呼吸灯效果，可用 CLI 调节亮度。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>

#include "backlight_pwm.h"
#include "bsp_gpio.h"
#include "lcd_panel_fill.h"

#define TAG "bl_pwm"

/* 白色：亮度变化最容易用肉眼观察 */
#define DEMO_FILL_COLOR 0xFFFF

/**
 * @brief AP 应用入口：刷白屏后启动背光 PWM 例程
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }
    if (bsp_gpio_init_power_master() != BK_OK ||
        bsp_gpio_init_lcd() != BK_OK) {
        BK_LOGE(TAG, "FAIL: LCD GPIO init\r\n");
        return -1;
    }
    if (media_service_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: media service init\r\n");
        return -1;
    }

    /* 先写 GRAM 白屏，再让 PWM 接管 GPIO25；失败仍继续 PWM 演示 */
    if (lcd_panel_fill_solid(DEMO_FILL_COLOR) != BK_OK) {
        BK_LOGW(TAG, "WARN: LCD fill failed, backlight PWM continues\r\n");
    }

    if (backlight_pwm_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: backlight PWM init\r\n");
        return -1;
    }

    BK_LOGI(TAG, "READY: GPIO25 PWM5 LCD backlight demo\r\n");
    BK_LOGI(TAG, "CLI: ap_cmd backlight help\r\n");
    return 0;
}
