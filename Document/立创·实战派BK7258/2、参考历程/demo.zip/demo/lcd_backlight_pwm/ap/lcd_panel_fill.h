/**
 * @file lcd_panel_fill.h
 * @brief 初始化 ST7789 并刷一屏纯色，便于观察背光亮度变化
 */

#pragma once

#include <common/bk_err.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 打开 ST7789，向 GRAM 刷满指定 RGB565 颜色后关闭控制器（保持供电）
 *
 * @param color RGB565 颜色，观察背光建议用白色 0xFFFF
 * @return 操作结果
 * @retval BK_OK 成功
 * @retval 其他  显示初始化或刷新失败
 */
bk_err_t lcd_panel_fill_solid(uint16_t color);

#ifdef __cplusplus
}
#endif
