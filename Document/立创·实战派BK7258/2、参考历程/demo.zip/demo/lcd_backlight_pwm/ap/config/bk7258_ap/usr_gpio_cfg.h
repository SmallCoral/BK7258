// 采用扩展板统一引脚映射；PWM 驱动会将 GPIO25 从普通背光脚切换到 PWM5。
#include "usr_gpio_cfg_default.h"
