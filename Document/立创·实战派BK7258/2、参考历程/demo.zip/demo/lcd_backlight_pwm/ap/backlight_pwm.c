/**
 * @file backlight_pwm.c
 * @brief LCD 背光 PWM 调光例程实现
 *
 * 使用 PWM5 驱动 GPIO25（LCD_BL，低有效）实现亮度调节、呼吸灯与 CLI 控制。
 */

#include "backlight_pwm.h"

#include <cli.h>
#include <components/log.h>
#include <driver/pwm.h>
#include <os/os.h>
#include <os/str.h>

#define TAG "bl_pwm"

#define BACKLIGHT_PWM_CHANNEL PWM_ID_5
#define BACKLIGHT_PWM_HZ 20000
#define BACKLIGHT_PWM_CLOCK_HZ 26000000
#define BACKLIGHT_PWM_PERIOD (BACKLIGHT_PWM_CLOCK_HZ / BACKLIGHT_PWM_HZ)
#define BACKLIGHT_DEFAULT_PERCENT 50
#define BACKLIGHT_BREATH_STEP 2
#define BACKLIGHT_BREATH_INTERVAL_MS 40

static beken_mutex_t s_lock;
static beken_thread_t s_breath_thread;
static uint8_t s_brightness;
static bool s_breathing;
static bool s_initialized;

/**
 * @brief 在持锁状态下设置 PWM 占空比（调用方须已持有 s_lock）
 *
 * @param percent 亮度 0～100
 * @return 操作结果
 * @retval BK_OK 设置成功
 */
static bk_err_t backlight_pwm_apply_locked(uint8_t percent)
{
    pwm_period_duty_config_t config = {0};
    config.period_cycle = BACKLIGHT_PWM_PERIOD;

    /*
     * LCD_BL 经 PMOS 低有效：GPIO 低=点亮，高=熄灭。
     * 在 bk_pwm_set_init_signal_low() 下：
     *   duty=0       → 常低 → 全亮
     *   duty=period  → 常高 → 熄灭
     * 因此亮度 percent 需反向映射到 duty，使 CLI 仍为 0%=熄灭、100%=最亮。
     */
    config.duty_cycle =
        (BACKLIGHT_PWM_PERIOD * (uint32_t)(100 - percent)) / 100;

    bk_err_t result =
        bk_pwm_set_period_duty(BACKLIGHT_PWM_CHANNEL, &config);
    if (result == BK_OK) {
        s_brightness = percent;
    }
    return result;
}

bk_err_t backlight_pwm_set_brightness(uint8_t percent)
{
    if (!s_initialized || percent > 100) {
        return BK_ERR_PARAM;
    }

    rtos_lock_mutex(&s_lock);
    bk_err_t result = backlight_pwm_apply_locked(percent);
    rtos_unlock_mutex(&s_lock);
    return result;
}

uint8_t backlight_pwm_get_brightness(void)
{
    rtos_lock_mutex(&s_lock);
    uint8_t brightness = s_brightness;
    rtos_unlock_mutex(&s_lock);
    return brightness;
}

/**
 * @brief 背光呼吸灯线程，在 s_breathing 为真时周期性改变亮度
 *
 * @param arg 未使用
 */
static void backlight_breath_task(beken_thread_arg_t arg)
{
    (void)arg;
    int value = BACKLIGHT_DEFAULT_PERCENT;
    int direction = 1;

    while (1) {
        rtos_lock_mutex(&s_lock);
        bool breathing = s_breathing;
        if (breathing) {
            value += direction * BACKLIGHT_BREATH_STEP;
            if (value >= 100) {
                value = 100;
                direction = -1;
            } else if (value <= 0) {
                value = 0;
                direction = 1;
            }
            backlight_pwm_apply_locked((uint8_t)value);
        } else {
            value = s_brightness;
        }
        rtos_unlock_mutex(&s_lock);

        rtos_delay_milliseconds(
            breathing ? BACKLIGHT_BREATH_INTERVAL_MS : 100);
    }
}

/**
 * @brief `backlight` CLI 命令处理
 *
 * @param buffer     响应写入缓冲区
 * @param buffer_len 缓冲区长度
 * @param argc       参数个数
 * @param argv       参数列表
 */
static void backlight_cli(char *buffer, int buffer_len,
                          int argc, char **argv)
{
    if (argc < 2 || os_strcmp(argv[1], "help") == 0) {
        os_snprintf(buffer, buffer_len,
                    "backlight set <0-100> | up | down | on | off | "
                    "breath start|stop | status\r\n");
        return;
    }

    bk_err_t result = BK_OK;
    if (os_strcmp(argv[1], "set") == 0 && argc >= 3) {
        uint32_t percent = os_strtoul(argv[2], NULL, 10);
        if (percent > 100) {
            result = BK_ERR_PARAM;
        } else {
            s_breathing = false;
            result = backlight_pwm_set_brightness((uint8_t)percent);
        }
    } else if (os_strcmp(argv[1], "up") == 0) {
        uint8_t value = backlight_pwm_get_brightness();
        value = value > 90 ? 100 : value + 10;
        s_breathing = false;
        result = backlight_pwm_set_brightness(value);
    } else if (os_strcmp(argv[1], "down") == 0) {
        uint8_t value = backlight_pwm_get_brightness();
        value = value < 10 ? 0 : value - 10;
        s_breathing = false;
        result = backlight_pwm_set_brightness(value);
    } else if (os_strcmp(argv[1], "on") == 0) {
        s_breathing = false;
        result = backlight_pwm_set_brightness(100);
    } else if (os_strcmp(argv[1], "off") == 0) {
        s_breathing = false;
        result = backlight_pwm_set_brightness(0);
    } else if (os_strcmp(argv[1], "breath") == 0 && argc >= 3) {
        if (os_strcmp(argv[2], "start") == 0) {
            s_breathing = true;
        } else if (os_strcmp(argv[2], "stop") == 0) {
            s_breathing = false;
        } else {
            result = BK_ERR_PARAM;
        }
    } else if (os_strcmp(argv[1], "status") != 0) {
        result = BK_ERR_PARAM;
    }

    if (result == BK_OK) {
        os_snprintf(buffer, buffer_len,
                    "brightness=%u%% breathing=%s pwm=%uHz channel=%u\r\n",
                    backlight_pwm_get_brightness(),
                    s_breathing ? "yes" : "no",
                    BACKLIGHT_PWM_HZ,
                    (unsigned)BACKLIGHT_PWM_CHANNEL);
    } else {
        os_snprintf(buffer, buffer_len, "ERROR: invalid command or value\r\n");
    }
}

static const struct cli_command s_commands[] = {
    {
        "backlight",
        "set <0-100>|up|down|on|off|breath start|stop|status",
        backlight_cli,
    },
};

bk_err_t backlight_pwm_init(void)
{
    if (s_initialized) {
        return BK_OK;
    }

    bool mutex_ready = false;
    bool pwm_inited = false;
    bool pwm_started = false;
    bool cli_registered = false;

    bk_err_t result = rtos_init_mutex(&s_lock);
    if (result != BK_OK) {
        return result;
    }
    mutex_ready = true;

    result = bk_pwm_driver_init();
    if (result != BK_OK) {
        goto fail;
    }

    pwm_init_config_t config = {0};
    config.period_cycle = BACKLIGHT_PWM_PERIOD;
    config.duty_cycle =
        (BACKLIGHT_PWM_PERIOD * (100 - BACKLIGHT_DEFAULT_PERCENT)) / 100;

    result = bk_pwm_init(BACKLIGHT_PWM_CHANNEL, &config);
    if (result != BK_OK) {
        goto fail;
    }
    pwm_inited = true;

    result = bk_pwm_set_init_signal_low(BACKLIGHT_PWM_CHANNEL);
    if (result != BK_OK) {
        goto fail;
    }

    result = bk_pwm_start(BACKLIGHT_PWM_CHANNEL);
    if (result != BK_OK) {
        goto fail;
    }
    pwm_started = true;

    result = cli_register_commands(
        s_commands, sizeof(s_commands) / sizeof(s_commands[0]));
    if (result != BK_OK) {
        goto fail;
    }
    cli_registered = true;

    result = rtos_create_thread(
        &s_breath_thread,
        BEKEN_DEFAULT_WORKER_PRIORITY,
        "bl_breath",
        backlight_breath_task,
        2048,
        NULL);
    if (result != BK_OK) {
        s_breath_thread = NULL;
        goto fail;
    }

    /* 全部成功后再置位，避免 status 报告半初始化状态 */
    s_brightness = BACKLIGHT_DEFAULT_PERCENT;
    s_breathing = true;
    s_initialized = true;

    BK_LOGI(TAG, "PWM5 ready: GPIO25, %uHz, active-low, default breath\r\n",
            BACKLIGHT_PWM_HZ);
    return BK_OK;

fail:
    if (cli_registered) {
        (void)cli_unregister_commands(
            s_commands, sizeof(s_commands) / sizeof(s_commands[0]));
    }
    if (pwm_started) {
        (void)bk_pwm_stop(BACKLIGHT_PWM_CHANNEL);
    }
    if (pwm_inited) {
        (void)bk_pwm_deinit(BACKLIGHT_PWM_CHANNEL);
    }
    if (mutex_ready) {
        (void)rtos_deinit_mutex(&s_lock);
    }
    s_brightness = 0;
    s_breathing = false;
    s_initialized = false;
    return result;
}
