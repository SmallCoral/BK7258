// CP 侧静态管脚映射：默认采用本板统一配置（components/board_cfg/cp）。
// 如需自定义，删除下面这行转发，直接写完整 GPIO_DEFAULT_DEV_CONFIG 即可覆盖。
#include "usr_gpio_cfg_default.h"
