/**
 * @file ap_main.c
 * @brief BLE AT 验证工程 AP 入口
 *
 * 经 USB-C CP UART0 发送 BLE AT 命令进行广播、扫描等联调验证。
 */

#include "bk_private/bk_init.h"
#include <os/os.h>
#include <components/log.h>
#include "bsp_gpio.h"

#define TAG "ble_at"

static void ble_at_boot_task(void *arg)
{
	(void)arg;
	rtos_delay_milliseconds(1500);

	BK_LOGI(TAG, "READY: ble_at_test\r\n");
	BK_LOGI(TAG, "USB-C (CP UART0) send AT commands, e.g. AT+BLELOCALADDR?\r\n");
	BK_LOGI(TAG, "adv: AT+BLEADVPARAM / AT+BLEADVDATA / AT+BLEADVENABLE=1\r\n");
	BK_LOGI(TAG, "scan: AT+BLESCANPARAM / AT+BLESCANENABLE=1\r\n");
	rtos_delete_thread(NULL);
}

/**
 * @brief AP 入口：初始化系统与板级电源，并打印 BLE AT 使用说明
 *
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
	if (bk_init() != BK_OK) {
		BK_LOGE(TAG, "FAIL: system init\r\n");
		return -1;
	}
	if (bsp_gpio_init_power_master() != BK_OK) {
		BK_LOGE(TAG, "FAIL: board power init\r\n");
		return -1;
	}

	if (rtos_create_thread(NULL, BEKEN_DEFAULT_WORKER_PRIORITY,
	                       "ble_at_boot", ble_at_boot_task, 2048, NULL) != BK_OK) {
		BK_LOGE(TAG, "FAIL: boot task create\r\n");
		return -1;
	}
	return 0;
}
