# ble_at_test：BK7258 BLE 串口 AT 验证示例

本工程用于验证 BK7258 BLE Host/Controller、广播、扫描和连接命令。BLE 命令与扫描输出受 AP/CP 路由和当前 SDK 行为影响，必须以本次构建后的上板结果为准。

## 1. 示例目标

- 通过 USB Type-C 串口检查 BLE AT 命令是否注册并可到达 AP。
- 验证本机地址查询、广播启停、扫描启停和可选连接流程。
- 明确区分“命令执行成功”和“扫描结果已主动上报”。
- 用对照测试确认当前多核配置下的实际命令路径。

## 2. 学习内容

- BK7258 BLE Host 与 Controller 的 AP/CP 分工。
- CP 串口 CLI 的 `ap_cmd` 转发机制。
- BLE 广播参数、广播数据、扫描参数和连接参数。
- AT 同步响应、BLE 异步事件以及日志级别之间的区别。

当前工程配置对应的目标架构：

```text
PC -> USB Type-C/CP UART0 -> CP CLI
                              |
                              +-- ap_cmd AT+BLE... -> AP BLE Host/AT
                                                       |
                                                       +-> CP BLE Controller
```

AP 配置为 BLE Host-only，CP 配置为 BLE Controller-only，因此 BLE Host AT 的首选验证路径是 `ap_cmd AT+BLE...`。直接发送 `AT+BLE...` 只作为多核路由对照项，不应预先认定可用。

## 3. 硬件要求和引脚

- 立创 BK7258 模组与扩展板。
- 支持数据传输的 USB Type-C 线。
- 另一台 BLE 设备，例如手机、耳机或第二块广播中的开发板。
- 手机 BLE 扫描工具可用于观察板端广播。
- BK7258 烧录工具和 115200 串口终端。

相关引脚：

- CP UART0 RX/TX：GPIO10/GPIO11，经板载 USB 转串口连接电脑。
- BLE 使用片内射频，没有专用外设 GPIO。
- AP 仅通过 `bsp_gpio_init_power_master()` 初始化板级总电源。

## 4. 软件配置

关键 AP 配置：

- `CONFIG_BLE_AT_ENABLE=y`
- `CONFIG_BLUETOOTH_AP=y`
- `CONFIG_BLUETOOTH_HOST_ONLY=y`
- `CONFIG_BLUETOOTH_AUTO_ENABLE=y`
- `CONFIG_BLUETOOTH_SUPPORT_IPC=y`
- `CONFIG_DEFAULT_AT_PORT=1`
- `CONFIG_UART_PRINT_PORT=1`
- `CONFIG_CPU_CNT=2`

关键 CP 配置：

- `CONFIG_BLUETOOTH=y`
- `CONFIG_BLE_AT_ENABLE=y`
- `CONFIG_BTDM_CONTROLLER_ONLY=y`
- `CONFIG_BLUETOOTH_SUPPORT_IPC=y`
- `CONFIG_DEFAULT_AT_PORT=0`
- `CONFIG_UART_PRINT_PORT=0`
- `CONFIG_UART_PRINT_BAUD_RATE=115200`
- `CONFIG_CPU_CNT=3`

AP 与 CP 的 `CONFIG_CPU_CNT` 当前分别为 2 和 3，而且 CP 也开启了 `CONFIG_BLE_AT_ENABLE`；同时 `ap/ap_main.c` 的提示日志示例没有写 `ap_cmd`。这些事实不能代替运行验证。烧录后必须按第 9 节对 `ap_cmd` 和直接命令做对照，记录哪条路径真正返回 BLE 数据。

Flash 分区为 bootloader 68 KiB、CP app 1360 KiB、AP app 1156 KiB、OTA 1428 KiB、用户配置 60 KiB。BLE Host/Controller 必须来自同一次完整构建。

## 5. 编译命令

默认 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级：

```bash
cd lichuang_bk7258/projects/ble_at_test
make bk7258
```

Docker wrapper：

```bash
./dbuild.sh bk7258
```

SDK 不在默认位置时：

```bash
make bk7258 SDK_DIR=/path/to/bk_avdk_smp_sdk
SDK_DIR=/path/to/bk_avdk_smp_sdk ./dbuild.sh bk7258
```

不要为本例直接编译、复制或修改 SDK 内部的 `bk_at_ble.c`；本工程 README 只描述现有接口和需要验证的行为。

## 6. 固件位置

完整镜像：

```text
build/bk7258/ble_at_test/package/all-app.bin
```

OTA 包为同目录的 `app_pack.rbl`。首次烧录使用 `all-app.bin`。最近一次仓库内构建摘要显示 CP Flash 使用约 75.81%，AP Flash 使用约 48.90%；以本次构建的 `package/build_summary.txt` 为准。

## 7. 烧录和运行步骤

1. 编译并确认 `all-app.bin` 生成。
2. 用 BKFIL 或 SDK 支持的 BK7258 下载工具烧录完整镜像。
3. 退出下载模式并复位，等待 AP/CP 均启动；BLE 初始化可能晚于基础串口。
4. 打开 USB Type-C 对应串口：115200、8N1、无流控、CRLF。
5. 先发送 `AT` 确认 CP 串口，再执行第 9 节的路由对照。
6. 广播测试用手机观察；扫描测试确保周围存在已知 BLE 广播源。

## 8. 预期日志或现象

AP 启动任务会打印：

```text
READY: ble_at_test
USB-C (CP UART0) send AT commands, e.g. AT+BLELOCALADDR?
adv: AT+BLEADVPARAM / AT+BLEADVDATA / AT+BLEADVENABLE=1
scan: AT+BLESCANPARAM / AT+BLESCANENABLE=1
```

这几行只是 `ap_main.c` 的提示字符串，不证明直接命令路径或问号语法已经上板通过。有效验收应同时观察：

- 命令是否返回 `CMDRSP:OK` 或明确错误。
- 地址查询是否真的输出 `ATRSP:BLE_ADDR:<mac>`。
- 手机是否能发现广播名。
- 扫描启动后是否存在当前固件可见的扫描日志。

当前仓库不能保证出现 `+BLESCAN:` 主动上报。当前外部 SDK 的扫描回调把广告信息写到 `LOGD`，未见本仓库工程侧注册 `+BLESCAN:` 输出；`AT+BLESCANENABLE=1` 返回 `OK` 只代表扫描启动命令成功。

## 9. CLI/AT 操作方法

先做路径与语法矩阵，不要只测一种写法：

```text
AT
ap_cmd AT+BLELOCALADDR
ap_cmd AT+BLELOCALADDR?
AT+BLELOCALADDR
AT+BLELOCALADDR?
```

当前 SDK 命令表注册名是 `AT+BLELOCALADDR`，get handler 要求零参数并输出 `ATRSP:BLE_ADDR:`；但 AT parser 对裸命令和 `?` 查询形式的分派需上板确认。将“返回 `CMDRSP:OK` 且包含有效地址”的写法作为后续命令路径。

若确认 `ap_cmd` 路径有效，广播可按当前命令表尝试：

```text
ap_cmd AT+BLEADVPARAM=7,120,160,0,0,3,1,1
ap_cmd AT+BLEADVDATA=0201060909373235385f424c45,D
ap_cmd AT+BLEADVENABLE=1
```

手机应能发现名为 `7258_BLE` 的广播。关闭广播：

```text
ap_cmd AT+BLEADVENABLE=0
```

扫描：

```text
ap_cmd AT+BLESCANPARAM=0,1,64,1e
ap_cmd AT+BLESCANENABLE=1
```

等待一段时间后停止：

```text
ap_cmd AT+BLESCANENABLE=0
```

若路径矩阵证明直接 `AT+BLE...` 才是当前固件有效入口，则仅去掉上述 `ap_cmd ` 前缀并重复同组命令，不能同时混用两条路径。

连接命令参数与地址类型依赖目标广告，且必须用真实扫描/手机工具获得的地址：

```text
ap_cmd AT+BLECREATECONNECT=17,0,1f4,1,0,aa:bb:cc:dd:ee:ff
ap_cmd AT+BLEDISCONNECT=0
```

连接属于进阶验证；参数不匹配时可能失败，不应把该示例地址当作固定设备。

## 10. 常见问题

- `command in cpu-1 is null`：命令没有到达预期 AP 命令表；执行第 9 节路由矩阵，不要凭旧文档猜路径。
- `cmd NOT found`：确认烧录的是本工程，AP 已启动，且 `CONFIG_BLE_AT_ENABLE` 生效。
- `AT+BLELOCALADDR?` 失败：再试零参数形式 `AT+BLELOCALADDR`；两种形式均需记录实际输出。
- 扫描返回 `OK` 但没有 `+BLESCAN:`：这是当前仓库可预期的情况，不能据此声称扫描未工作；用手机/第二块板和可用调试日志交叉验证。
- 手机扫不到板端广播：确认广播三条命令使用同一路径、参数均成功、已关闭旧活动，并靠近板端。
- 广播和扫描互相影响：先执行 `AT+BLEADVENABLE=0` 再启扫描。
- 命令过早：复位后等待 AP BLE Host 初始化完成再测试。

## 11. 代码入口

- `ap/ap_main.c`：初始化系统和总电源，打印 BLE AT 提示；本文件没有自定义扫描上报实现。
- `ap/CMakeLists.txt`：注册 AP 入口，依赖 `bk_cli` 和 `bsp_gpio`。
- `cp/CMakeLists.txt`：直接注册工程自己的 `cp_main.c`。
- `ap/config/bk7258_ap/config`：BLE Host-only、BLE AT、IPC 和 AP UART 配置。
- `cp/config/bk7258/config`：BLE Controller-only、BLE AT、IPC 和 CP UART0 配置。
- `partitions/bk7258/auto_partitions.csv`：双核固件和 OTA 布局。

## 12. 可扩展方向

- 在工程自身组件中增加稳定、可测试的扫描事件接口，而不是指导用户改外部 SDK。
- 增加广播数据解析、设备去重和 RSSI 过滤。
- 增加 GATT 服务发现、读写、通知和连接参数测试。
- 统一 AP/CP 的 CPU 数量和 BLE AT 注册策略后，再固化唯一命令路径。
- 增加上板回归脚本，分别断言命令响应、广播可见性和连接事件。

## 13. 相关示例

- `projects/wifi_at_test`：CP 本地 AT，不加 `ap_cmd`，可用于理解两种路由差异。
- [`codepulse_desk`](../../../projects/codepulse_desk/)：工程自管 BLE NUS 服务，不依赖本例的扫描输出。
- [`../../docs/examples/connectivity/ble-at.md`](../../docs/examples/connectivity/ble-at.md)：BLE 基础与串口 AT 的进一步说明。
- `projects/digital_camera`：AP CLI 从 CP 串口经 `ap_cmd` 转发的明确示例。

## 14. 验收清单

- `AT` 能确认 CP 串口正常。
- 路由矩阵明确记录有效的 AP/CP 命令路径。
- 本机地址命令至少一种写法返回有效 `ATRSP:BLE_ADDR:`。
- 广播启停命令成功，手机能发现并确认消失。
- 扫描启停命令成功；扫描结果是否可见按当前日志能力单独记录，不把 `+BLESCAN:` 当作仓库保证。
- AP/CP `CONFIG_CPU_CNT` 差异及其上板行为已完成对比验证。
