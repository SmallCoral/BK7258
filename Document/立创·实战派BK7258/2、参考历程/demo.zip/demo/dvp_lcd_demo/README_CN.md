# dvp_lcd_demo：GC0308 DVP 摄像头实时显示

## 示例目标

在立创 BK7258 扩展板上采集 GC0308 兼容 DVP 摄像头的 640×480 YUV422 帧，按宽高各二分之一缩放并转换为 RGB565，在横屏 320×240 ST7789V2 SPI 屏上实时预览完整画面。

## 学习内容

- DVP8 数据、同步时钟和 SCCB 配置链路。
- 摄像头供电、PWDN、RESET 与传感器探测。
- SDK GC0308 的 VYUY 输出、YUV422 到 RGB565 转换和 2:1 缩放。
- 公共帧队列、物理竖屏软件旋转整帧刷新及首帧后开启背光。
- 用 CLI 启停预览并检查运行状态。

## 硬件要求和引脚

需要 BK7258 主板、立创扩展板、GC0308 兼容 DVP 摄像头模组、240×320 ST7789V2 SPI 屏和支持数据传输的 USB Type-C 线。

| 摄像头信号 | 引脚 | 说明 |
| --- | --- | --- |
| XCLK | GPIO27 | `JPEG_MCLK`，传感器 profile 使用 24 MHz |
| PCLK/HREF/VSYNC | GPIO29/GPIO30/GPIO31 | DVP 像素、行、场同步 |
| D0～D7 | GPIO32～GPIO39 | DVP8 数据 |
| SCCB SCL/SDA | GPIO42/GPIO43 | 共享模拟 I2C，7 位地址 `0x21` |
| PWDN | GPIO40 | 高为掉电、低为工作，由摄像头驱动控制 |
| RESET | GPIO41 | 低有效 |
| DVP PWR | GPIO9 | 摄像头 2.8 V 电源使能，高有效 |

| LCD 信号 | 引脚 | 说明 |
| --- | --- | --- |
| CLK/CS/MOSI | GPIO2/GPIO3/GPIO4 | SPI1 |
| D/C、RESET | GPIO5、GPIO12 | 普通输出 |
| PWR、BL | GPIO13、GPIO25 | 电源高有效；背光低有效 |

GPIO22 控制外部 3.3 V 总电源；GPIO10/11 是 CH340K 对应的 CP UART0 日志和下载口。引脚与有效电平以 [`board_design/pinmap.md`](../../board_design/pinmap.md)、`components/bsp_gpio` 和 `components/board_cfg` 为准。

## 软件配置

- `CONFIG_DVP_CAMERA=y`、`CONFIG_DVP_CAMERA_I2C_ID=2`、`CONFIG_DVP_CTRL_POWER_GPIO_ID=9`。
- `CONFIG_SIM_I2C=y`，摄像头 SCCB 使用 GPIO42/43 上的共享模拟 I2C。
- `CONFIG_DVP_GC0308=y`，其它 DVP 传感器关闭；探测和初始化使用 SDK `dvp_gc0308.c`。
- `CONFIG_BSP_CAMERA_GC0308_MIRROR_HORIZONTAL=y`，垂直镜像关闭，匹配当前模组方向。
- `CONFIG_BSP_CAMERA_YUV_FRAME_COUNT=3`。
- `CONFIG_LCD_SPI_ST7789V2=y`、`CONFIG_LCD_SPI_REFRESH_WITH_QSPI_MAPPING_MODE=y`。
- LCD 保持物理竖屏 240×320、`LCD_QSPI_64M`，逻辑 320×240 画面软件旋转到独立 PSRAM 发送缓冲后一次整帧发送；板级初始化含 `INVON(0x21)`。
- 工程使用 `partitions/bk7258/auto_partitions.csv` 的标准分区布局。
- `ram_regions.csv` 使用板载 16 MiB PSRAM 布局并关闭 write-through。

### 统一的 SDK GC0308 YUV profile

三个相机工程统一使用：

```text
SDK GC0308 reg 0x24 = 0xa2
DVP 帧格式 = IMAGE_YUV / PIXEL_FMT_YUYV
DMA 字节顺序 = VYUY [Cr Y0 Cb Y1]
采集尺寸 = 640x480
转换 = 读取 V、Y、U，并调用 yuv_to_rgb565(y, u, v)
显示尺寸 = 320x240 RGB565
```

转换对行、列各做 2:1 最近邻采样。镜像仅通过 `bsp_camera_gc0308_set_mirror()` 读改写寄存器 `0x14` 的方向位，不修改 `0x24`，也不叠加软件 RGB 取反。

## 编译命令

默认 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。在本工程目录执行：

```bash
make bk7258
```

Docker 编译：

```bash
./dbuild.sh bk7258
```

SDK 位于其他位置时，再通过 `SDK_DIR` 显式覆盖。

## 固件位置

整机固件为：

```text
build/bk7258/dvp_lcd_demo/package/all-app.bin
```

确认文件来自本次成功构建；不要选择 AP、CP、OTA 分区或其他中间镜像。

## 烧录和运行步骤

1. 断电安装摄像头和 LCD FPC，确认方向与锁扣。
2. 用 USB Type-C 连接开发板，使用 BKFIL 选择 CH340K 串口和上述固件。
3. 下载波特率设为 `1500000`，应用复位波特率设为 `115200`，完成烧录。
4. 释放串口，以 `115200 8N1`、无流控打开日志终端。
5. 短按复位键；程序会自动启动摄像头和实时预览。
6. 将彩色物体放在镜头前，检查方向、比例、运动和颜色。

通用流程见[固件烧录参考](../../docs/reference/firmware-download.md)和[串口控制台参考](../../docs/reference/serial-console.md)。

## 预期日志或现象

正常启动的关键日志包括：

```text
READY: camera preview service started
LCD power on
DVP power on
GC0308 640x480 opened
preview started
first frame ready, backlight on
```

首帧准备好之前背光保持关闭。正常现象是横屏显示完整 4:3 画面，物体移动连续可见，红绿蓝颜色关系自然，无持续横纹、碎块或明显绿紫/蓝偏。

## CLI/AT 操作方法

在 CH340K 终端使用 `115200 8N1`、CRLF。AP 命令必须带 `ap_cmd`：

| 命令 | 作用 |
| --- | --- |
| `ap_cmd camera_lcd status` | 打印预览线程和摄像头状态 |
| `ap_cmd camera_lcd close` | 停止预览并释放摄像头、LCD 和缓冲区 |
| `ap_cmd camera_lcd open` | 重新创建预览线程 |

关闭后等待 `preview stopped` 再重新打开。本工程不提供 AT 命令。

## 常见问题

- **摄像头打开失败**：检查 GPIO9 供电、GPIO40 PWDN、GPIO41 RESET、GPIO42/43 SCCB 和模组 FPC；优先找日志中的第一条失败。
- **只有背光无画面**：检查是否出现 `GC0308 640x480 opened`、`preview started` 和首帧日志；确认帧队列分配没有失败。
- **画面清晰但肤色发蓝**：确认只启用 SDK GC0308，保持 `REG24=0xa2`，并按 VYUY 调用 `yuv_to_rgb565(y, u, v)`。
- **绿紫偏色**：检查是否误按 YUYV/UYVY 重排 DMA 字节。
- **横纹、碎块或花屏**：确认物理竖屏配置、软件旋转缓冲和单次整帧发送均生效，并保留发送完成等待。
- **画面呈补色**：保留屏 profile 的 `INVON(0x21)`，不要再对 RGB565 做软件取反。
- **日志乱码或 CLI 无响应**：检查串口参数、CRLF、`ap_cmd` 和端口占用，详见[通用排障](../../docs/reference/troubleshooting.md)。

## 代码入口

- `ap/ap_main.c`：初始化总电源、LCD、摄像头 GPIO、媒体服务和预览。
- `ap/board_camera_lcd.c`：DVP 打开、VYUY 转换、2:1 缩放、软件旋转整帧刷新和 CLI。
- SDK `ap/components/bk_peripheral/src/dvp/dvp_gc0308.c`：唯一的 GC0308 探测和初始化驱动。
- `components/bsp_camera/bsp_camera_gc0308.c`：基于 camera ioctl 的镜像 profile。
- `components/bsp_camera/dvp_frame_list.c`：三个工程共用的 YUV 帧队列。
- `components/bsp_lcd_st7789`：横竖屏、镜像、时钟和 `INVON` profile。
- `ap/config/bk7258_ap/config`：本工程的 DVP、YUV、模拟 I2C 和 LCD 配置。

## 可扩展方向

- 增加实时帧率、丢帧、队列深度和 SPI 刷新耗时统计。
- 增加曝光、白平衡、镜像等传感器寄存器调节，但保持格式 profile 与解码一致。
- 增加画面叠加、裁剪或不同缩放算法，并评估内存与 CPU 占用。

## 相关示例

- `digital_camera`：更完整的相机应用，使用同一 SDK GC0308/VYUY profile。
- `st7789_test`：单独验证 ST7789 显示链路。
- `lcd_tp_test`：验证同一 LCD 与触摸输入。
- `hello_board`：基础构建、烧录和日志基线。

## 人工上板验收

本工程必须人工上板验收，不能以编译成功、传感器探测成功或静态截图代替：

1. 复位后确认自动出现实时画面，日志达到 `first frame ready, backlight on`。
2. 用红、绿、蓝物体和肤色目标检查颜色；移动目标检查连续性和完整 4:3 构图。
3. 检查方向和比例，无明显拉伸、补色、绿紫、横纹、碎块或快速运动斜向撕裂。
4. 执行 `status`、`close`、`open`，确认预览可停止并恢复。

记录板卡、摄像头模组、FPC 方向、固件时间和完整启动日志后，才可判定通过。
