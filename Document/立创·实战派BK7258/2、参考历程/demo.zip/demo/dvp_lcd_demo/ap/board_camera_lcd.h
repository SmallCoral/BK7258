/**
 * @file board_camera_lcd.h
 * @brief GC0308 DVP 摄像头 + ST7789 SPI LCD 实时预览对外接口
 */

#pragma once

#include <common/bk_err.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 启动摄像头预览线程（YUV → RGB565 缩放并刷新 LCD）
 *
 * @return 操作结果
 * @retval BK_OK 已运行或线程创建成功
 * @retval 其他  线程创建失败
 */
bk_err_t board_camera_lcd_init(void);

/**
 * @brief 注册 `camera_lcd` CLI 命令
 *
 * @return cli_register_commands 返回值，0 表示成功
 */
int board_camera_lcd_cli_init(void);

#ifdef __cplusplus
}
#endif
