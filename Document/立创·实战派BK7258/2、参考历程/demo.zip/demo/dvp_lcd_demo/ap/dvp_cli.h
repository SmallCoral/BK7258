/**
 * @file dvp_cli.h
 * @brief DVP 摄像头 CLI 测试公共宏与接口
 *
 * 提供 CLI 响应字符串、DVP 电源 GPIO 配置及命令解析辅助函数。
 */

#ifndef __DVP_CLI_H_
#define __DVP_CLI_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @brief CLI 命令成功响应前缀 */
#define CLI_CMD_RSP_SUCCEED               "CMDRSP:OK\r\n"
/** @brief CLI 命令失败响应前缀 */
#define CLI_CMD_RSP_ERROR                 "CMDRSP:ERROR\r\n"
/** @brief 判断 argv 中是否包含指定子串 */
#define CMD_CONTAIN(value) cmd_contain(argc, argv, value)

/** @brief 无效 GPIO 编号占位 */
#define GPIO_INVALID_ID           (0xFF)
#ifdef CONFIG_DVP_CTRL_POWER_GPIO_ID
#define DVP_POWER_GPIO_ID CONFIG_DVP_CTRL_POWER_GPIO_ID
#else
#define DVP_POWER_GPIO_ID GPIO_INVALID_ID
#endif

/**
 * @brief 判断 CLI 参数列表中是否包含指定字符串
 *
 * @param argc   参数个数
 * @param argv   参数列表
 * @param string 待匹配子串
 * @return true 包含；false 不包含
 */
bool cmd_contain(int argc, char **argv, char *string);

/**
 * @brief 注册 DVP 测试 CLI 命令
 *
 * @return cli_register_commands 返回值，0 表示成功
 */
int cli_dvp_test_init(void);

/**
 * @brief DVP API 测试 CLI 命令处理
 *
 * @param pcWriteBuffer  响应写入缓冲区
 * @param xWriteBufferLen 缓冲区长度
 * @param argc           参数个数
 * @param argv           参数列表
 */
void cli_dvp_api_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv);

/**
 * @brief DVP 功能测试 CLI 命令处理
 *
 * @param pcWriteBuffer  响应写入缓冲区
 * @param xWriteBufferLen 缓冲区长度
 * @param argc           参数个数
 * @param argv           参数列表
 */
void cli_dvp_func_test_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv);

#ifdef __cplusplus
}
#endif

#endif
