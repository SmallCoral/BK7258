/**
 * @file board_camera_lcd.c
 * @brief GC0308 DVP 摄像头 + ST7789 SPI LCD 实时预览实现
 *
 * 640×480 YUV 经 2:1 缩放转 RGB565，软件旋转后刷新 ST7789 竖屏；对齐 JiaLiChuang7258demo/dvp_example。
 */

#include "board_camera_lcd.h"

#include <os/os.h>
#include <os/str.h>
#include <os/mem.h>
#include <components/log.h>
#include <components/media_types.h>
#include <components/avdk_utils/avdk_error.h>
#include <components/bk_camera_ctlr.h>
#include <components/dvp_camera_types.h>
#include <driver/gpio.h>
#include <driver/lcd_spi.h>
#include <driver/psram.h>
#include <driver/pwr_clk.h>
#include "gpio_driver.h"
#include "board_i2c.h"
#include "bsp_camera_gc0308.h"
#include "bsp_gpio.h"
#include "bsp_lcd_st7789.h"
#include "cli.h"
#include "frame_buffer.h"
#include "dvp_frame_list.h"

#define TAG "cam_lcd"

#define GPIO_INVALID_ID    (0xFF)

#define LCD_LDO_PIN        BOARD_LCD_PWR_PIN
#define LCD_BL_PIN         BOARD_LCD_BL_PIN
#define LCD_SPI_ID         1
#define LCD_DC_PIN         BOARD_LCD_DC_PIN
#define LCD_RST_PIN        BOARD_LCD_RST_PIN
#define LCD_WIDTH          320
#define LCD_HEIGHT         240
#define CAM_WIDTH          640
#define CAM_HEIGHT         480

#ifdef CONFIG_DVP_CTRL_POWER_GPIO_ID
#define DVP_POWER_GPIO_ID  CONFIG_DVP_CTRL_POWER_GPIO_ID
#else
#define DVP_POWER_GPIO_ID  GPIO_INVALID_ID
#endif

static bk_camera_ctlr_handle_t s_dvp_handle = NULL;
static volatile int s_dvp_running = 0;
static bool s_camera_suspended = false;
static beken_thread_t s_disp_thread = NULL;

static void lcd_backlight_init_off(uint8_t bl_io)
{
    gpio_dev_unmap(bl_io);
    bk_gpio_enable_output(bl_io);
    bk_gpio_pull_up(bl_io);
    bk_gpio_set_output_high(bl_io);
}

static void lcd_backlight_open(uint8_t bl_io)
{
    bk_gpio_set_output_low(bl_io);
}

static void lcd_backlight_close(uint8_t bl_io)
{
    bk_gpio_set_output_high(bl_io);
}

static inline uint16_t yuv_to_rgb565(uint8_t y, uint8_t u, uint8_t v)
{
    int r, g, b;
    int c = y - 16;
    int d = u - 128;
    int e = v - 128;

    r = (298 * c + 409 * e + 128) >> 8;
    g = (298 * c - 100 * d - 208 * e + 128) >> 8;
    b = (298 * c + 516 * d + 128) >> 8;

    if (r < 0) r = 0; else if (r > 255) r = 255;
    if (g < 0) g = 0; else if (g > 255) g = 255;
    if (b < 0) b = 0; else if (b > 255) b = 255;

    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

/* SDK GC0308 reg0x24=0xa2，DMA 内存为 VYUY=[Cr Y0 Cb Y1]。
 * 宽高按 2:1 最近邻缩小，完整保留 640x480 画面。 */
static void yuyv_to_rgb565_scale_half(uint8_t *yuyv, uint8_t *rgb,
                                      uint16_t src_w, uint16_t src_h)
{
    uint16_t dst_w = src_w / 2;
    uint16_t dst_h = src_h / 2;

    for (uint16_t row = 0; row < dst_h; row++) {
        uint8_t *src_row = yuyv + (row * 2) * src_w * 2;
        uint8_t *dst_row = rgb + row * dst_w * 2;

        for (uint16_t col = 0; col < dst_w; col++) {
            uint16_t src_col = col * 2;
            const uint8_t *pixel = &src_row[src_col * 2];
            uint8_t v = pixel[0];
            uint8_t y = pixel[1];
            uint8_t u = pixel[2];
            uint16_t color = yuv_to_rgb565(y, u, v);

            dst_row[col * 2] = color >> 8;
            dst_row[col * 2 + 1] = color & 0xFF;
        }
    }
}

/* 逻辑横屏 320x240 软件旋转为 ST7789 物理竖屏 240x320 扫描顺序。 */
static bk_err_t lcd_display_frame(uint8_t *rgb, uint8_t *lcd_frame)
{
    for (int x = 0; x < LCD_WIDTH; x++) {
        for (int y = 0; y < LCD_HEIGHT; y++) {
            const uint8_t *src =
                &rgb[(y * LCD_WIDTH + x) * 2];
            uint8_t *dst =
                &lcd_frame[((LCD_WIDTH - 1 - x) * LCD_HEIGHT + y) * 2];
            dst[0] = src[0];
            dst[1] = src[1];
        }
    }

    bk_err_t ret = bk_lcd_spi_frame_display(
        LCD_SPI_ID, lcd_frame, LCD_WIDTH * LCD_HEIGHT * 2);
    if (ret == BK_OK) {
        ret = bk_lcd_spi_wait_display_complete(LCD_SPI_ID);
    }
    return ret;
}

static frame_buffer_t *dvp_lcd_frame_malloc(image_format_t format, uint32_t size)
{
    frame_buffer_t *frame = dvp_frame_queue_malloc(format, size);

    if (frame) {
        frame->sequence  = 0;
        frame->length    = 0;
        frame->timestamp = 0;
        frame->size      = size;
    }
    return frame;
}

static void dvp_lcd_frame_complete(image_format_t format, frame_buffer_t *frame, int result)
{
    if (result != AVDK_ERR_OK) {
        dvp_frame_queue_free(format, frame);
    } else {
        dvp_frame_queue_complete(format, frame);
    }
}

static const bk_dvp_callback_t s_dvp_cbs = {
    .malloc   = dvp_lcd_frame_malloc,
    .complete = dvp_lcd_frame_complete,
};

static avdk_err_t camera_open(void)
{
    avdk_err_t ret = AVDK_ERR_GENERIC;
    int retry;

    if (s_dvp_handle && s_camera_suspended) {
        ret = bk_camera_resume(s_dvp_handle);
        if (ret == AVDK_ERR_OK) {
            s_camera_suspended = false;
            BK_LOGI(TAG, "GC0308 camera resumed\r\n");
        }
        return ret;
    }

    ret = dvp_frame_queue_init_all();
    if (ret != BK_OK) {
        BK_LOGE(TAG, "frame queue init failed: %d\r\n", ret);
        return ret;
    }

    bk_dvp_ctlr_config_t dvp_config = {
        .config = BK_DVP_864X480_30FPS_MJPEG_CONFIG(),
        .cbs    = &s_dvp_cbs,
    };
    dvp_config.config.img_format          = IMAGE_YUV;
    dvp_config.config.width             = CAM_WIDTH;
    dvp_config.config.height            = CAM_HEIGHT;
    dvp_config.config.i2c_config.scl_pin = BSP_BOARD_I2C_SCL_PIN;
    dvp_config.config.i2c_config.sda_pin = BSP_BOARD_I2C_SDA_PIN;
    dvp_config.config.reset_pin          = BOARD_DVP_RST_PIN;
    dvp_config.config.pwdn_pin           = BOARD_DVP_PWDN_PIN;

    for (retry = 0; retry < 3; retry++) {
        if (retry > 0) {
            BK_LOGI(TAG, "camera retry %d\r\n", retry);
            bk_gpio_set_output_low(BOARD_DVP_RST_PIN);
            rtos_delay_milliseconds(50);
            bk_gpio_set_output_high(BOARD_DVP_RST_PIN);
            rtos_delay_milliseconds(200);
        }

        ret = bk_camera_dvp_ctlr_new(&s_dvp_handle, &dvp_config);
        if (ret != AVDK_ERR_OK) {
            BK_LOGE(TAG, "bk_camera_dvp_ctlr_new failed: %d\r\n", ret);
            continue;
        }

        ret = bk_camera_open(s_dvp_handle);
        if (ret == AVDK_ERR_OK) {
            ret = bsp_camera_gc0308_apply_profile(s_dvp_handle);
            if (ret == BK_OK) {
                BK_LOGI(TAG, "GC0308 %ux%u opened\r\n",
                        CAM_WIDTH, CAM_HEIGHT);
                return AVDK_ERR_OK;
            }
            BK_LOGE(TAG, "GC0308 profile failed: %d\r\n", ret);
            bk_camera_close(s_dvp_handle);
        }

        BK_LOGE(TAG, "bk_camera_open failed: %d\r\n", ret);
        bk_camera_delete(s_dvp_handle);
        s_dvp_handle = NULL;
    }

    dvp_frame_queue_deinit_all();
    return ret;
}

static void camera_power_on(void)
{
    /* Hold the sensor inactive while its rail and shared I/O power settle. */
    gpio_dev_unmap(BOARD_DVP_PWDN_PIN);
    bk_gpio_enable_output(BOARD_DVP_PWDN_PIN);
    bk_gpio_set_output_high(BOARD_DVP_PWDN_PIN);

    gpio_dev_unmap(BOARD_DVP_RST_PIN);
    bk_gpio_enable_output(BOARD_DVP_RST_PIN);
    bk_gpio_set_output_low(BOARD_DVP_RST_PIN);

    if (DVP_POWER_GPIO_ID != GPIO_INVALID_ID) {
        gpio_dev_unmap(DVP_POWER_GPIO_ID);
        bk_gpio_enable_output(DVP_POWER_GPIO_ID);
        bk_gpio_set_output_high(DVP_POWER_GPIO_ID);
    }

    gpio_dev_unmap(BOARD_EXPORT_IO_PWR_PIN);
    bk_gpio_enable_output(BOARD_EXPORT_IO_PWR_PIN);
    bk_gpio_set_output_high(BOARD_EXPORT_IO_PWR_PIN);
    rtos_delay_milliseconds(50);

    bk_gpio_set_output_low(BOARD_DVP_PWDN_PIN);
    rtos_delay_milliseconds(10);
    bk_gpio_set_output_high(BOARD_DVP_RST_PIN);
    rtos_delay_milliseconds(200);
}

static void camera_power_off(void)
{
    /*
     * Keep the board camera/shared-I/O rails enabled across close/open.
     * Cycling either rail leaves this board's SCCB bus unable to recover
     * without a full reset. PWDN high plus RESET low stops the sensor cleanly
     * while preserving a restartable electrical state.
     */
    gpio_dev_unmap(BOARD_DVP_PWDN_PIN);
    bk_gpio_enable_output(BOARD_DVP_PWDN_PIN);
    bk_gpio_set_output_high(BOARD_DVP_PWDN_PIN);

    gpio_dev_unmap(BOARD_DVP_RST_PIN);
    bk_gpio_enable_output(BOARD_DVP_RST_PIN);
    bk_gpio_set_output_low(BOARD_DVP_RST_PIN);
    rtos_delay_milliseconds(10);
}

static void dvp_lcd_display_task(void *arg)
{
    (void)arg;
    uint8_t *rgb_buf = NULL;
    uint8_t *lcd_frame = NULL;
    bool lcd_initialized = false;
    bool camera_opened = false;
    bk_err_t display_ret = BK_OK;

    rtos_delay_milliseconds(500);

    bk_pm_module_vote_psram_ctrl(PM_POWER_PSRAM_MODULE_NAME_VIDP_LCD,
                                  PM_POWER_MODULE_STATE_ON);
    bk_pm_module_vote_cpu_freq(PM_DEV_ID_DISP, PM_CPU_FRQ_480M);
    BK_LOGI(TAG, "LCD power on\r\n");
    bk_pm_module_vote_ctrl_external_ldo(GPIO_CTRL_LDO_MODULE_LCD, LCD_LDO_PIN, GPIO_OUTPUT_STATE_HIGH);
    rtos_delay_milliseconds(200);

    /* 背光低电平有效：初始化及首帧写入期间保持关闭，避免显示未初始化显存。 */
    lcd_backlight_init_off(LCD_BL_PIN);

    /* 保持 ST7789 物理竖屏扫描；横屏方向由软件旋转发送缓冲完成。 */
    bsp_lcd_st7789_cfg_t lcd_cfg = {
        .landscape = false,
        .mirror_x  = false,
        .mirror_y  = false,
        .clk       = LCD_QSPI_64M,
    };
    bk_lcd_spi_init(LCD_SPI_ID, bsp_lcd_st7789_get(&lcd_cfg), LCD_RST_PIN, LCD_DC_PIN);
    lcd_initialized = true;

    uint32_t disp_size = LCD_WIDTH * LCD_HEIGHT * 2;
    rgb_buf = (uint8_t *)psram_malloc(disp_size);
    if (!rgb_buf) {
        BK_LOGE(TAG, "rgb_buf malloc failed\r\n");
        goto cleanup;
    }
    lcd_frame = (uint8_t *)psram_malloc(disp_size);
    if (!lcd_frame) {
        BK_LOGE(TAG, "LCD rotate buffer malloc failed\r\n");
        goto cleanup;
    }

    /*
     * 先在 DVP 驱动申请 DMA 资源前完成一次黑帧传输。SDK 的 LCD QSPI
     * DMA 在 deinit/init 后需要先建立完成中断，顺序与 digital_camera 一致。
     */
    os_memset(rgb_buf, 0, disp_size);
    display_ret = lcd_display_frame(rgb_buf, lcd_frame);
    if (display_ret != BK_OK) {
        BK_LOGE(TAG, "LCD warm-up frame failed: %d\r\n", display_ret);
        goto cleanup;
    }

    if (!s_dvp_handle) {
        BK_LOGI(TAG, "DVP power on\r\n");
        camera_power_on();
    }

    if (camera_open() != AVDK_ERR_OK) {
        BK_LOGE(TAG, "camera open failed\r\n");
        goto cleanup;
    }
    camera_opened = true;

    BK_LOGI(TAG, "preview started\r\n");

    bool first_frame = true;
    while (s_dvp_running) {
        frame_buffer_t *frame = dvp_frame_queue_get_frame(IMAGE_YUV, 500);
        if (!frame) {
            continue;
        }

        yuyv_to_rgb565_scale_half((uint8_t *)frame->frame, rgb_buf,
                                  CAM_WIDTH, CAM_HEIGHT);
        dvp_frame_queue_free(IMAGE_YUV, frame);

        display_ret = lcd_display_frame(rgb_buf, lcd_frame);
        if (display_ret != BK_OK) {
            BK_LOGE(TAG, "LCD frame display failed: %d\r\n", display_ret);
            break;
        }

        if (first_frame) {
            lcd_backlight_open(LCD_BL_PIN);
            first_frame = false;
            BK_LOGI(TAG, "first frame ready, backlight on\r\n");
        }
    }

cleanup:
    s_dvp_running = 0;
    bool camera_retained = false;
    if (s_dvp_handle && camera_opened) {
        if (bk_camera_suspend(s_dvp_handle) == BK_OK) {
            frame_buffer_t *frame = NULL;
            while ((frame =
                        dvp_frame_queue_get_frame(IMAGE_YUV, 0)) != NULL) {
                dvp_frame_queue_free(IMAGE_YUV, frame);
            }
            s_camera_suspended = true;
            camera_retained = true;
            BK_LOGI(TAG, "camera suspended\r\n");
        }
    }
    if (!camera_retained) {
        if (s_dvp_handle) {
            bk_camera_close(s_dvp_handle);
            bk_camera_delete(s_dvp_handle);
            s_dvp_handle = NULL;
        }
        s_camera_suspended = false;
        dvp_frame_queue_deinit_all();
        camera_power_off();
    }
    lcd_backlight_close(LCD_BL_PIN);
    if (rgb_buf) {
        psram_free(rgb_buf);
    }
    if (lcd_frame) {
        psram_free(lcd_frame);
    }
    if (lcd_initialized) {
        bk_lcd_spi_deinit(LCD_SPI_ID, LCD_RST_PIN, LCD_DC_PIN);
    }
    bk_pm_module_vote_cpu_freq(PM_DEV_ID_DISP, PM_CPU_FRQ_DEFAULT);
    bk_pm_module_vote_psram_ctrl(PM_POWER_PSRAM_MODULE_NAME_VIDP_LCD,
                                 PM_POWER_MODULE_STATE_OFF);
    bk_pm_module_vote_ctrl_external_ldo(
        GPIO_CTRL_LDO_MODULE_LCD, LCD_LDO_PIN, GPIO_OUTPUT_STATE_LOW);
    BK_LOGI(TAG, "preview stopped\r\n");
    s_disp_thread = NULL;
    rtos_delete_thread(NULL);
}

static void preview_stop(void)
{
    beken_thread_t thread = s_disp_thread;
    s_dvp_running = 0;
    if (thread) {
        rtos_thread_join(&thread);
    }
}

static bk_err_t preview_start(void)
{
    if (s_disp_thread) {
        return BK_OK;
    }

    s_dvp_running = 1;
    bk_err_t ret = rtos_create_thread(&s_disp_thread, 4, "dvp_lcd",
                                      (beken_thread_function_t)dvp_lcd_display_task,
                                      8192, NULL);
    if (ret != BK_OK) {
        s_dvp_running = 0;
        s_disp_thread = NULL;
    }
    return ret;
}

/**
 * @brief 启动摄像头预览线程（YUV → RGB565 缩放并刷新 LCD）
 *
 * @return 操作结果
 * @retval BK_OK 已运行或线程创建成功
 * @retval 其他  线程创建失败
 */
bk_err_t board_camera_lcd_init(void)
{
    return preview_start();
}

static void cli_camera_lcd_cmd(char *pcWriteBuffer, int xWriteBufferLen, int argc, char **argv)
{
    const char *msg = CLI_CMD_RSP_ERROR;

    if (argc < 2) {
        goto exit;
    }

    if (os_strcmp(argv[1], "open") == 0) {
        if (preview_start() == BK_OK) {
            msg = CLI_CMD_RSP_SUCCEED;
        }
    } else if (os_strcmp(argv[1], "close") == 0) {
        preview_stop();
        msg = CLI_CMD_RSP_SUCCEED;
    } else if (os_strcmp(argv[1], "status") == 0) {
        BK_LOGI(TAG, "running=%s cam=%s\r\n",
                s_dvp_running ? "yes" : "no",
                s_camera_suspended ? "suspended" :
                (s_dvp_handle ? "open" : "closed"));
        msg = CLI_CMD_RSP_SUCCEED;
    }

exit:
    os_memcpy(pcWriteBuffer, msg, os_strlen(msg));
}

static const struct cli_command s_cmds[] = {
    {"camera_lcd", "open/close/status", cli_camera_lcd_cmd},
};

/**
 * @brief 注册 `camera_lcd` CLI 命令
 *
 * @return cli_register_commands 返回值，0 表示成功
 */
int board_camera_lcd_cli_init(void)
{
    int ret =
        cli_register_commands(s_cmds, sizeof(s_cmds) / sizeof(s_cmds[0]));
    if (ret == BK_OK) {
        /*
         * SDK CLI uses binary search. Commands registered after bk_cli_init()
         * must be sorted again before CP's `ap_cmd` forwarding can find them.
         */
        extern void cli_sort_command(char *, int, int, char **);
        cli_sort_command(NULL, 0, 0, NULL);
    }
    return ret;
}
