/**
 * @file ap_main.c
 * @brief GC0308 摄像头 + ST7789 LCD 实时预览工程 AP 入口
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>
#include "bsp_gpio.h"
#include "board_camera_lcd.h"

#define TAG "dvp_lcd_demo"

/**
 * @brief AP 入口：初始化系统、板级 GPIO 与摄像头预览服务
 *
 * @return 0 成功；-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }
    if (bsp_gpio_init_power_master() != BK_OK ||
        bsp_gpio_init_lcd() != BK_OK ||
        bsp_gpio_init_camera() != BK_OK) {
        BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
        return -1;
    }
    if (media_service_init() != BK_OK ||
        board_camera_lcd_cli_init() != BK_OK ||
        board_camera_lcd_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: preview service init\r\n");
        return -1;
    }
    BK_LOGI(TAG, "READY: camera preview service started\r\n");
    return 0;
}
