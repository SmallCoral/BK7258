set(incs .)
set(srcs ap_main.c board_camera_lcd.c)

# 传感器使用 SDK GC0308；公共帧队列和方向 profile 由 bsp_camera 提供。
set(priv_req media_service multimedia bk_camera bk_dvp bk_peripheral bk_display bsp_lcd_st7789 bsp_gpio bsp_camera)

armino_component_register(SRCS "${srcs}" INCLUDE_DIRS "${incs}" PRIV_REQUIRES "${priv_req}")
