/**
 * @file ap_main.c
 * @brief 板级 Hello 演示工程入口
 *
 * 最小启动例程：仅初始化系统与板级 3V3 电源，串口打印就绪信息。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include "bsp_gpio.h"

#define TAG "hello_board"

/**
 * @brief AP 应用入口：系统与板级电源初始化
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }

    // 纯串口 hello：仅上总 3V3（维持板级电源时序），不用任何外设组
    if (bsp_gpio_init_power_master() != BK_OK) {
        BK_LOGE(TAG, "FAIL: board power init\r\n");
        return -1;
    }

    BK_LOGI(TAG, "READY: hello board\r\n");
    return 0;
}
