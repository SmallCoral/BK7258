# hello_board：BK7258 板级最小启动示例

本 README 依据工程当前的 C、CMake、config、分区文件及板级组件编写。文中的日志是源码定义的验收标志；本次文档整理不等同于上板实测，最终结果需人工烧录并检查串口。

## 示例目标

验证 BK7258 双核工程的最小闭环：完成系统初始化、按板级时序打开外部 3.3 V 总电源，并由 AP 输出 `hello board`。它适合先排除工具链、打包、烧录和串口链路问题，再测试其他外设。

## 学习内容

- 认识 AP 应用入口 `main()` 与 `bk_init()`。
- 理解 `bsp_gpio_init_power_master()` 必须先于其他板级外设初始化。
- 完成本地或 Docker 编译、整机固件烧录和串口验收。

## 硬件要求和引脚

- 立创 BK7258 开发板及扩展板、支持数据传输的 USB Type-C 线。
- 本例不操作 LCD、按键、传感器或 TF 卡。
- 板级代码仅将 `BOARD_PWR_EN_GPIO`（外部 3.3 V 总使能）拉高；日志/下载使用板载 CH340K 对应的 UART0。
- 引脚号、有效电平和 UART 复用请始终查阅[板卡唯一权威映射](../../board_design/pinmap.md)和 [`bsp_gpio.h`](../../components/bsp_gpio/bsp_gpio.h)，不要从本文复制映射到新板设计。

## 软件配置

- 工程根 CMake 通过 `lichuang_project_setup()` 接入仓库公共组件，AP 组件依赖 `bsp_gpio`。
- `ap/config/bk7258_ap/usr_gpio_cfg.h` 转发到 `components/board_cfg` 的统一映射。
- 当前 `auto_partitions.csv` 使用标准 AP/CP/OTA 分区，`ram_regions.csv` 声明并完整规划 16 MiB PSRAM；运行本例无需改分区。
- 默认目录布局为 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级，工程 `Makefile` 会自动找到 SDK。

## 编译命令

在本工程目录执行其一：

```bash
make bk7258
```

```bash
./dbuild.sh bk7258
```

第一条使用本机工具链，第二条使用 Docker。需要排除旧产物时先执行 `make clean`，再重新编译。

## 固件位置

整机烧录文件为：

```text
build/bk7258/hello_board/package/all-app.bin
```

不要选择 AP、CP 或分区中间镜像代替 `package/all-app.bin`。

## 烧录和运行步骤

1. 用 USB 数据线连接开发板，确认系统枚举出 CH340K 串口。
2. 按[固件烧录参考](../../docs/reference/firmware-download.md)选择上述 `all-app.bin`；下载波特率使用 `1500000`，应用复位波特率使用 `115200`。
3. 烧录完成后让下载工具释放串口。
4. 按[串口控制台参考](../../docs/reference/serial-console.md)以 `115200 8N1`、无流控打开终端。
5. 保持终端已打开，短按复位键并保存完整启动日志。

## 预期日志或现象

源码定义的关键通过标志是：

```text
READY: hello board
```

日志前缀、核名、时间戳可能变化，以消息正文为准。人工硬件验收至少应确认：烧录成功、复位后串口可见该标志、开发板没有反复复位；本文不宣称本次修改已完成上板验证。

## CLI/AT 操作方法

无需 CLI/AT。本工程没有注册项目专用命令，只需查看启动日志。

## 常见问题

- 找不到 SDK：确认 `bk_avdk_smp_sdk` 与 `lichuang_bk7258` 同级，并从本工程目录执行命令。
- 没有生成固件：向上查找第一条编译或链接错误，不要沿用旧的 `all-app.bin`。
- 烧录成功但没有日志：先释放下载工具占用的串口，再核对 `115200 8N1`、USB 数据线和实际端口。
- `hello_board` 仍失败：先按[通用排障](../../docs/reference/troubleshooting.md)修复环境、编译、烧录或串口链路，再排查外设工程。

## 代码入口

教学调用链：

```text
AP main()
  -> bk_init()
  -> bsp_gpio_init_power_master()
       -> 初始化 GPIO 驱动
       -> BOARD_PWR_EN_GPIO 拉高
       -> 等待外部 3.3 V 稳定
  -> BK_LOGI("READY: hello board")
```

应用入口位于 [`ap/ap_main.c`](ap/ap_main.c)；AP 依赖在 [`ap/CMakeLists.txt`](ap/CMakeLists.txt)；公共供电时序在 [`components/bsp_gpio`](../../components/bsp_gpio/)。

## 可扩展方向

- 在确认最小链路稳定后，按需增加 `bsp_gpio` 的外设分组初始化。
- 增加周期任务，学习 RTOS 线程、延时和日志接口。
- 将启动自检结果汇总为统一的板卡产测状态，但应保留本例作为最小基线。

## 相关示例

- [`key_test`](../key_test/)：在最小启动基础上增加 SW2 中断与消抖。
- [`st7789_test`](../st7789_test/)：增加 LCD 供电、显示控制器和帧缓冲。
- [`gsensor_test`](../gsensor_test/)：增加共享模拟 I2C 传感器访问。
- [`sdcard_test`](../sdcard_test/)：增加 SDIO、FATFS 和文件读写。
