cmake_minimum_required(VERSION 3.5)

include(${CMAKE_CURRENT_LIST_DIR}/../../cmake/lichuang_project.cmake)

# ST7789V2 接收大端 RGB565，LVGL V9 软件渲染输出为小端，
# 在显示 flush 时交换每个像素的两个字节。
add_compile_definitions(CONFIG_LV_COLOR_16_SWAP=1)

lichuang_project_setup(
    EXTRA_COMPONENTS_DIRS ${CMAKE_CURRENT_SOURCE_DIR}/ap/modules
)
project(app)
