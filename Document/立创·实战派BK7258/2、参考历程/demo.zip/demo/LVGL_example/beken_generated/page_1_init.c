/*
 * Copyright (c) 2025 BekenCorp. All rights reserved.
 * 
 * This software is proprietary and confidential. No part of this software may be
 * reproduced, distributed, or transmitted in any form or by any means, including
 * photocopying, recording, or other electronic or mechanical methods, without the
 * prior written permission of BekenCorp, except in the case of brief quotations
 * embodied in critical reviews and certain other noncommercial uses permitted
 * by copyright law.
 * 
 * For permission requests, write to BekenCorp at armino_support@bekencorp.com.

 * Author: Beken LVGL Designer Tool
*/ 
#include "lvgl.h"
#include "beken_ui.h"
#include "custom_func.h"
#include "event_runtime.h"
#include <stdio.h>
#include <string.h>
/* Animation exec wrappers for style properties */
typedef void (*anim_color_setter_cb_t)(lv_obj_t * obj, lv_color_t color, lv_opa_t opa);
typedef enum {
    ANIM_EASING_LINEAR = 0,
    ANIM_EASING_EASE_IN,
    ANIM_EASING_EASE_OUT,
    ANIM_EASING_EASE_IN_OUT,
    ANIM_EASING_OVERSHOOT,
    ANIM_EASING_BOUNCE,
    ANIM_EASING_STEP,
} anim_easing_t;
typedef struct {
    uint32_t time_ms;
    int64_t value;
    anim_easing_t easing;
} anim_keyframe_t;
typedef struct {
    lv_obj_t * target;
    const anim_keyframe_t * keyframes;
    uint16_t keyframe_count;
    uint32_t duration;
    bool is_color;
    lv_anim_exec_xcb_t setter_i32;
    anim_color_setter_cb_t setter_color;
} anim_track_ctx_t;

static uint32_t anim_decode_color_rgba(uint64_t c) {
    // 新格式：marker + (RGB << 8) + A
    if (c >= 0x100000000ULL) {
        return (uint32_t)(c - 0x100000000ULL) & 0xFFFFFFFFU;
    }
    // 旧格式1：仅 RGB，默认 alpha=255
    if (c <= 0xFFFFFFULL) {
        return ((uint32_t)c << 8) | 0xFFU;
    }
    // 旧格式2：直接使用 0xRRGGBBAA
    return (uint32_t)c & 0xFFFFFFFFU;
}

static uint32_t anim_color_lerp_rgba(uint64_t c0, uint64_t c1, uint32_t t, uint32_t d) {
    c0 = anim_decode_color_rgba(c0);
    c1 = anim_decode_color_rgba(c1);
    if (d == 0) return c1 & 0xFFFFFFFFU;
    if (t > d) t = d;
    uint32_t r0 = (c0 >> 24) & 0xFFU;
    uint32_t g0 = (c0 >> 16) & 0xFFU;
    uint32_t b0 = (c0 >> 8) & 0xFFU;
    uint32_t a0 = c0 & 0xFFU;
    uint32_t r1 = (c1 >> 24) & 0xFFU;
    uint32_t g1 = (c1 >> 16) & 0xFFU;
    uint32_t b1 = (c1 >> 8) & 0xFFU;
    uint32_t a1 = c1 & 0xFFU;
    uint32_t rr = r0 + (((int32_t)r1 - (int32_t)r0) * (int32_t)t + (int32_t)(d / 2U)) / (int32_t)d;
    uint32_t gg = g0 + (((int32_t)g1 - (int32_t)g0) * (int32_t)t + (int32_t)(d / 2U)) / (int32_t)d;
    uint32_t bb = b0 + (((int32_t)b1 - (int32_t)b0) * (int32_t)t + (int32_t)(d / 2U)) / (int32_t)d;
    uint32_t aa = a0 + (((int32_t)a1 - (int32_t)a0) * (int32_t)t + (int32_t)(d / 2U)) / (int32_t)d;
    return ((rr & 0xFFU) << 24) | ((gg & 0xFFU) << 16) | ((bb & 0xFFU) << 8) | (aa & 0xFFU);
}

static uint32_t anim_apply_easing_u16(uint32_t progress, anim_easing_t easing) {
    if (progress > 1024U) progress = 1024U;
    double r = (double)progress / 1024.0;
    double out = r;
    switch (easing) {
        case ANIM_EASING_EASE_IN:
            out = r * r;
            break;
        case ANIM_EASING_EASE_OUT:
            out = 1.0 - (1.0 - r) * (1.0 - r);
            break;
        case ANIM_EASING_EASE_IN_OUT:
            out = 3.0 * r * r - 2.0 * r * r * r;
            break;
        case ANIM_EASING_OVERSHOOT: {
            const double s = 1.70158;
            out = r * r * ((s + 1.0) * r - s);
            break;
        }
        case ANIM_EASING_BOUNCE:
            if (r < 1.0 / 2.75) {
                out = 7.5625 * r * r;
            } else if (r < 2.0 / 2.75) {
                double r2 = r - 1.5 / 2.75;
                out = 7.5625 * r2 * r2 + 0.75;
            } else if (r < 2.5 / 2.75) {
                double r2 = r - 2.25 / 2.75;
                out = 7.5625 * r2 * r2 + 0.9375;
            } else {
                double r2 = r - 2.625 / 2.75;
                out = 7.5625 * r2 * r2 + 0.984375;
            }
            break;
        case ANIM_EASING_STEP:
            out = (r < 1.0) ? 0.0 : 1.0;
            break;
        case ANIM_EASING_LINEAR:
        default:
            out = r;
            break;
    }
    if (out < 0.0) out = 0.0;
    if (out > 1.0) out = 1.0;
    return (uint32_t)(out * 1024.0 + 0.5);
}

static int64_t anim_keyframe_value_at(const anim_track_ctx_t * ctx, uint32_t t) {
    if (ctx == NULL || ctx->keyframes == NULL || ctx->keyframe_count == 0U) return 0;
    const anim_keyframe_t * kfs = ctx->keyframes;
    uint16_t n = ctx->keyframe_count;
    if (t <= kfs[0].time_ms) return kfs[0].value;
    if (t >= kfs[n - 1].time_ms) return kfs[n - 1].value;

    uint16_t i = 0;
    while ((i + 1U) < n && t >= kfs[i + 1U].time_ms) i++;
    const anim_keyframe_t * k0 = &kfs[i];
    const anim_keyframe_t * k1 = &kfs[i + 1U];
    uint32_t span = (k1->time_ms > k0->time_ms) ? (k1->time_ms - k0->time_ms) : 0U;
    if (span == 0U) return k1->value;

    uint32_t local_t = t - k0->time_ms;
    uint32_t p = (uint32_t)(((uint64_t)local_t * 1024ULL + (uint64_t)(span / 2U)) / (uint64_t)span);
    p = anim_apply_easing_u16(p, k1->easing);

    if (ctx->is_color) {
        uint32_t rgba = anim_color_lerp_rgba((uint64_t)k0->value, (uint64_t)k1->value, p, 1024U);
        return (int64_t)(uint64_t)rgba;
    }

    int64_t dv = k1->value - k0->value;
    int64_t out = k0->value + (int64_t)(((dv * (int64_t)p) + 512LL) / 1024LL);
    return out;
}

static void anim_track_exec_common(lv_anim_t * a, int32_t v) {
    anim_track_ctx_t * ctx = (anim_track_ctx_t *)lv_anim_get_user_data(a);
    if (ctx == NULL || ctx->target == NULL || ctx->keyframes == NULL || ctx->keyframe_count == 0U) return;
    uint32_t d = ctx->duration > 0U ? ctx->duration : 1U;
    uint32_t t = (v < 0) ? 0U : (uint32_t)v;
    if (t > d) t = d;
    int64_t raw = anim_keyframe_value_at(ctx, t);

    if (ctx->is_color) {
        if (ctx->setter_color == NULL) return;
        uint32_t rgba = anim_decode_color_rgba((uint64_t)raw);
        ctx->setter_color(ctx->target, lv_color_hex((rgba >> 8) & 0xFFFFFFU), (lv_opa_t)(rgba & 0xFFU));
        return;
    }
    if (ctx->setter_i32 == NULL) return;
    ctx->setter_i32(ctx->target, (int32_t)raw);
}

static void anim_track_exec_x(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_y(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_width(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_height(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_opa(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_transform_rotation(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_bg_color(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_border_width(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_radius(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_border_color(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_shadow_color(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_shadow_width(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_shadow_spread(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_shadow_offset_x(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_shadow_offset_y(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_pad_top(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_pad_bottom(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_pad_left(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_pad_right(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_pad_row(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }
static void anim_track_exec_pad_column(lv_anim_t * a, int32_t v) { anim_track_exec_common(a, v); }

static void anim_set_style_opa(void * var, int32_t v) { lv_obj_set_style_opa((lv_obj_t *)var, (lv_opa_t)v, LV_PART_MAIN); }
static void anim_set_style_transform_rotation(void * var, int32_t v) { lv_obj_set_style_transform_rotation((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_bg_color(void * var, int32_t v) { lv_obj_set_style_bg_color((lv_obj_t *)var, lv_color_hex((uint32_t)v), LV_PART_MAIN); }
static void anim_apply_style_bg_color(lv_obj_t * obj, lv_color_t color, lv_opa_t opa) {
    lv_obj_set_style_bg_color(obj, color, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(obj, opa, LV_PART_MAIN);
}
static void anim_set_style_border_width(void * var, int32_t v) { lv_obj_set_style_border_width((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_radius(void * var, int32_t v) { lv_obj_set_style_radius((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_border_color(void * var, int32_t v) { lv_obj_set_style_border_color((lv_obj_t *)var, lv_color_hex((uint32_t)v), LV_PART_MAIN); }
static void anim_apply_style_border_color(lv_obj_t * obj, lv_color_t color, lv_opa_t opa) {
    lv_obj_set_style_border_color(obj, color, LV_PART_MAIN);
    lv_obj_set_style_border_opa(obj, opa, LV_PART_MAIN);
}
static void anim_set_style_shadow_color(void * var, int32_t v) { lv_obj_set_style_shadow_color((lv_obj_t *)var, lv_color_hex((uint32_t)v), LV_PART_MAIN); }
static void anim_apply_style_shadow_color(lv_obj_t * obj, lv_color_t color, lv_opa_t opa) {
    lv_obj_set_style_shadow_color(obj, color, LV_PART_MAIN);
    lv_obj_set_style_shadow_opa(obj, opa, LV_PART_MAIN);
}
static void anim_set_style_shadow_width(void * var, int32_t v) { lv_obj_set_style_shadow_width((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_shadow_spread(void * var, int32_t v) { lv_obj_set_style_shadow_spread((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_shadow_offset_x(void * var, int32_t v) { lv_obj_set_style_shadow_offset_x((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_shadow_offset_y(void * var, int32_t v) { lv_obj_set_style_shadow_offset_y((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_pad_top(void * var, int32_t v) { lv_obj_set_style_pad_top((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_pad_bottom(void * var, int32_t v) { lv_obj_set_style_pad_bottom((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_pad_left(void * var, int32_t v) { lv_obj_set_style_pad_left((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_pad_right(void * var, int32_t v) { lv_obj_set_style_pad_right((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_pad_row(void * var, int32_t v) { lv_obj_set_style_pad_row((lv_obj_t *)var, v, LV_PART_MAIN); }
static void anim_set_style_pad_column(void * var, int32_t v) { lv_obj_set_style_pad_column((lv_obj_t *)var, v, LV_PART_MAIN); }



/*
 * @brief: init page page_1
 */
void init_page_page_1(bk_lv_ui_t *bk_ui)
{
    if (bk_ui->page_1 != NULL && lv_obj_is_valid(bk_ui->page_1)) {
        destroy_page_page_1(bk_ui);
    }
    

    bk_ui->page_1 = lv_obj_create(NULL);
    lv_obj_set_scrollbar_mode(bk_ui->page_1, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_size(bk_ui->page_1, 320, 240);
    lv_obj_set_style_bg_color(bk_ui->page_1, lv_color_hex(0x1565c0), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_color(bk_ui->page_1, lv_color_hex(0x0a1f3d), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1, LV_GRAD_DIR_VER, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_main_stop(bk_ui->page_1, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_stop(bk_ui->page_1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_opa(bk_ui->page_1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_title_frame = lv_obj_create(bk_ui->page_1);
    lv_obj_set_x(bk_ui->page_1_title_frame, 30);
    lv_obj_set_y(bk_ui->page_1_title_frame, 85);
    lv_obj_set_width(bk_ui->page_1_title_frame, 260);
    lv_obj_set_height(bk_ui->page_1_title_frame, 70);
    lv_obj_set_style_bg_color(bk_ui->page_1_title_frame, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_title_frame, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(bk_ui->page_1_title_frame, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_width(bk_ui->page_1_title_frame, 1, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(bk_ui->page_1_title_frame, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_side(bk_ui->page_1_title_frame, LV_BORDER_SIDE_FULL, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_radius(bk_ui->page_1_title_frame, 4, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_clip_corner(bk_ui->page_1_title_frame, false, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_row(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_column(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_color(bk_ui->page_1_title_frame, lv_color_hex(0x1e7fcf), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(bk_ui->page_1_title_frame, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_offset_x(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_offset_y(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_spread(bk_ui->page_1_title_frame, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_title_lbl = lv_label_create(bk_ui->page_1_title_frame);
    lv_label_set_text(bk_ui->page_1_title_lbl, "BK7258 LVGL");
    lv_label_set_long_mode(bk_ui->page_1_title_lbl, LV_LABEL_LONG_MODE_WRAP);
    lv_obj_set_x(bk_ui->page_1_title_lbl, 0);
    lv_obj_set_y(bk_ui->page_1_title_lbl, 22);
    lv_obj_set_width(bk_ui->page_1_title_lbl, 260);
    lv_obj_set_height(bk_ui->page_1_title_lbl, 28);
    lv_obj_set_style_bg_color(bk_ui->page_1_title_lbl, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_title_lbl, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(bk_ui->page_1_title_lbl, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_width(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(bk_ui->page_1_title_lbl, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_side(bk_ui->page_1_title_lbl, LV_BORDER_SIDE_FULL, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_radius(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_clip_corner(bk_ui->page_1_title_lbl, false, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_row(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_column(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(bk_ui->page_1_title_lbl, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(bk_ui->page_1_title_lbl, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(bk_ui->page_1_title_lbl, &lv_font_montserrat_regular_20, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(bk_ui->page_1_title_lbl, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(bk_ui->page_1_title_lbl, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_color(bk_ui->page_1_title_lbl, lv_color_hex(0x1e7fcf), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(bk_ui->page_1_title_lbl, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_offset_x(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_offset_y(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_spread(bk_ui->page_1_title_lbl, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_top_bar = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_top_bar_points[] = {
        { 15, 0 },
        { 305, 0 }
    };
    lv_line_set_points(bk_ui->page_1_top_bar, page_1_top_bar_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_top_bar, false);
    lv_obj_set_x(bk_ui->page_1_top_bar, 0);
    lv_obj_set_y(bk_ui->page_1_top_bar, 10);
    lv_obj_set_width(bk_ui->page_1_top_bar, 100);
    lv_obj_set_height(bk_ui->page_1_top_bar, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_top_bar, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_top_bar, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_top_bar, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_top_bar, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_top_bar, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_top_bar, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_top_bar, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_bot_bar = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_bot_bar_points[] = {
        { 15, 0 },
        { 305, 0 }
    };
    lv_line_set_points(bk_ui->page_1_bot_bar, page_1_bot_bar_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_bot_bar, false);
    lv_obj_set_x(bk_ui->page_1_bot_bar, 0);
    lv_obj_set_y(bk_ui->page_1_bot_bar, 228);
    lv_obj_set_width(bk_ui->page_1_bot_bar, 100);
    lv_obj_set_height(bk_ui->page_1_bot_bar, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_bot_bar, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_bot_bar, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_bot_bar, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_bot_bar, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_bot_bar, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_bot_bar, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_bot_bar, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_acc_top = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_acc_top_points[] = {
        { 50, 0 },
        { 270, 0 }
    };
    lv_line_set_points(bk_ui->page_1_acc_top, page_1_acc_top_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_acc_top, false);
    lv_obj_set_x(bk_ui->page_1_acc_top, 0);
    lv_obj_set_y(bk_ui->page_1_acc_top, 78);
    lv_obj_set_width(bk_ui->page_1_acc_top, 100);
    lv_obj_set_height(bk_ui->page_1_acc_top, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_acc_top, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_acc_top, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_acc_top, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_acc_top, 1, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_acc_top, lv_color_hex(0x4fc3f7), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_acc_top, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_acc_top, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_acc_bot = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_acc_bot_points[] = {
        { 50, 0 },
        { 270, 0 }
    };
    lv_line_set_points(bk_ui->page_1_acc_bot, page_1_acc_bot_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_acc_bot, false);
    lv_obj_set_x(bk_ui->page_1_acc_bot, 0);
    lv_obj_set_y(bk_ui->page_1_acc_bot, 162);
    lv_obj_set_width(bk_ui->page_1_acc_bot, 100);
    lv_obj_set_height(bk_ui->page_1_acc_bot, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_acc_bot, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_acc_bot, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_acc_bot, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_acc_bot, 1, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_acc_bot, lv_color_hex(0x4fc3f7), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_acc_bot, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_acc_bot, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_tl_h = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_tl_h_points[] = {
        { 0, 0 },
        { 24, 0 }
    };
    lv_line_set_points(bk_ui->page_1_corner_tl_h, page_1_corner_tl_h_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_tl_h, false);
    lv_obj_set_x(bk_ui->page_1_corner_tl_h, 8);
    lv_obj_set_y(bk_ui->page_1_corner_tl_h, 8);
    lv_obj_set_width(bk_ui->page_1_corner_tl_h, 100);
    lv_obj_set_height(bk_ui->page_1_corner_tl_h, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_tl_h, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_tl_h, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_tl_h, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_tl_h, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_tl_h, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_tl_h, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_tl_h, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_tl_v = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_tl_v_points[] = {
        { 0, 0 },
        { 0, 24 }
    };
    lv_line_set_points(bk_ui->page_1_corner_tl_v, page_1_corner_tl_v_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_tl_v, false);
    lv_obj_set_x(bk_ui->page_1_corner_tl_v, 8);
    lv_obj_set_y(bk_ui->page_1_corner_tl_v, 8);
    lv_obj_set_width(bk_ui->page_1_corner_tl_v, 100);
    lv_obj_set_height(bk_ui->page_1_corner_tl_v, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_tl_v, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_tl_v, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_tl_v, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_tl_v, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_tl_v, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_tl_v, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_tl_v, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_tr_h = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_tr_h_points[] = {
        { 0, 0 },
        { 24, 0 }
    };
    lv_line_set_points(bk_ui->page_1_corner_tr_h, page_1_corner_tr_h_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_tr_h, false);
    lv_obj_set_x(bk_ui->page_1_corner_tr_h, 288);
    lv_obj_set_y(bk_ui->page_1_corner_tr_h, 8);
    lv_obj_set_width(bk_ui->page_1_corner_tr_h, 100);
    lv_obj_set_height(bk_ui->page_1_corner_tr_h, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_tr_h, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_tr_h, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_tr_h, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_tr_h, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_tr_h, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_tr_h, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_tr_h, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_tr_v = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_tr_v_points[] = {
        { 0, 0 },
        { 0, 24 }
    };
    lv_line_set_points(bk_ui->page_1_corner_tr_v, page_1_corner_tr_v_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_tr_v, false);
    lv_obj_set_x(bk_ui->page_1_corner_tr_v, 312);
    lv_obj_set_y(bk_ui->page_1_corner_tr_v, 8);
    lv_obj_set_width(bk_ui->page_1_corner_tr_v, 100);
    lv_obj_set_height(bk_ui->page_1_corner_tr_v, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_tr_v, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_tr_v, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_tr_v, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_tr_v, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_tr_v, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_tr_v, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_tr_v, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_bl_h = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_bl_h_points[] = {
        { 0, 0 },
        { 24, 0 }
    };
    lv_line_set_points(bk_ui->page_1_corner_bl_h, page_1_corner_bl_h_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_bl_h, false);
    lv_obj_set_x(bk_ui->page_1_corner_bl_h, 8);
    lv_obj_set_y(bk_ui->page_1_corner_bl_h, 208);
    lv_obj_set_width(bk_ui->page_1_corner_bl_h, 100);
    lv_obj_set_height(bk_ui->page_1_corner_bl_h, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_bl_h, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_bl_h, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_bl_h, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_bl_h, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_bl_h, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_bl_h, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_bl_h, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_bl_v = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_bl_v_points[] = {
        { 0, 0 },
        { 0, 24 }
    };
    lv_line_set_points(bk_ui->page_1_corner_bl_v, page_1_corner_bl_v_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_bl_v, false);
    lv_obj_set_x(bk_ui->page_1_corner_bl_v, 8);
    lv_obj_set_y(bk_ui->page_1_corner_bl_v, 208);
    lv_obj_set_width(bk_ui->page_1_corner_bl_v, 100);
    lv_obj_set_height(bk_ui->page_1_corner_bl_v, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_bl_v, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_bl_v, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_bl_v, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_bl_v, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_bl_v, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_bl_v, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_bl_v, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_br_h = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_br_h_points[] = {
        { 0, 0 },
        { 24, 0 }
    };
    lv_line_set_points(bk_ui->page_1_corner_br_h, page_1_corner_br_h_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_br_h, false);
    lv_obj_set_x(bk_ui->page_1_corner_br_h, 288);
    lv_obj_set_y(bk_ui->page_1_corner_br_h, 208);
    lv_obj_set_width(bk_ui->page_1_corner_br_h, 100);
    lv_obj_set_height(bk_ui->page_1_corner_br_h, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_br_h, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_br_h, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_br_h, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_br_h, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_br_h, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_br_h, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_br_h, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    bk_ui->page_1_corner_br_v = lv_line_create(bk_ui->page_1);
    static lv_point_precise_t page_1_corner_br_v_points[] = {
        { 0, 0 },
        { 0, 24 }
    };
    lv_line_set_points(bk_ui->page_1_corner_br_v, page_1_corner_br_v_points, 2);
    lv_line_set_y_invert(bk_ui->page_1_corner_br_v, false);
    lv_obj_set_x(bk_ui->page_1_corner_br_v, 312);
    lv_obj_set_y(bk_ui->page_1_corner_br_v, 208);
    lv_obj_set_width(bk_ui->page_1_corner_br_v, 100);
    lv_obj_set_height(bk_ui->page_1_corner_br_v, 100);
    lv_obj_set_style_bg_color(bk_ui->page_1_corner_br_v, lv_color_hex(0xffffff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(bk_ui->page_1_corner_br_v, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(bk_ui->page_1_corner_br_v, LV_GRAD_DIR_NONE, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_width(bk_ui->page_1_corner_br_v, 2, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(bk_ui->page_1_corner_br_v, lv_color_hex(0x00e5ff), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(bk_ui->page_1_corner_br_v, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(bk_ui->page_1_corner_br_v, true, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_update_layout(bk_ui->page_1);
}

/*
 * @brief: destroy page page_1
 */
void destroy_page_page_1(bk_lv_ui_t *bk_ui)
{
    if (bk_ui == NULL) {
        return;
    }
    
    if (bk_ui->page_1 != NULL) {
        lv_obj_del(bk_ui->page_1);
        bk_ui->page_1 = NULL;
    }
}