# BK7258 LVGL Designer 示例

本工程把 Beken LVGL UI Designer 生成的页面接入立创 BK7258 扩展板，使用 ST7789V2 显示、FT6336 触摸和 LVGL 9.3。

## 示例目标

- 在 240 × 320 物理屏上以横屏 320 × 240 逻辑分辨率运行 Designer 页面；
- 验证 ST7789V2、FT6336、LVGL vendor port、PSRAM framebuffer 和生成代码集成；
- 建立 Designer 生成代码与项目级硬件适配之间的清晰边界。

## 学习内容

- 初始化 SPI 显示设备、LVGL vendor port 和触摸输入设备；
- 使用 `ROTATE_90` 统一处理物理竖屏到逻辑横屏的坐标变换；
- 通过两个 RGB565 framebuffer 进行 partial render；
- 使用项目组件 CMake 自动收集 `beken_generated/` 中的生成代码；
- 在首帧完成后再打开低有效背光，减少启动花屏。

## 硬件要求和引脚

- 立创 BK7258 扩展板、板载 240 × 320 ST7789V2 屏和 FT6336 触摸；
- LCD SPI1：GPIO2=SCK、GPIO3=CS、GPIO4=MOSI，GPIO5=DC，GPIO12=RESET；
- GPIO13 为高有效 LCD 电源，GPIO25 为低有效背光（拉低点亮）；
- 触摸与其他板载设备共享 I2C1：GPIO42=SCL、GPIO43=SDA，GPIO45=INT，GPIO46=RESET；
- GPIO22 为扩展板外部 3.3 V 总使能；
- USB-C 对应 CP UART0，GPIO10/11 用于下载和日志。

显示链路是 SPI1。源码中的 `LCD_QSPI_64M` 是 SDK 的显示时钟枚举名，不能据此把硬件误认为 QSPI 接线。

## 软件配置

- `LVGL_example.bkprj` 声明 LVGL 9.3 和 320 × 240 Designer 画布；
- AP 配置启用 `CONFIG_LCD_SPI_ST7789V2`、`CONFIG_TP_FT6336`、`CONFIG_LVGL_V9`、16 bit 色深和两个 framebuffer；
- 根 `CMakeLists.txt` 定义 `CONFIG_LV_COLOR_16_SWAP=1`，适配 ST7789V2 所需 RGB565 字节序；
- `ap/modules/lvgl_example_ui/CMakeLists.txt` 引入 `beken_generated.cmake`，递归收集生成的 `.c` 和头文件目录；
- 工程分区文件的 AP 应用区为 1224 KiB；构建时使用 `partitions/bk7258/auto_partitions.csv`。

物理参数为 240 × 320，运行时通过 `ROTATE_90` 得到 320 × 240 逻辑画布。设备侧使用同级 SDK 提供的 LVGL，不把 PC 仿真目录中的 LVGL 编入固件。

## 编译命令

默认目录结构为 `lichuang_bk7258` 与 `bk_avdk_smp_sdk` 同级。在本工程目录执行：

```bash
make bk7258
```

SDK 不在默认位置时：

```bash
make bk7258 SDK_DIR=/path/to/bk_avdk_smp_sdk
```

Docker wrapper：

```bash
./dbuild.sh bk7258
```

也可在运行 wrapper 前设置 `SDK_DIR`。

## 固件位置

```text
build/bk7258/LVGL_example/package/all-app.bin
```

烧录时选择完整的 `all-app.bin`，不要选择 AP、CP 等中间镜像。

## 烧录和运行步骤

1. USB Type-C 连接开发板，关闭占用串口的终端；
2. 在 BKFIL 开发模式中选择开发板串口和上述 `all-app.bin`；
3. 下载波特率可设为 1500000，应用复位波特率设为 115200，开始烧录；
4. 烧录完成后释放串口，以 `115200、8N1、无流控` 打开日志；
5. 复位开发板，等待首帧绘制和背光开启；
6. 检查页面方向、颜色、标题显示和触摸坐标。

## 预期日志或现象

正常日志：

```text
READY: LVGL example UI
UI ready: physical=240x320, logical=320x240
```

屏幕应横向显示 Designer 生成的蓝色页面和 `BK7258 LVGL` 标题，首帧完成约 300 ms 后背光点亮。触摸点应与横屏坐标一致，不应出现重复旋转造成的轴交换或镜像。

若出现 `frame buffer ... alloc failed`、`create SPI display failed` 或 `LVGL example UI init failed`，不得判显示 PASS。

## CLI/AT 操作方法

本工程没有示例专用 CLI 或 AT 命令；上电后自动初始化 UI。USB-C 串口用于查看 CP/AP 日志，参数为：

```text
115200、8N1、无流控
```

页面交互通过 FT6336 触摸完成，不需要发送串口命令。

## 常见问题

- 黑屏：检查 GPIO13 屏电源和 GPIO25 低有效背光，并确认烧录的是本工程 `all-app.bin`；
- 白屏、花屏或颜色异常：核对 ST7789V2、SPI1 接线和 `CONFIG_LV_COLOR_16_SWAP=1`；
- 页面方向错误：Designer 保持 320 × 240，设备端保持物理 240 × 320 和 `ROTATE_90`，不要在多层重复旋转；
- 触摸坐标偏转：本工程让触摸驱动返回面板原生坐标，由 LVGL V9 统一旋转；不要再叠加驱动旋转；
- 中文显示为空框：重新生成包含目标中文字形的字体资源；
- 链接阶段缺少页面符号：确认 Designer 已完整生成 `beken_generated/`，且 `beken_generated.cmake` 仍存在；
- framebuffer 分配失败：确认 PSRAM 配置和分区未被其他工程配置覆盖。

## 代码入口

- `ap/ap_main.c`：初始化板级电源与外设、媒体服务并启动 UI；
- `ap/modules/lvgl_example_ui/lvgl_example_ui.c`：显示、framebuffer、旋转、触摸和背光适配；
- `ap/modules/lvgl_example_ui/CMakeLists.txt`：接入 Designer 生成源文件；
- `beken_generated/beken_ui.c`：生成 UI 的入口 `beken_ui_init()`；
- `beken_generated/page_1_init.c`：当前页面对象和 `BK7258 LVGL` 标题；
- `ap/config/bk7258_ap/config`：LCD、触摸、LVGL、PSRAM 配置；
- `partitions/bk7258/auto_partitions.csv`：本工程 Flash 分区。

## Designer 生成代码边界

1. 页面布局、控件、样式和字体以 `LVGL_example.bkprj` 为源，在 Beken LVGL UI Designer 中修改；
2. 重新生成到本工程 `beken_generated/`；这里的普通生成文件可能在下次生成时被覆盖，不应把不可丢失的板级逻辑直接手改进去；
3. 仅在 Designer 明确定义并保证保留的 custom 扩展点中放自定义页面逻辑；不确定保留规则时，放到项目自有模块并由生成回调调用；
4. 屏幕、旋转、framebuffer、触摸和背光适配属于 `ap/modules/lvgl_example_ui/`，不要混入页面生成文件；
5. `components/bsp_*` 是多个工程共用的板级组件。仅修改本示例页面时不要改公共组件，更不要修改同级外部 SDK；
6. `lv_port_pc_simulate/` 只用于 PC 仿真，不参与 BK7258 固件构建，也不要把其私有 LVGL 副本加入设备固件；
7. 不要删除 `ap/`、`cp/`、`partitions/`、项目 CMake、Makefile 或 `beken_generated.cmake`。

## 可扩展方向

- 在 Designer 中增加多页面导航、按钮事件、动画和资源；
- 把业务数据与 UI 生成层解耦，通过项目自有模块更新控件；
- 增加触摸边界、长按、滑动和多次重入测试；
- 评估图片缓存、字体体积和 framebuffer 对 PSRAM/Flash 的占用；
- 增加低功耗唤醒后的显示与触摸恢复流程。

## 相关示例

- `../st7789_test/`：单独验证 ST7789 显示；
- `../lcd_tp_test/`：联合验证 LCD 与触摸；
- `../key_lcd_demo/`：按键与 LCD 交互；
- `../../docs/examples/peripherals/lvgl.md`：LVGL 集成说明；
- `../../docs/examples/peripherals/lcd-st7789.md`：ST7789 硬件与烧录说明。
