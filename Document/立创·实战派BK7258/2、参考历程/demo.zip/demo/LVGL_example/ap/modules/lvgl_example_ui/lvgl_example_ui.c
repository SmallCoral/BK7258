/**
 * @file lvgl_example_ui.c
 * @brief LVGL Designer 示例 UI 初始化实现
 *
 * 配置 ST7789 SPI 显示、FT6336 触摸与 LVGL V9，加载 Designer 生成的 beken_ui 页面。
 */

#include "lvgl_example_ui.h"

#include <components/bk_display.h>
#include <components/log.h>
#include <driver/drv_tp.h>
#include <driver/pwr_clk.h>
#include <frame_buffer.h>
#include <lv_vendor.h>
#include <lvgl.h>
#include <modules/pm.h>
#include <os/mem.h>
#include <os/os.h>

#include "beken_ui.h"
#include "bsp_gpio.h"
#include "bsp_lcd_st7789.h"

#define TAG "lvgl_ui"

extern lv_indev_t *indev_touchpad;

static bk_display_spi_ctlr_config_t s_spi_cfg = {
    .lcd_device = NULL, /* 运行时由 bsp_lcd_st7789_get 填充 */
    .spi_id = 1,
    .dc_pin = GPIO_5,
    .reset_pin = GPIO_12,
    .te_pin = 0,
};

/**
 * @brief 触摸输入读取回调（不做坐标旋转，由 LVGL ROTATE_90 统一处理）
 *
 * @param indev LVGL 输入设备（未使用）
 * @param data  输出触摸点与状态
 */
static void touchpad_read_no_rotate(lv_indev_t *indev, lv_indev_data_t *data)
{
    (void)indev;
    static int32_t last_x;
    static int32_t last_y;
    static lv_indev_state_t last_state = LV_INDEV_STATE_RELEASED;
    static uint8_t read_fail_count;
    tp_point_infor_t point;

    if (drv_tp_read(&point) == 0) {
        read_fail_count = 0;
        last_x = point.m_x;
        last_y = point.m_y;
        last_state = point.m_state
                         ? LV_INDEV_STATE_PRESSED
                         : LV_INDEV_STATE_RELEASED;
        data->continue_reading = point.m_need_continue;
    } else {
        data->continue_reading = false;
        if (last_state != LV_INDEV_STATE_RELEASED &&
            ++read_fail_count >= 5) {
            read_fail_count = 0;
            last_state = LV_INDEV_STATE_RELEASED;
            last_x = 0;
            last_y = 0;
        }
    }

    data->point.x = last_x;
    data->point.y = last_y;
    data->state = last_state;
}

bool lvgl_example_ui_init(void)
{
    lv_vnd_config_t cfg = {0};

    bk_pm_module_vote_psram_ctrl(
        PM_POWER_PSRAM_MODULE_NAME_LVGL_CODE_RUN,
        PM_POWER_MODULE_STATE_ON
    );

    /* 背光先关闭，LCD 完成首帧绘制后再点亮，避免启动花屏。 */
    board_gpio_set_high(BOARD_LCD_BL_PIN);
    board_gpio_set_high(BOARD_LCD_PWR_PIN);

    /* 物理竖屏 240×320 + 64M；INVON 由 bsp_lcd_st7789 固化。逻辑横屏靠 LVGL ROTATE_90。 */
    bsp_lcd_st7789_cfg_t lcd_cfg = {
        .landscape = false,
        .mirror_x  = false,
        .mirror_y  = false,
        .clk       = LCD_QSPI_64M,
    };
    const lcd_device_t *lcd = bsp_lcd_st7789_get(&lcd_cfg);
    s_spi_cfg.lcd_device = lcd;

    /*
     * ST7789V2 物理分辨率为 240×320；ROTATE_90 后 LVGL 逻辑画布
     * 为 320×240，与 Designer 工程保持一致。
     */
    cfg.width = lcd->width;
    cfg.height = lcd->height;
    cfg.render_mode = RENDER_PARTIAL_MODE;
    cfg.rotation = ROTATE_90;

    for (int i = 0; i < CONFIG_LVGL_FRAME_BUFFER_NUM; i++) {
        cfg.frame_buffer[i] = frame_buffer_display_malloc(
            cfg.width * cfg.height * sizeof(bk_color_t)
        );
        if (!cfg.frame_buffer[i] || !cfg.frame_buffer[i]->frame) {
            BK_LOGE(TAG, "frame buffer %d alloc failed\r\n", i);
            return false;
        }

        os_memset(
            cfg.frame_buffer[i]->frame,
            0,
            cfg.width * cfg.height * sizeof(bk_color_t)
        );
    }

    if (bk_display_spi_new(&cfg.handle, &s_spi_cfg) != AVDK_ERR_OK) {
        BK_LOGE(TAG, "create SPI display failed\r\n");
        return false;
    }

    lv_vendor_init(&cfg);
    bk_display_open(cfg.handle);

    drv_tp_open(cfg.width, cfg.height, TP_MIRROR_NONE);
    board_key_reinit_pin();
    if (indev_touchpad) {
        lv_indev_set_read_cb(indev_touchpad, touchpad_read_no_rotate);
    }

    lv_vendor_disp_lock();
    beken_ui_init();
    lv_vendor_disp_unlock();

    lv_vendor_start();

    rtos_delay_milliseconds(300);
    board_gpio_set_low(BOARD_LCD_BL_PIN);

    BK_LOGI(
        TAG,
        "UI ready: physical=%dx%d, logical=%dx%d\r\n",
        cfg.width,
        cfg.height,
        beken_get_screen_width(),
        beken_get_screen_height()
    );

    return true;
}
