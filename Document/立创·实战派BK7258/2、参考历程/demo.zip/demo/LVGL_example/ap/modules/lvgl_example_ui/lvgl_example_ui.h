/**
 * @file lvgl_example_ui.h
 * @brief LVGL Designer 示例 UI 初始化接口
 */

#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 ST7789V2、FT6336、LVGL V9 与 Designer 生成的页面
 *
 * @return true 初始化成功；false 初始化失败
 */
bool lvgl_example_ui_init(void);

#ifdef __cplusplus
}
#endif
