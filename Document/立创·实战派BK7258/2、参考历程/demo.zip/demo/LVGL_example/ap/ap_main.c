/**
 * @file ap_main.c
 * @brief BK7258 LVGL Designer 示例工程入口
 *
 * 初始化板级 GPIO 与 media_service，启动 ST7789 + FT6336 + LVGL V9 UI。
 */

#include "bk_private/bk_init.h"
#include <components/log.h>
#include <media_service.h>

#include "bsp_gpio.h"
#include "lvgl_example_ui.h"

#define TAG "lvgl_example"

/**
 * @brief AP 应用入口：初始化板级资源并启动 LVGL UI
 *
 * @return 0 成功，-1 初始化失败
 */
int main(void)
{
    if (bk_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: system init\r\n");
        return -1;
    }
    /* TP 的 RST/INT 由 TP 框架接管，故不调用 bsp_gpio_init_tp() */
    if (bsp_gpio_init_power_master() != BK_OK ||
        bsp_gpio_init_lcd() != BK_OK ||
        bsp_gpio_init_key() != BK_OK) {
        BK_LOGE(TAG, "FAIL: board GPIO init\r\n");
        return -1;
    }
    if (media_service_init() != BK_OK) {
        BK_LOGE(TAG, "FAIL: media service init\r\n");
        return -1;
    }

    if (!lvgl_example_ui_init()) {
        BK_LOGE(TAG, "FAIL: LVGL UI init\r\n");
        return -1;
    }

    BK_LOGI(TAG, "READY: LVGL example UI\r\n");
    return 0;
}
