set(incs .)
set(srcs ap_main.c)

set(priv_req
    media_service
    lvgl_example_ui
    bsp_gpio
)

armino_component_register(
    SRCS "${srcs}"
    INCLUDE_DIRS "${incs}"
    PRIV_REQUIRES "${priv_req}"
)
