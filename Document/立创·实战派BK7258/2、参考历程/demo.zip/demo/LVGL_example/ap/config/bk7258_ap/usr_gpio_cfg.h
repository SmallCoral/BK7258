/**
 * @file usr_gpio_cfg.h
 * @brief AP 侧 GPIO 默认管脚映射配置
 *
 * 转发至 board_cfg 统一默认配置；如需覆盖扩展口功能，可在此直接定义 GPIO_DEFAULT_DEV_CONFIG。
 */
// AP 侧静态管脚映射：默认采用本板统一配置（components/board_cfg）。
// 如需把扩展口配成不同功能，删除下面这行转发，直接写完整 GPIO_DEFAULT_DEV_CONFIG 即可覆盖。
#include "usr_gpio_cfg_default.h"
